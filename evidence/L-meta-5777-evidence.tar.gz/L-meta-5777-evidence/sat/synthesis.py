"""Generate a monotone circuit existence problem for a Fano point subset."""
import argparse
import itertools
import json
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument("points", help="comma-separated Fano point labels")
p.add_argument("gates", type=int)
p.add_argument("prefix", type=Path)
p.add_argument("--flag", default="0,0", help="point,line or none")
p.add_argument("--seed-witness",type=Path, help="fix gates from op,a,b triples (1 = AND)")
p.add_argument("--canonical",action="store_true",help="order gates by larger then smaller operand, and require every internal gate to feed the output")
p.add_argument("--separate",action="store_true",help="require different operands in both directions on positive rows for OR and negative rows for AND, justified for a minimum-size circuit")
p.add_argument("--bypass",action="store_true",help="each deletion to either operand must change the output on a boundary row")
p.add_argument("--pareto",action="store_true",help="exclude earlier wire dominating a new wire on signed critical-row signatures at minimum size")
p.add_argument("--tree",action="store_true",help="every gate except output used exactly once")
args=p.parse_args()
points=sorted(set(map(int,args.points.split(","))))
assert points and all(0 <= x < 7 for x in points)
edges=[(x,7+l) for l in range(7) for x in points if (x-l)%7 in (0,1,3)]
labels=sorted({x for e in edges for x in e})
edges=[tuple(labels.index(x) for x in e) for e in edges]
flag=[]
if args.flag!="none":
    a,b=map(int,args.flag.split(","))
    flag=[labels.index(a),labels.index(7+b)]
    assert tuple(flag) in edges
n=len(labels)
def truth(m):
    return any(m>>x&1 and m>>y&1 for x,y in edges)
rows=[(1<<x)|(1<<y) for x,y in edges]
rows += [m for m in range(1<<n) if not truth(m) and all(truth(m|1<<k) for k in range(n) if not m>>k&1)]
clauses=[]
count=0
def fresh():
    global count
    count+=1
    return count
T=fresh()
def add(*ls):
    clauses.append(ls)
add(T)
def one_of(k):
    a=[fresh() for _ in range(k)]
    add(*a)
    for x,y in itertools.combinations(a,2):
        add(-x,-y)
    return a
def AND(x,y):
    z=fresh()
    add(-x,-y,z)
    add(x,-z)
    add(y,-z)
    return z
def OR(x,y): return -AND(-x,-y)
def mux(c,x,y):
    z=fresh()
    add(-c,-x,z)
    add(-c,x,-z)
    add(c,-y,z)
    add(c,y,-z)
    return z
def select(sels,columns):
    z=fresh()
    for sel,v in zip(sels,columns,strict=True):
        add(-sel,-v,z)
        add(-sel,v,-z)
    return z
columns=[[T if m>>k&1 else -T for k in range(n)] for m in rows]
for k in flag:
    columns += [[T if j==k else -T for j in range(n)],[-T]*n]
gatedata=[]
for i in range(args.gates):
    w=n+i
    op=fresh()
    a,b=one_of(w),one_of(w)
    # Distinct earlier operands; commutativity permits a < b.
    for j in range(w):
        for k in range(j+1): add(-a[j],-b[k])
    gatedata.append(dict(op=op,a=a,b=b))
    vals=[(select(a,col),select(b,col)) for col in columns]
    if args.separate:
        # Only at the minimum gate count. Bypassing an OR can lose only
        # positive edges, and bypassing an AND can add only maximal negatives.
        # Each bypass must spoil correctness or we could remove the gate.
        for swap in (False,True):
            positive=[]
            negative=[]
            for idx,(u,v) in enumerate(vals[:len(rows)]):
                if swap: u,v=v,u
                (positive if idx<len(edges) else negative).append(AND(u,-v))
            add(op,*positive)
            add(-op,*negative)
    for j,(x,y) in enumerate(vals):
        if j < len(rows):
            z=mux(op,AND(x,y),OR(x,y))
        elif (j-len(rows))%2==0:
            z=OR(x,y)
        else:
            u,v=vals[j-1]
            z=OR(OR(x,y),AND(op,AND(u,v)))
        columns[j].append(z)
if args.tree:
    for i in range(args.gates-1):
        uses=[v[n+i] for gate in gatedata[i+1:] for v in (gate["a"],gate["b"])]
        add(*uses)
        for x,y in itertools.combinations(uses,2): add(-x,-y)
if args.pareto:
    for j in range(args.gates):
        new=n+j
        for old in range(new):
            witnesses=[]
            for m,col in zip(rows,columns):
                wanted,other=(col[new],col[old]) if truth(m) else (col[old],col[new])
                witnesses.append(AND(wanted,-other))
            add(*witnesses)
for m,col in zip(rows,columns): add(col[-1] if truth(m) else -col[-1])
for i in range(len(flag)): add(columns[len(rows)+2*i+1][-1])
if args.canonical:
    # Kahn's ordering: pick the ready gate with least (larger input,smaller input).
    # A newly ready gate uses the immediately preceding wire; its larger
    # operand therefore exceeds those of all previously ready gates.
    for i,(prev,nxt) in enumerate(zip(gatedata,gatedata[1:])):
        aa,bb,cc,dd=(prev['a'],prev['b'],nxt['a'],nxt['b'])
        # Each non-output gate is used later (a minimal gate-count circuit).
        add(*(sel[n+i] for gate in gatedata[i+1:] for sel in (gate['a'],gate['b'])))
        for u in range(len(bb)):
            add(-bb[u],*dd[u:])
            for v in range(u):
                add(-bb[u],-dd[u],-aa[v],*cc[v:])
if args.bypass:
    for j,d in enumerate(gatedata):
        for port in ("a","b"):
            choose=one_of(len(rows))
            # An AND bypass increases outputs, requiring a negative witness.
            # An OR bypass decreases outputs, requiring a positive witness.
            for m,sel in zip(rows,choose):
                add(-sel, -d['op'] if truth(m) else d['op'])
            w=[fresh() for _ in range(n)]
            for m,sel in zip(rows,choose):
                for k,z in enumerate(w): add(-sel,z if m>>k&1 else -z)
            for i,gi in enumerate(gatedata):
                if j==i:
                    w.append(select(gi[port],w))
                else:
                    u,v=select(gi["a"],w),select(gi["b"],w)
                    w.append(mux(gi["op"],AND(u,v),OR(u,v)))
            add(-d["op"],w[-1])
            add(d["op"],-w[-1])
if args.seed_witness:
    gs=[list(map(int,s.split())) for s in args.seed_witness.read_text().splitlines()]
    if args.canonical:
        order={i:i for i in range(n)}
        remaining=list(enumerate(gs,n))
        normalized=[]
        while remaining:
            choices=[(max(order[a],order[b]),min(order[a],order[b]),t,w)
                     for w,(t,a,b) in remaining if a in order and b in order]
            hi,lo,t,w=min(choices)
            order[w]=n+len(normalized)
            normalized.append([t,lo,hi])
            remaining=[row for row in remaining if row[0]!=w]
        assert order[n+len(gs)-1]==n+len(gs)-1
        gs=normalized
    for (op,a,b),d in zip(gs,gatedata,strict=True):
        a,b=sorted((a,b))
        add(d["op"] if op else -d["op"])
        add(d["a"][a])
        add(d["b"][b])
with args.prefix.with_suffix(".cnf").open("w") as f:
    print("p cnf",count,len(clauses),file=f)
    for c in clauses: print(*c,0,file=f)
args.prefix.with_suffix(".json").write_text(json.dumps(dict(labels=labels,edges=edges,flag=flag,gates=gatedata)))
print(len(rows),"critical rows", count,"variables",len(clauses),"clauses")
