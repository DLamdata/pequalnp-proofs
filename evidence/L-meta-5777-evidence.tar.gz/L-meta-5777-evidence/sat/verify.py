"""Decode a SAT witness, replay the truth table and uncapped singleton degrees."""
import json
import sys
from pathlib import Path
meta=json.loads(Path(sys.argv[1]).read_text())
model=Path(sys.argv[2]).read_text()
assert 'SATISFIABLE' in model and 'UNSATISFIABLE' not in model
pos={int(i) for s in model.splitlines() if s.startswith('v ') for i in s.split()[1:] if int(i)>0}
gs=[]
for d in meta['gates']:
    a,=[i for i,v in enumerate(d['a']) if v in pos]
    b,=[i for i,v in enumerate(d['b']) if v in pos]
    assert a<b
    gs.append((int(d['op'] in pos),a,b))
n=len(meta['labels'])
for m in range(1<<n):
    v=[m>>i&1 for i in range(n)]
    for op,a,b in gs: v.append((v[a]&v[b]) if op else (v[a]|v[b]))
    assert v[-1]==any((m>>x&1) and (m>>y&1) for x,y in meta['edges'])
for f in meta['flag']:
    v=[int(i==f) for i in range(n)]
    for op,a,b in gs: v.append(v[a]+v[b] if op else max(v[a],v[b]))
    assert v[-1]>=2
print('Validated all',1<<n,'rows and flag',meta['flag'],'gates',gs)
