#!/usr/bin/env bash
set -eu
evidence=$(cd "$(dirname "$0")" && pwd)
cd "$evidence"
cadical_bin=${CADICAL:-/workspace/lean-4.36.0-linux/bin/cadical}
run_dir=$(mktemp -d)
printf 'DIMACS files, logs and model outputs in %s\n' "$run_dir"
one() {
  local label=$1 seconds=$2 points=$3 gates=$4
  shift 4
  python3 synthesis.py "$points" "$gates" "$run_dir/$label" "$@"
  local status=0
  "$cadical_bin" --seed=5777 -t "$seconds" -w "$run_dir/$label.model" "$run_dir/$label.cnf" > "$run_dir/$label.log" || status=$?
  case "$status" in
    10) python3 verify.py "$run_dir/$label.json" "$run_dir/$label.model" ;;
    20) printf '%s UNSAT as reported by solver\n' "$label" ;;
    0) printf '%s inconclusive\n' "$label" ;;
    *) return "$status" ;;
  esac
}
case "${1:-control}" in
  control) one control 60 0,1,2,3,4,5,6 28 --seed-witness ../search/seed.txt
    one treecontrol 60 0,1,2,3,4,5,6 29 --canonical --tree --seed-witness tree30.txt
    one canonicalcontrol 60 0,1,2,3,4,5,6 28 --canonical --seed-witness ../search/seed.txt
    one paretocontrol 60 0,1,2,3,4,5,6 27 --canonical --pareto --flag none --seed-witness stars27.txt
    one bypasscontrol 60 0,1,2,3,4,5,6 27 --canonical --separate --bypass --flag none --seed-witness stars27.txt ;;
  tree29) one tree29 255 0,1,2,3,4,5,6 28 --canonical --tree ;;
  full) one full 480 0,1,2,3,4,5,6 27 ;;
  paretofull) one paretofull 320 0,1,2,3,4,5,6 27 --canonical --separate --pareto ;;
  orderedfull) one orderedfull 475 0,1,2,3,4,5,6 27 --canonical --separate ;;
  bypassfull) one bypassfull 380 0,1,2,3,4,5,6 27 --canonical --separate --bypass ;;
  sub013) one sub013 320 0,1,3 11 ;;
  sub012) one sub012 320 0,1,2 11 ;;
  ordered012) one ordered012 540 0,1,2 11 --canonical ;;
  sep013) one sep013 420 0,1,3 11 --canonical --separate ;;
  *) exit 2 ;;
esac
