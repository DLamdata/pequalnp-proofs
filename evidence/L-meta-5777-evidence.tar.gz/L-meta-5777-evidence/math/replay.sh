#!/usr/bin/env bash
set -euo pipefail
evidence_dir="$(cd "$(dirname "$0")" && pwd)"
repo_dir="${1:-/workspace/pequalnp-proofs}"
scratch_dir="$(mktemp -d)"
trap 'rm -rf -- "$scratch_dir"' EXIT
cd "$repo_dir/lean"
export PEQUALNP_HOME="${PEQUALNP_HOME:-/workspace/.pequalnp-build}"
export MATHLIB_CACHE_DIR="${MATHLIB_CACHE_DIR:-/workspace/.pequalnp-cache}"
../tools/build.sh +PEqualNP.Outside.L_meta_2225 +PEqualNP.Outside.L_meta_5775 +PEqualNP.Outside.L_meta_9442 +PEqualNP.Outside.L_meta_17415 +PEqualNP.Outside.L_meta_4101 +PEqualNP.Outside.L_meta_5268 +PEqualNP.MetaComplexity.Helpers.LiveSize
../tools/build.sh --lake env bash -ec '
  export LEAN_PATH="$1:$LEAN_PATH"
  for mod in FlagEquivalence Obstruction BoundaryLift BoundaryCounts BoundarySuffices GateBypass CriticalRows CanonicalFlag SearchCriterion; do
    lean --root="$2" -o "$1/$mod.olean" "$2/$mod.lean"
  done
' bash "$scratch_dir" "$evidence_dir"
