import GateBypass
import BoundaryLift

open PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection PEqualNP.TopForm
open PEqualNP.MetaComplexity.NestedCover
open PEqualNP.Outside.L_meta_4101_aux

namespace FlagEquivalence

theorem or_critical_edge (C : Circuit) (small : C.size ≤ 27) (ao : IsAO2 14 C)
    (computes : ComputesIncidence fanoLines C) (r keep drop : ℕ) (hr : r < C.gates.length)
    (slots : (gateAt C r).inputs = [keep,drop] ∨ (gateAt C r).inputs = [drop,keep])
    (op : (gateAt C r).op = .or) :
    ∃ p l : Fin 7, p ∈ fanoLines l ∧
      let b := incidenceInput {p} {l}
      C.eval b = true ∧ (bypass 14 C r keep).eval b = false ∧
      val C b keep = false ∧ val C b drop = true := by
  have hi : keep < 14+r := ao.2.1 r hr keep (by rcases slots with eq|eq <;> simp [eq])
  obtain ⟨x, diff⟩ := bypass_changes C small ao computes r keep hr hi
  obtain ⟨pos,lost,_,_⟩ := or_row ao hr slots op x diff
  obtain ⟨p,l,flag,cp,dn⟩ := BoundaryLift.lostPositive C (bypass 14 C r keep)
    computes (isAO2_bypass ao hi).1 x pos lost
  refine ⟨p,l,flag,cp,dn,?_⟩
  let y := BoundaryLift.bits {p} {l}
  have row : List.ofFn y = incidenceInput {p} {l} := BoundaryLift.ofFn_bits _ _
  have flip : (bypass 14 C r keep).eval (List.ofFn y) ≠ C.eval (List.ofFn y) := by
    rw [row,cp,dn]; decide
  simpa only [row] using (or_row ao hr slots op y flip).2.2

theorem and_critical_maxfalse (C : Circuit) (small : C.size ≤ 27) (ao : IsAO2 14 C)
    (computes : ComputesIncidence fanoLines C) (r keep drop : ℕ) (hr : r < C.gates.length)
    (slots : (gateAt C r).inputs = [keep,drop] ∨ (gateAt C r).inputs = [drop,keep])
    (op : (gateAt C r).op = .and) :
    ∃ X Y : Finset (Fin 7), IsMaximalFalse fanoLines X Y ∧
      let b := incidenceInput X Y
      C.eval b = false ∧ (bypass 14 C r keep).eval b = true ∧
      val C b keep = true ∧ val C b drop = false := by
  have hi : keep < 14+r := ao.2.1 r hr keep (by rcases slots with eq|eq <;> simp [eq])
  obtain ⟨x, diff⟩ := bypass_changes C small ao computes r keep hr hi
  obtain ⟨neg,gained,_,_⟩ := and_row ao hr slots op x diff
  obtain ⟨X,Y,maximal,cn,dp⟩ := BoundaryLift.gainedFalse C (bypass 14 C r keep)
    computes (isAO2_bypass ao hi).1 x neg gained
  refine ⟨X,Y,maximal,cn,dp,?_⟩
  let y := BoundaryLift.bits X Y
  have row : List.ofFn y = incidenceInput X Y := BoundaryLift.ofFn_bits _ _
  have flip : (bypass 14 C r keep).eval (List.ofFn y) ≠ C.eval (List.ofFn y) := by
    rw [row,cn,dp]; decide
  simpa only [row] using (and_row ao hr slots op y flip).2.2

end FlagEquivalence

#print axioms FlagEquivalence.or_critical_edge
#print axioms FlagEquivalence.and_critical_maxfalse
