import FlagEquivalence
import Complete28

namespace FlagEquivalence
open PEqualNP.Outside.L_meta_4126_research

theorem failureAt28 : ¬ WithGateBudget 28 := by
  intro h
  obtain ⟨size,ao,nd,computes,flag,pdeg,ldeg⟩ := exact_28
  have disj := (budgetEquivalence 28).mp h W 0 0 (by omega) ao nd computes flag
  change W.lineDeg 14 {0} ≤ 1 ∨ W.lineDeg 14 {7} ≤ 1 at disj
  omega

end FlagEquivalence

#print axioms FlagEquivalence.failureAt28
