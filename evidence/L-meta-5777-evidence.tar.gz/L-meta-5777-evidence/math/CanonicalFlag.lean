import Obstruction
import FlagEquivalence
import PEqualNP.Outside.L_meta_5268

open PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection PEqualNP.TopForm
open PEqualNP.MetaComplexity PEqualNP.MetaComplexity.NestedCover

namespace FlagEquivalence

def inc (p l : Fin 7) : Prop := p = l ∨ p = l+1 ∨ p = l+3

def Eligible (C : Circuit) : Prop := C.size ≤ 27 ∧
  (∀ j g, C.gates[j]? = some g → (g.op = .and ∨ g.op = .or) ∧
    ∃ a b : ℕ, g.inputs = [a,b] ∧ a ≠ b ∧ a < 14+j ∧ b < 14+j) ∧
  ∀ x : Fin 14 → Bool, C.eval (List.ofFn x) = true ↔
    ∃ p l : Fin 7, inc p l ∧ x (Fin.castAdd 7 p) = true ∧ x (Fin.natAdd 7 l) = true

theorem toEligible (C : Circuit) (small : C.size ≤ 27) (ao : IsAO2 14 C)
    (nd : ∀ g ∈ C.gates, g.inputs.Nodup) (computes : ComputesIncidence fanoLines C) :
    Eligible C := by
  have gateShape (j : ℕ) (g : Gate) (hit : C.gates[j]? = some g) :
      (g.op = .and ∨ g.op = .or) ∧ ∃ a b : ℕ, g.inputs = [a,b] ∧ a ≠ b ∧
        a < 14 + j ∧ b < 14 + j := by
    have mem := List.mem_of_getElem? hit
    have earlier (i : ℕ) (hi : i ∈ g.inputs) : i < 14+j := by
      have valid : j < C.gates.length := (List.getElem?_eq_some_iff.mp hit).1
      have eq : gateAt C j = g := by
        unfold gateAt
        rw [List.getD_eq_getElem?_getD,hit]
        rfl
      exact ao.2.1 j valid i (eq.symm ▸ hi)
    have hlen := ao.2.2 g mem
    obtain ⟨a,b,slots⟩ : ∃ a b, g.inputs = [a,b] := by
      cases h : g.inputs with
      | nil => simp [h] at hlen
      | cons a mid => cases mid with
        | nil => simp [h] at hlen
        | cons b tail =>
          have empty : tail = [] := by
            apply List.length_eq_zero_iff.mp
            simpa [h] using hlen
          subst tail
          exact ⟨a,b,rfl⟩
    exact ⟨ao.1 g mem,a,b,slots,by simpa [slots] using nd g mem,
      earlier a (by simp [slots]),earlier b (by simp [slots])⟩
  exact ⟨small,gateShape,incidenceTable C computes⟩

set_option maxHeartbeats 2000000 in
theorem fromEligible (C : Circuit) (eligible : Eligible C) :
    IsAO2 14 C ∧ (∀ g ∈ C.gates, g.inputs.Nodup) ∧ ComputesIncidence fanoLines C := by
  have fanoPoint (p l : Fin 7) : p ∈ fanoLines l ↔
      p = l ∨ p = l + 1 ∨ p = l + 3 := by
    revert p l
    decide +kernel
  unfold Eligible inc at eligible
  have cb : IsAO2 14 C := by
    refine ⟨?_,?_,?_⟩
    · intro g hg
      obtain ⟨j,hj⟩ := List.mem_iff_getElem?.1 hg
      exact (eligible.2.1 j g hj).1
    · intro j hj i hi
      have lookup : gateAt C j = C.gates[j] := List.getD_eq_getElem _ _ hj
      rw [lookup] at hi
      obtain ⟨_,a,b,eq,_,ha,hb⟩ := eligible.2.1 j C.gates[j] (List.getElem?_eq_getElem hj)
      simp only [eq,List.mem_cons,List.mem_nil_iff,or_false] at hi
      rcases hi with rfl | rfl <;> assumption
    · intro g hg
      obtain ⟨j,hj⟩ := List.mem_iff_getElem?.1 hg
      obtain ⟨_,a,b,eq,_,_,_⟩ := eligible.2.1 j g hj
      simp [eq]
  have nd : ∀ g ∈ C.gates, g.inputs.Nodup := by
    intro g hg
    obtain ⟨j,hj⟩ := List.mem_iff_getElem?.1 hg
    obtain ⟨_,a,b,eq,ne,_,_⟩ := eligible.2.1 j g hj
    simp [eq,ne]
  have incidence : ComputesIncidence fanoLines C := by
    intro X Y
    let x : Fin 14 → Bool := Fin.append (fun u => decide (u ∈ X)) (fun v => decide (v ∈ Y))
    have eq : List.ofFn x = incidenceInput X Y := List.ofFn_fin_append _ _
    rw [← eq]
    apply Bool.eq_iff_iff.mpr
    rw [eligible.2.2 x]
    have result : incidenceFun fanoLines X Y = true ↔
        ∃ p ∈ X, ∃ l ∈ Y, p ∈ fanoLines l := by
      change decide (∃ p ∈ X, ∃ l ∈ Y, p ∈ fanoLines l) = true ↔ _
      constructor
      · intro h; exact of_decide_eq_true h
      · intro h; exact decide_eq_true h
    rw [result]
    simp only [x, Fin.append_left, Fin.append_right, decide_eq_true_eq, fanoPoint]
    constructor
    · rintro ⟨u,v,hit,hu,hv⟩
      exact ⟨u,hu,v,hv,hit⟩
    · rintro ⟨u,hu,v,hv,hit⟩
      exact ⟨u,v,hit,hu,hv⟩
  exact ⟨cb,nd,incidence⟩

set_option maxHeartbeats 2000000 in
theorem canonicalWitness (C : Circuit) (p l : Fin 7) (hv : Eligible C) (hflag : inc p l)
    (hp : 2 ≤ C.lineDeg 14 {p.val}) (hl : 2 ≤ C.lineDeg 14 {7+l.val}) :
    ∃ E : Circuit, Eligible E ∧ 2 ≤ E.lineDeg 14 {0} ∧ 2 ≤ E.lineDeg 14 {7} := by
  let mul : Fin 3 → Fin 7 := fun k => if k = 0 then 1 else if k = 1 then 2 else 4
  let off : Fin 3 → Fin 7 := fun k => if k = 0 then 0 else if k = 1 then 1 else 3
  let point (k : Fin 3) (b z : Fin 7) := mul k * (z - b) + off k
  let line (k : Fin 3) (b z : Fin 7) := mul k * (z - b)
  have pinj : ∀ (k : Fin 3) (b u v : Fin 7), point k b u = point k b v → u = v := by
    dsimp only [point, mul, off]
    decide +kernel
  have linj : ∀ (k : Fin 3) (b u v : Fin 7), line k b u = line k b v → u = v := by
    dsimp only [line, mul]
    decide +kernel
  have psurj : ∀ (k : Fin 3) (b v : Fin 7), ∃ u : Fin 7, point k b u = v := by
    dsimp only [point, mul, off]
    decide +kernel
  have lsurj : ∀ (k : Fin 3) (b v : Fin 7), ∃ u : Fin 7, line k b u = v := by
    dsimp only [line, mul]
    decide +kernel
  have hauto : ∀ (k : Fin 3) (b u v : Fin 7), inc (point k b u) (line k b v) ↔ inc u v := by
    dsimp only [inc, point, line, mul, off]
    decide +kernel
  have hmove : ∀ u v : Fin 7, inc u v → ∃ k : Fin 3, point k v u = 0 ∧ line k v v = 0 := by
    dsimp only [inc, point, line, mul, off]
    decide +kernel
  obtain ⟨k, hmP, hmL⟩ := hmove p l hflag
  classical
  let P : Equiv.Perm (Fin 7) :=
    Equiv.ofBijective (point k l) ⟨fun _ _ => pinj k l _ _, psurj k l⟩
  let L : Equiv.Perm (Fin 7) :=
    Equiv.ofBijective (line k l) ⟨fun _ _ => linj k l _ _, lsurj k l⟩
  have pzero : P p = 0 := hmP
  have lzero : L l = 0 := hmL
  have hi : ∀ u v, inc (P u) (L v) ↔ inc u v := hauto k l
  obtain ⟨E, he, hte, hep, hel⟩ := PEqualNP.Outside.L_meta_5268 P L hi C hv
  have ep : 2 ≤ E.lineDeg 14 {0} := by
    have eq := hep p
    rw [pzero] at eq
    change E.lineDeg 14 {0} = _ at eq
    rw [eq]
    exact hp
  have el : 2 ≤ E.lineDeg 14 {7} := by
    have eq := hel l
    rw [lzero] at eq
    change E.lineDeg 14 {7} = _ at eq
    rw [eq]
    exact hl
  exact ⟨E,he,ep,el⟩

theorem canonicalIff : PostedStatement ↔
    ¬∃ C : Circuit, Eligible C ∧ 2 ≤ C.lineDeg 14 {0} ∧ 2 ≤ C.lineDeg 14 {7} := by
  rw [flagEquivalence]
  constructor
  · rintro allFlags ⟨C,hC,dp,dl⟩
    obtain ⟨ao,nd,computes⟩ := fromEligible C hC
    have dis := allFlags C 0 0 hC.1 ao nd computes (by decide)
    change C.lineDeg 14 {0} ≤ 1 ∨ C.lineDeg 14 {7} ≤ 1 at dis
    omega
  · intro noCase C p l small ao nd computes flag
    by_contra! high
    have incEq : ∀ a b : Fin 7, a ∈ fanoLines b ↔ inc a b := by
      unfold inc
      decide
    exact noCase (canonicalWitness C p l (toEligible C small ao nd computes)
      ((incEq p l).mp flag) high.1 high.2)

end FlagEquivalence

#print axioms FlagEquivalence.canonicalIff
