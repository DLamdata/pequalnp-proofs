import Obstruction
import PEqualNP.Outside.L_meta_4101

open PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection PEqualNP.TopForm
open PEqualNP.MetaComplexity.NestedCover
open PEqualNP.Outside.L_meta_4101_aux

namespace FlagEquivalence

theorem bypass_changes (C : Circuit) (small : C.size ≤ 27) (ao : IsAO2 14 C)
    (computes : ComputesIncidence fanoLines C) (r keep : ℕ) (hr : r < C.gates.length)
    (hi : keep < 14+r) : ∃ x : Fin 14 → Bool,
      (bypass 14 C r keep).eval (List.ofFn x) ≠ C.eval (List.ofFn x) := by
  by_contra! same
  have da := isAO2_bypass ao hi
  have fp : ∀ a b : Fin 7, a ∈ fanoLines b ↔ a = b ∨ a = b + 1 ∨ a = b + 3 := by decide
  have lower := PEqualNP.Outside.L_meta_9442 (bypass 14 C r keep) da (fun x => by
    rw [same x]; simpa only [fp] using incidenceTable C computes x)
  unfold Circuit.size at lower small
  rw [bypass_length] at lower
  omega

theorem anyAO (C : Circuit) (ao : IsAO2 14 C) :
    ∀ k < C.gates.length, (gateAt C k).op = .and ∨ (gateAt C k).op = .or :=
  fun k hk => ao.1 _ (gateAt_mem hk)

theorem diffwire {C : Circuit} {r keep : ℕ} (ao : IsAO2 14 C) (hr : r < C.gates.length)
    (hi : keep < 14+r) {x : Fin 14 → Bool}
    (diff : (bypass 14 C r keep).eval (List.ofFn x) ≠ C.eval (List.ofFn x)) :
    val C (List.ofFn x) (14+r) ≠ val C (List.ofFn x) keep :=
  fun eq => diff (bypass_eval_eq List.length_ofFn (anyAO C ao) hr (Or.inl hi) eq)

theorem gateBits {C : Circuit} {r keep drop : ℕ} (ao : IsAO2 14 C) (hr : r < C.gates.length)
    (slots : (gateAt C r).inputs = [keep,drop] ∨ (gateAt C r).inputs = [drop,keep])
    (x : Fin 14 → Bool) :
    let V := val C (List.ofFn x)
    ((gateAt C r).op = .or → V (14+r) = (V keep || V drop)) ∧
    ((gateAt C r).op = .and → V (14+r) = (V keep && V drop)) := by
  dsimp only
  have hk : keep < 14+r := ao.2.1 r hr keep (by rcases slots with eq|eq <;> simp [eq])
  have hd : drop < 14+r := ao.2.1 r hr drop (by rcases slots with eq|eq <;> simp [eq])
  have gate := val_gate (C := C) (x := List.ofFn x) List.length_ofFn hr
  constructor <;> intro op <;> rw [gate,op] <;> rcases slots with eq|eq <;>
    simp [eq,GateOp.eval,hk,hd,Bool.and_comm,Bool.or_comm]

theorem flipMono : OpMono (fun a b => b = true → a = true) :=
  fun op hop l f g h => opMono_imp op hop l g f h

theorem or_row {C : Circuit} {r keep drop : ℕ} (ao : IsAO2 14 C) (hr : r < C.gates.length)
    (slots : (gateAt C r).inputs = [keep,drop] ∨ (gateAt C r).inputs = [drop,keep])
    (op : (gateAt C r).op = .or) (x : Fin 14 → Bool)
    (diff : (bypass 14 C r keep).eval (List.ofFn x) ≠ C.eval (List.ofFn x)) :
    C.eval (List.ofFn x) = true ∧ (bypass 14 C r keep).eval (List.ofFn x) = false ∧
    val C (List.ofFn x) keep = false ∧ val C (List.ofFn x) drop = true := by
  have hi : keep < 14+r := ao.2.1 r hr keep (by rcases slots with eq|eq <;> simp [eq])
  have bits := (gateBits ao hr slots x).1 op
  have sep := diffwire ao hr hi diff
  have down := bypass_eval_rel (R := fun a b => b = true → a = true) (fun _ h => h) flipMono
    (C := C) (x := List.ofFn x) List.length_ofFn (anyAO C ao) hr (Or.inl hi)
    (fun h => by rw [bits,h]; rfl)
  grind

theorem and_row {C : Circuit} {r keep drop : ℕ} (ao : IsAO2 14 C) (hr : r < C.gates.length)
    (slots : (gateAt C r).inputs = [keep,drop] ∨ (gateAt C r).inputs = [drop,keep])
    (op : (gateAt C r).op = .and) (x : Fin 14 → Bool)
    (diff : (bypass 14 C r keep).eval (List.ofFn x) ≠ C.eval (List.ofFn x)) :
    C.eval (List.ofFn x) = false ∧ (bypass 14 C r keep).eval (List.ofFn x) = true ∧
    val C (List.ofFn x) keep = true ∧ val C (List.ofFn x) drop = false := by
  have hi : keep < 14+r := ao.2.1 r hr keep (by rcases slots with eq|eq <;> simp [eq])
  have bits := (gateBits ao hr slots x).2 op
  have sep := diffwire ao hr hi diff
  have up := bypass_eval_rel (R := fun a b => a = true → b = true) (fun _ h => h) opMono_imp
    (C := C) (x := List.ofFn x) List.length_ofFn (anyAO C ao) hr (Or.inl hi)
    (fun h => (Bool.and_eq_true_iff.mp (bits ▸ h)).1)
  grind

end FlagEquivalence
