# L-meta-5777 formal research evidence

These certificates use the project's pinned Lean 4.36.0 and Mathlib revision `fc4f59e577feb1a4956671bc04ac18aaaf8cd842` in `open-goat/pequalnp-proofs` at `7c4efd6d7efbd8a5b701c1c3405343b01acf5fac`. Codex generated and ran them. They are local research certificates. They import checked project results beyond the desk's allowed submission import list.

Run from this directory in the prepared task environment, or pass the path of another checkout at the same revision. `PEQUALNP_HOME` and `MATHLIB_CACHE_DIR` can be set to its writable caches.

```bash
bash replay.sh /workspace/pequalnp-proofs
bash replay-boundary.sh /workspace/pequalnp-proofs
```

- `FlagEquivalence.lean` contains the verbatim desk proposition and proves `exactBudget` by reflexivity. `flagEquivalence` equates it to saying that for every eligible circuit and incident flag, one of its two marked degrees is at most one. The formula-to-circuit compiler L-meta-5775 saves the number of leaves minus one in gates, keeps the marked degrees unchanged and yields distinct internal-wire uses. L-meta-2225 rules out both degrees being at least two for such a circuit. This proof uses the point encoding `{0,1,3} + l` in Fin 7 and checks that it agrees with the Boolean truth function on all 14 input bits.
- `Obstruction.lean` proves `liveObstruction`. Any counterexample candidate has exactly 27 gates, output wire 40, and every gate belongs to the output cone. Some internal wire occurs at least twice in the flattened gate inputs. Since every gate has distinct operands, these are uses by different gates. An AND strictly below the output fires on an input with one or two active bits that the output rejects. The general propagation lemma `blockingAND` locates a later AND on that path whose output is false while an input wire is true. These claims combine the Fano lower bound L-meta-9442, L-meta-2225, the pair-clean result L-meta-17415, and the project's live-gate pruning theorem. The counterexample candidate itself has not been found or ruled out.
- `Boundary28.lean` proves `failureAt28`. The variant obtained by changing only the circuit budget to 28 is false. The formula budget stays at 28 leaves. It uses the separately checked 28-gate witness `W` and its exact marked degrees 3 and 2 from `../prefix/Complete28.lean`. `boundary.log` records the three axioms printed for this certificate.
- `GateBypass.lean` formalizes a necessary condition at every gate. `bypass_changes` uses the lower bound to show that replacing a gate by an earlier wire changes the output on some complete input. `or_row` and `and_row` determine the exact gate operand bits on any differing input when the replacement is one of the two gate inputs. These lemmas use the existing L-meta-4101 bypass construction.

The arguments are symbolic and use the Lean kernel. The source and logs in this directory contain no numerical synthesis results or random-seed claims.

`BoundaryLift.lean` proves boundary-row lifting for Fano incidence and an arbitrary AND/OR comparison circuit. `CriticalRows.lean` combines it with `GateBypass.lean`. For each OR gate and each choice of retained operand, an incident point/line pair row makes the retained operand false and the other true. Bypassing the gate to the retained operand changes the final output from true to false. For an AND gate, a maximal false row makes the retained operand true and the other false, and bypassing changes the final output from false to true. Swapping which operand is retained gives the other orientation. The bypassed circuit may have repeated operands, which the 27-gate lower bound allows.

`BoundaryCounts.lean` proves the incident-row count 21 and maximal-false-row count 37. The kernel enumerates only the 128 point subsets for the latter count, using a proof that each uniquely determines its maximal set of lines. The positive rows comprise all 21 distinct incident point/line pairs; the false rows represent all inclusion-maximal independent inputs in the same labeling.

`CanonicalFlag.lean` checks a reduction to the specific flag consisting of point 0 and line 0. It uses the existing L-meta-5268 transport theorem and automorphisms verified for the actual modular labels of the Fano plane. The automorphism construction follows R-meta-2223-528. The shape and incidence conversions follow R-meta-2223-607. `BoundarySuffices.lean` proves matching the 58 boundary rows suffices for AO2 circuits.

`SearchCriterion.lean` combines the results into one equivalence: the verbatim posted statement holds iff there is no circuit satisfying `SearchWitness`. That predicate requires 27 gates, output wire 40, binary back-reading AND/OR gates with distinct operands, agreement on all 21 incident rows and 37 maximal false rows, and both marked degrees at least 2 for flag (0,0). This is a mathematical search specification. No theorem in these files certifies a SAT encoder, proof trace or outcome of the unrestricted search.
