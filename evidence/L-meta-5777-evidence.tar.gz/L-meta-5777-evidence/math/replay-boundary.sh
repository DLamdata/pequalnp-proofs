#!/usr/bin/env bash
set -euo pipefail
evidence_dir="$(cd "$(dirname "$0")" && pwd)"
repo_dir="${1:-/workspace/pequalnp-proofs}"
scratch_dir="$(mktemp -d)"
trap 'rm -rf -- "$scratch_dir"' EXIT
cp "$evidence_dir/FlagEquivalence.lean" "$evidence_dir/../prefix/Complete28.lean" "$evidence_dir/Boundary28.lean" "$scratch_dir/"
cd "$repo_dir/lean"
export PEQUALNP_HOME="${PEQUALNP_HOME:-/workspace/.pequalnp-build}"
export MATHLIB_CACHE_DIR="${MATHLIB_CACHE_DIR:-/workspace/.pequalnp-cache}"
../tools/build.sh +PEqualNP.Outside.L_meta_2225 +PEqualNP.Outside.L_meta_5775
for mod in FlagEquivalence Complete28; do
  ../tools/build.sh --lake env lean --root="$scratch_dir" -o "$scratch_dir/$mod.olean" "$scratch_dir/$mod.lean"
done
../tools/build.sh --lake env bash -ec 'export LEAN_PATH="$1:$LEAN_PATH"; lean --root="$1" "$1/Boundary28.lean"' bash "$scratch_dir"
