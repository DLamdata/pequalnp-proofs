import PEqualNP.MetaComplexity.Helpers.LiveSize
import PEqualNP.Outside.L_meta_17415
import PEqualNP.Outside.L_meta_9442
import PEqualNP.Outside.L_meta_2225

open PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection PEqualNP.TopForm
open PEqualNP.MetaComplexity PEqualNP.MetaComplexity.NestedCover

namespace FlagEquivalence

theorem incidenceTable (C : Circuit) (computes : ComputesIncidence fanoLines C) (x : Fin 14 → Bool) : C.eval (List.ofFn x) = true ↔
    ∃ a b : Fin 7, (a = b ∨ a = b+1 ∨ a = b+3) ∧
      x (Fin.castAdd 7 a) = true ∧ x (Fin.natAdd 7 b) = true := by
  have fp : ∀ a b : Fin 7, a ∈ fanoLines b ↔ a = b ∨ a = b + 1 ∨ a = b + 3 := by decide
  let X := Finset.univ.filter (fun a : Fin 7 => x (Fin.castAdd 7 a) = true)
  let Y := Finset.univ.filter (fun b : Fin 7 => x (Fin.natAdd 7 b) = true)
  let bits := Fin.append (fun a : Fin 7 => decide (a ∈ X)) (fun b : Fin 7 => decide (b ∈ Y))
  have eq : bits = x := by
    funext i
    refine Fin.addCases (fun a => ?_) (fun b => ?_) i
    · unfold bits
      rw [Fin.append_left]
      simp [X]
    · unfold bits
      rw [Fin.append_right]
      simp [Y]
  have input : List.ofFn bits = incidenceInput X Y := List.ofFn_fin_append ..
  rw [eq] at input
  rw [input, computes]
  change decide (∃ a ∈ X, ∃ b ∈ Y, a ∈ fanoLines b) = true ↔ _
  simp only [decide_eq_true_eq, X, Y, Finset.mem_filter, Finset.mem_univ, true_and, fp]
  constructor
  · rintro ⟨a,xa,b,xb,ab⟩
    exact ⟨a,b,ab,xa,xb⟩
  · rintro ⟨a,b,ab,xa,xb⟩
    exact ⟨a,xa,b,xb,ab⟩

set_option maxHeartbeats 2000000 in
theorem obstruction (C : Circuit) (p l : Fin 7) (small : C.size ≤ 27) (ao : IsAO2 14 C)
    (nd : ∀ g ∈ C.gates, g.inputs.Nodup) (computes : ComputesIncidence fanoLines C)
    (flag : p ∈ fanoLines l) (pd : 2 ≤ C.lineDeg 14 {p.val})
    (ld : 2 ≤ C.lineDeg 14 {7+l.val}) :
    C.size = 27 ∧
    ¬(((C.output :: C.gates.flatMap Gate.inputs).filter (fun w => decide (14 ≤ w))).Nodup) ∧
    ∃ (j : ℕ) (u v : Fin 14), PEqualNP.ReadTwo.isAnd C j ∧
      PEqualNP.EdgeOwnership.gateVal 14 C j (PEqualNP.EdgeOwnership.pairInput u v) = true ∧
      C.eval (List.ofFn (PEqualNP.EdgeOwnership.pairInput u v)) = false := by
  have fp : ∀ a b : Fin 7, a ∈ fanoLines b ↔ a = b ∨ a = b + 1 ∨ a = b + 3 := by decide
  have gateShape (j : ℕ) (g : Gate) (hit : C.gates[j]? = some g) :
      (g.op = .and ∨ g.op = .or) ∧ ∃ a b : ℕ, g.inputs = [a,b] ∧ a ≠ b ∧
        a < 14 + j ∧ b < 14 + j := by
    have mem := List.mem_of_getElem? hit
    have earlier (i : ℕ) (hi : i ∈ g.inputs) : i < 14+j := by
      have valid : j < C.gates.length := (List.getElem?_eq_some_iff.mp hit).1
      have eq : gateAt C j = g := by
        unfold gateAt
        rw [List.getD_eq_getElem?_getD,hit]
        rfl
      exact ao.2.1 j valid i (eq.symm ▸ hi)
    have hlen := ao.2.2 g mem
    obtain ⟨a,b,slots⟩ : ∃ a b, g.inputs = [a,b] := by
      cases h : g.inputs with
      | nil => simp [h] at hlen
      | cons a mid => cases mid with
        | nil => simp [h] at hlen
        | cons b tail =>
          have empty : tail = [] := by
            apply List.length_eq_zero_iff.mp
            simpa [h] using hlen
          subst tail
          exact ⟨a,b,rfl⟩
    exact ⟨ao.1 g mem,a,b,slots,by simpa [slots] using nd g mem,
      earlier a (by simp [slots]),earlier b (by simp [slots])⟩
  have cor := incidenceTable C computes
  have lower := PEqualNP.Outside.L_meta_9442 C ao (fun x => by simpa only [fp] using cor x)
  refine ⟨by omega, ?_, ?_⟩
  · intro tree
    have bad := PEqualNP.Outside.L_meta_2225 C p l ⟨small,gateShape,cor⟩ tree ((fp p l).mp flag)
    change C.lineDeg 14 {p.val} ≤ 1 ∨ C.lineDeg 14 {7+l.val} ≤ 1 at bad
    omega
  · by_contra hc
    have tests (j : ℕ) (hj : PEqualNP.ReadTwo.isAnd C j) (u v : Fin 14)
        (hv : PEqualNP.EdgeOwnership.gateVal 14 C j (PEqualNP.EdgeOwnership.pairInput u v) = true) :
        C.eval (List.ofFn (PEqualNP.EdgeOwnership.pairInput u v)) = true := by
      cases hh : C.eval (List.ofFn (PEqualNP.EdgeOwnership.pairInput u v)) with
      | true => rfl
      | false => exact False.elim (hc ⟨j,u,v,hj,hv,hh⟩)
    have bad := PEqualNP.Outside.L_meta_17415 C ⟨small,gateShape,cor⟩ tests p l ((fp p l).mp flag)
    omega

open PEqualNP.MetaComplexity.LiveSize PEqualNP.FactorSubst PEqualNP.EdgeOwnership

theorem path_forward {C : Circuit} {a b : ℕ} (path : Relation.TransGen (RR 14 C) a b) :
    a < b ∧ b < C.gates.length := by
  induction path with
  | single edge => exact ⟨edge.2.1,edge.1⟩
  | tail _ edge ih => exact ⟨lt_trans ih.1 edge.2.1,edge.1⟩

set_option maxHeartbeats 2000000 in
theorem liveObstruction (C : Circuit) (p l : Fin 7) (small : C.size ≤ 27) (ao : IsAO2 14 C)
    (nd : ∀ g ∈ C.gates, g.inputs.Nodup) (computes : ComputesIncidence fanoLines C)
    (flag : p ∈ fanoLines l) (pd : 2 ≤ C.lineDeg 14 {p.val})
    (ld : 2 ≤ C.lineDeg 14 {7+l.val}) :
    C.size = 27 ∧ C.output = 40 ∧ liveGates 14 C = Finset.range 27 ∧
    ¬((C.gates.flatMap Gate.inputs).filter (fun w => decide (14 ≤ w))).Nodup ∧
    ∃ (j : ℕ) (u v : Fin 14), PEqualNP.ReadTwo.isAnd C j ∧
      InCone 14 C j 26 ∧ gateVal 14 C j (pairInput u v) = true ∧
      C.eval (List.ofFn (pairInput u v)) = false := by
  obtain ⟨size,shared,⟨j,u,v,jand,jval,bad⟩⟩ := obstruction C p l small ao nd computes flag pd ld
  have len : C.gates.length = 27 := size
  obtain ⟨D,dao,dsize,equiv⟩ := live_main 14 C.gates.length C rfl ao
  change ∀ x : Fin 14 → Bool, D.eval (List.ofFn x) = C.eval (List.ofFn x) at equiv
  have fp : ∀ a b : Fin 7, a ∈ fanoLines b ↔ a = b ∨ a = b+1 ∨ a = b+3 := by decide
  have lower := PEqualNP.Outside.L_meta_9442 D dao (fun x => by
    rw [equiv]; simpa only [fp] using incidenceTable C computes x)
  have allLive : liveGates 14 C = Finset.range 27 := by
    apply Finset.eq_of_subset_of_card_le
    · rw [←len]
      exact Finset.filter_subset _ _
    · rw [Finset.card_range]
      rw [dsize] at lower
      exact lower
  have liveLast : 26 ∈ liveGates 14 C := by rw [allLive]; decide
  obtain ⟨_,outlo,atEnd|inside⟩ := (mem_live 14 C 26).mp liveLast
  all_goals try exact False.elim (by obtain ⟨lt,hi⟩ := path_forward inside; omega)
  have out : C.output = 40 := by omega
  have outfree : C.output ∉ C.gates.flatMap Gate.inputs := by
    intro mem
    obtain ⟨g,gm,ow⟩ := List.mem_flatMap.mp mem
    obtain ⟨k,hk⟩ := List.mem_iff_getElem?.mp gm
    have kl := (List.getElem?_eq_some_iff.mp hk).1
    have gg : gateAt C k = g := by
      unfold gateAt
      rw [List.getD_eq_getElem?_getD,hk]
      rfl
    have early := ao.2.1 k kl C.output (gg.symm ▸ ow)
    omega
  have hshare : ¬((C.gates.flatMap Gate.inputs).filter (fun w => decide (14 ≤ w))).Nodup := by
    intro h
    apply shared
    have ho : decide (14 ≤ C.output) = true := by rw [out]; decide
    simp only [List.filter_cons, ho, Bool.true_eq, ↓reduceIte, List.nodup_cons]
    exact ⟨fun m => outfree (List.mem_of_mem_filter m),h⟩
  refine ⟨size,out,allLive,hshare,j,u,v,jand,?_,jval,bad⟩
  have jm : j ∈ liveGates 14 C := by
    rw [allLive,←len]
    exact Finset.mem_range.mpr jand.1
  obtain ⟨_,_,endGate|path⟩ := (mem_live 14 C j).mp jm
  · have eqj : 14+j=C.output := by omega
    unfold gateVal at jval
    rw [eqj] at jval
    change (C.wires (List.ofFn (pairInput u v))).getD C.output false = false at bad
    rw [bad] at jval
    contradiction
  · rw [out] at path
    exact (cone_iff 14 C j 26).mpr path

theorem crossing {α : Type} {R : α → α → Prop} (P : α → Prop) {a b : α}
    (path : Relation.TransGen R a b) (pa : P a) (pb : ¬P b) :
    ∃ i k, (a = i ∨ Relation.TransGen R a i) ∧ R i k ∧
      (k = b ∨ Relation.TransGen R k b) ∧ P i ∧ ¬P k := by
  classical
  induction path with
  | single e => exact ⟨_,_,Or.inl rfl,e,Or.inl rfl,pa,pb⟩
  | @tail c d prev edge ih =>
    by_cases pc : P c
    · exact ⟨c,d,Or.inr prev,edge,Or.inl rfl,pc,pb⟩
    · obtain ⟨i,k,ai,ik,kc,pi,pk⟩ := ih pc
      refine ⟨i,k,ai,ik,Or.inr ?_,pi,pk⟩
      rcases kc with rfl | sub
      · exact Relation.TransGen.single edge
      · exact Relation.TransGen.tail sub edge

open PEqualNP.Outside.L_meta_17415_aux.ConcreteModel

theorem blockingAND (C : Circuit) (x : Fin 14 → Bool) (ao : IsAO2 14 C)
    (j root : ℕ) (path : InCone 14 C j root) (source : gateVal 14 C j x = true)
    (target : gateVal 14 C root x = false) :
    ∃ i k, (i = j ∨ InCone 14 C j i) ∧ InCone 14 C j k ∧
      (k = root ∨ InCone 14 C k root) ∧ PEqualNP.ReadTwo.isAnd C k ∧
      14+i ∈ (gateAt C k).inputs ∧ gateVal 14 C i x = true ∧ gateVal 14 C k x = false := by
  obtain ⟨i,k,ji,ik,kr,pi,pk⟩ := crossing (fun i => gateVal 14 C i x = true)
    ((cone_iff ..).mp path) source (by rw [target]; decide)
  have fk : gateVal 14 C k x = false := by simpa only [Bool.not_eq_true] using pk
  have andk : PEqualNP.ReadTwo.isAnd C k := by
    have hk := ik.1
    have mem : C.gates[k] ∈ C.gates := List.getElem_mem ..
    have hgate := ao.1 _ mem
    unfold PEqualNP.ReadTwo.isAnd
    rw [Fold.gateAt_eq hk]
    refine ⟨hk,hgate.resolve_right ?_⟩
    intro op
    have e := Fold.gate_val Fold.Fw false Fold.loc_w 14 C ao.2.1 (List.ofFn x) (by simp) k hk
    change gateVal 14 C k x = C.gates[k].op.eval (C.gates[k].inputs.map (W C x)) at e
    have tmem : true ∈ C.gates[k].inputs.map (W C x) := by
      apply List.mem_map.mpr
      exact ⟨14+i, Fold.gateAt_eq hk ▸ ik.2.2, pi⟩
    rw [fk,op] at e
    change false = (C.gates[k].inputs.map (W C x)).any id at e
    have tr := List.any_eq_true.mpr (show ∃ y ∈ C.gates[k].inputs.map (W C x), id y = true
      from ⟨true,tmem,rfl⟩)
    simp [tr] at e
  have toK : Relation.TransGen (RR 14 C) j k := by
    rcases ji with rfl|p
    · exact Relation.TransGen.single ik
    · exact Relation.TransGen.tail p ik
  exact ⟨i,k,ji.elim (fun h => Or.inl h.symm) (fun h => Or.inr ((cone_iff ..).mpr h)),
    (cone_iff ..).mpr toK,kr.imp id (cone_iff ..).mpr,andk,ik.2.2,pi,fk⟩

end FlagEquivalence
