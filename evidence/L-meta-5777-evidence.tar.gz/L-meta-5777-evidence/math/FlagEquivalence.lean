import PEqualNP.Outside.L_meta_2225
import PEqualNP.Outside.L_meta_5775

open PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection PEqualNP.TopForm
open PEqualNP.MetaComplexity PEqualNP.MetaComplexity.NestedCover

namespace FlagEquivalence

abbrev WithGateBudget (budget : ℕ) : Prop :=
have x1 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → Prop → Prop → Prop := fun (x1 x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x3 x4 : Prop) => x3 ∧ x4 ∧ ¬∃ (x5 : Fin (14 : ℕ)), x1 = PEqualNP.MetaComplexity.DMFormula.lit x5 Bool.true ∧ x2 = PEqualNP.MetaComplexity.DMFormula.lit x5 Bool.true; have x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → Prop := fun (x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) => PEqualNP.MetaComplexity.DMFormula.rec (fun (x3 : Fin (14 : ℕ)) (x4 : Bool) => x4 = Bool.true) x1 x1 x2; have x3 : ℕ → PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → ℕ := fun (x3 : ℕ) (x4 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) => PEqualNP.MetaComplexity.DMFormula.rec (fun (x5 : Fin (14 : ℕ)) (x6 : Bool) => if ↑x5 = x3 then (1 : ℕ) else (0 : ℕ)) (fun (x5 x6 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x7 x8 : ℕ) => x7 + x8) (fun (x5 x6 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x7 x8 : ℕ) => Max.max x7 x8) x4; ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit) (x5 x6 : Fin (7 : ℕ)), x4.size ≤ budget → PEqualNP.TopForm.IsAO2 (14 : ℕ) x4 → (∀ x9 ∈ x4.gates, x9.inputs.Nodup) → PEqualNP.GenericRejection.ComputesIncidence PEqualNP.CircuitLowerBounds.fanoLines x4 → x5 ∈ PEqualNP.CircuitLowerBounds.fanoLines x6 → (2 : ℕ) ≤ x4.lineDeg (14 : ℕ) {↑x5} → (2 : ℕ) ≤ x4.lineDeg (14 : ℕ) {(7 : ℕ) + ↑x6} → ∃ (x14 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)), x2 x14 ∧ x14.leaves ≤ (28 : ℕ) ∧ (∀ (x15 : Fin (14 : ℕ) → Bool), x14.eval x15 = x4.eval (List.ofFn x15)) ∧ (2 : ℕ) ≤ x3 (↑x5) x14 ∧ (2 : ℕ) ≤ x3 ((7 : ℕ) + ↑x6) x14

set_option maxHeartbeats 2000000 in
theorem budgetEquivalence (budget : ℕ) : WithGateBudget budget ↔
    ∀ (C : Circuit) (p l : Fin 7), C.size ≤ budget → IsAO2 14 C →
      (∀ g ∈ C.gates, g.inputs.Nodup) → ComputesIncidence fanoLines C →
      p ∈ fanoLines l → C.lineDeg 14 {p.val} ≤ 1 ∨ C.lineDeg 14 {7 + l.val} ≤ 1 := by
  constructor
  · intro orig C p l small ao nd computes flag
    by_contra! both
    obtain ⟨t, good, leaf, agrees, pd, ld⟩ := orig C p l small ao nd computes flag both.1 both.2
    obtain ⟨D, dao, dnd, ds, dtree, deval, ddeg⟩ := PEqualNP.Outside.L_meta_5775 t good
    have fp : ∀ a b : Fin 7, a ∈ fanoLines b ↔ a = b ∨ a = b + 1 ∨ a = b + 3 := by decide
    have gateShape (j : ℕ) (g : Gate) (hit : D.gates[j]? = some g) :
        (g.op = .and ∨ g.op = .or) ∧ ∃ a b : ℕ, g.inputs = [a,b] ∧ a ≠ b ∧
          a < 14 + j ∧ b < 14 + j := by
      have mem := List.mem_of_getElem? hit
      have earlier (i : ℕ) (hi : i ∈ g.inputs) : i < 14+j := by
        have valid : j < D.gates.length := (List.getElem?_eq_some_iff.mp hit).1
        have eq : gateAt D j = g := by
          unfold gateAt
          rw [List.getD_eq_getElem?_getD,hit]
          rfl
        exact dao.2.1 j valid i (eq.symm ▸ hi)
      have hlen := dao.2.2 g mem
      obtain ⟨a,b,slots⟩ : ∃ a b, g.inputs = [a,b] := by
        cases h : g.inputs with
        | nil => simp [h] at hlen
        | cons a mid => cases mid with
          | nil => simp [h] at hlen
          | cons b tail =>
            have empty : tail = [] := by
              apply List.length_eq_zero_iff.mp
              simpa [h] using hlen
            subst tail
            exact ⟨a,b,rfl⟩
      exact ⟨dao.1 g mem,a,b,slots,by simpa [slots] using dnd g mem,
        earlier a (by simp [slots]),earlier b (by simp [slots])⟩
    have cor (x : Fin 14 → Bool) : D.eval (List.ofFn x) = true ↔
        ∃ a b : Fin 7, (a = b ∨ a = b+1 ∨ a = b+3) ∧
          x (Fin.castAdd 7 a) = true ∧ x (Fin.natAdd 7 b) = true := by
      let X := Finset.univ.filter (fun a : Fin 7 => x (Fin.castAdd 7 a) = true)
      let Y := Finset.univ.filter (fun b : Fin 7 => x (Fin.natAdd 7 b) = true)
      let bits := Fin.append (fun a : Fin 7 => decide (a ∈ X)) (fun b : Fin 7 => decide (b ∈ Y))
      have eq : bits = x := by
        funext i
        refine Fin.addCases (fun a => ?_) (fun b => ?_) i
        · unfold bits
          rw [Fin.append_left]
          simp [X]
        · unfold bits
          rw [Fin.append_right]
          simp [Y]
      have input : List.ofFn bits = incidenceInput X Y := List.ofFn_fin_append ..
      rw [eq] at input
      rw [deval, agrees, input, computes]
      change decide (∃ a ∈ X, ∃ b ∈ Y, a ∈ fanoLines b) = true ↔ _
      simp only [decide_eq_true_eq, X, Y, Finset.mem_filter, Finset.mem_univ, true_and, fp]
      constructor
      · rintro ⟨a,xa,b,xb,ab⟩
        exact ⟨a,b,ab,xa,xb⟩
      · rintro ⟨a,b,ab,xa,xb⟩
        exact ⟨a,xa,b,xb,ab⟩
    have disj := PEqualNP.Outside.L_meta_2225 D p l ⟨by omega,gateShape,cor⟩ dtree ((fp p l).mp flag)
    change D.lineDeg 14 {p.val} ≤ 1 ∨ D.lineDeg 14 {7+l.val} ≤ 1 at disj
    rw [ddeg, ddeg] at disj
    omega
  · intro out
    intro C p l small ao nd computes flag pd ld
    rcases out C p l small ao nd computes flag with hp | hl <;> omega

abbrev PostedStatement : Prop :=
have x1 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → Prop → Prop → Prop := fun (x1 x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x3 x4 : Prop) => x3 ∧ x4 ∧ ¬∃ (x5 : Fin (14 : ℕ)), x1 = PEqualNP.MetaComplexity.DMFormula.lit x5 Bool.true ∧ x2 = PEqualNP.MetaComplexity.DMFormula.lit x5 Bool.true; have x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → Prop := fun (x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) => PEqualNP.MetaComplexity.DMFormula.rec (fun (x3 : Fin (14 : ℕ)) (x4 : Bool) => x4 = Bool.true) x1 x1 x2; have x3 : ℕ → PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → ℕ := fun (x3 : ℕ) (x4 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) => PEqualNP.MetaComplexity.DMFormula.rec (fun (x5 : Fin (14 : ℕ)) (x6 : Bool) => if ↑x5 = x3 then (1 : ℕ) else (0 : ℕ)) (fun (x5 x6 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x7 x8 : ℕ) => x7 + x8) (fun (x5 x6 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x7 x8 : ℕ) => Max.max x7 x8) x4; ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit) (x5 x6 : Fin (7 : ℕ)), x4.size ≤ (27 : ℕ) → PEqualNP.TopForm.IsAO2 (14 : ℕ) x4 → (∀ x9 ∈ x4.gates, x9.inputs.Nodup) → PEqualNP.GenericRejection.ComputesIncidence PEqualNP.CircuitLowerBounds.fanoLines x4 → x5 ∈ PEqualNP.CircuitLowerBounds.fanoLines x6 → (2 : ℕ) ≤ x4.lineDeg (14 : ℕ) {↑x5} → (2 : ℕ) ≤ x4.lineDeg (14 : ℕ) {(7 : ℕ) + ↑x6} → ∃ (x14 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)), x2 x14 ∧ x14.leaves ≤ (28 : ℕ) ∧ (∀ (x15 : Fin (14 : ℕ) → Bool), x14.eval x15 = x4.eval (List.ofFn x15)) ∧ (2 : ℕ) ≤ x3 (↑x5) x14 ∧ (2 : ℕ) ≤ x3 ((7 : ℕ) + ↑x6) x14

theorem exactBudget : PostedStatement = WithGateBudget 27 := rfl

theorem flagEquivalence : PostedStatement ↔
    ∀ (C : Circuit) (p l : Fin 7), C.size ≤ 27 → IsAO2 14 C →
      (∀ g ∈ C.gates, g.inputs.Nodup) → ComputesIncidence fanoLines C →
      p ∈ fanoLines l → C.lineDeg 14 {p.val} ≤ 1 ∨ C.lineDeg 14 {7 + l.val} ≤ 1 :=
  budgetEquivalence 27

end FlagEquivalence
