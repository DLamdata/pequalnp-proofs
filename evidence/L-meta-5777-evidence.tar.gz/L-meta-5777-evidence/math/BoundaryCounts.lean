import PEqualNP.Defs
import Mathlib.Data.Finset.Card

open PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection

namespace BoundaryCounts

abbrev Side := Finset (Fin 7)

def incidentRows : Finset (Fin 7 × Fin 7) :=
  Finset.univ.filter fun t => t.1 ∈ fanoLines t.2

def maxY (X : Side) : Side := Finset.univ.filter fun l => Disjoint (fanoLines l) X

theorem maxY_eq {X Y : Side} (maximal : IsMaximalFalse fanoLines X Y) : Y = maxY X := by
  ext l
  simp only [maxY, Finset.mem_filter, Finset.mem_univ, true_and]
  refine ⟨maximal.1 l,?_⟩
  intro dis
  by_contra h
  apply maximal.2.2 l h
  intro k hk
  rcases Finset.mem_insert.mp hk with rfl|mem
  · exact dis
  · exact maximal.1 k mem

def closedXs : Finset Side := Finset.univ.filter fun X => IsMaximalFalse fanoLines X (maxY X)

def negativeRows : Finset (Side × Side) := closedXs.image fun X => (X, maxY X)

theorem mem_negativeRows (X Y : Side) :
    (X,Y) ∈ negativeRows ↔ IsMaximalFalse fanoLines X Y := by
  constructor
  · intro h
    obtain ⟨A,ha,eq⟩ := Finset.mem_image.mp h
    cases eq
    exact (Finset.mem_filter.mp ha).2
  · intro maximal
    have eq := maxY_eq maximal
    exact Finset.mem_image.mpr ⟨X,Finset.mem_filter.mpr ⟨Finset.mem_univ _,eq ▸ maximal⟩,by rw [eq]⟩

theorem positiveCount : incidentRows.card = 21 := by decide +kernel

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 60000 in
theorem negativeCount : negativeRows.card = 37 := by
  rw [negativeRows, Finset.card_image_of_injective _ (fun a b h => congrArg Prod.fst h)]
  decide +kernel

end BoundaryCounts

#print axioms BoundaryCounts.positiveCount
#print axioms BoundaryCounts.negativeCount
