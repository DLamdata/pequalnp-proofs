import BoundaryLift
import BoundaryCounts

open PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection PEqualNP.TopForm

namespace BoundarySuffices

theorem boundaryIff (D : Circuit) (hD : ∀ g ∈ D.gates, g.op = GateOp.and ∨ g.op = GateOp.or) :
    ComputesIncidence fanoLines D ↔
      (∀ p l : Fin 7, p ∈ fanoLines l → D.eval (incidenceInput {p} {l}) = true) ∧
      (∀ X Y : BoundaryLift.Part, IsMaximalFalse fanoLines X Y →
        D.eval (incidenceInput X Y) = false) := by
  constructor
  · intro computes
    constructor
    · intro p l edge; rw [computes]; simp [incidenceFun,edge]
    · intro X Y maximal; rw [computes]; exact (BoundaryLift.negative_iff X Y).mpr maximal.1
  · rintro ⟨pos,neg⟩ X Y
    cases h : incidenceFun fanoLines X Y with
    | true =>
      obtain ⟨p,hp,l,hl,edge⟩ := of_decide_eq_true h
      exact BoundaryLift.monoIn D hD (Finset.singleton_subset_iff.mpr hp)
        (Finset.singleton_subset_iff.mpr hl) (pos p l edge)
    | false =>
      let P (s : BoundaryLift.Part × BoundaryLift.Part) := IsFalseInput fanoLines s.1 s.2
      have orig : P (X,Y) := (BoundaryLift.negative_iff X Y).mp h
      obtain ⟨⟨U,V⟩,hle,hm⟩ := Finite.exists_le_maximal (p := P) orig
      have maximal : IsMaximalFalse fanoLines U V := by
        refine ⟨hm.1,?_,?_⟩
        · intro p hpu add
          have down : (insert p U,V) ≤ (U,V) := hm.2 (show P (insert p U,V) from add)
            ⟨Finset.subset_insert _ _,le_rfl⟩
          exact hpu (down.1 (Finset.mem_insert_self ..))
        · intro l hlv add
          have down : (U,insert l V) ≤ (U,V) := hm.2 (show P (U,insert l V) from add)
            ⟨le_rfl,Finset.subset_insert _ _⟩
          exact hlv (down.2 (Finset.mem_insert_self ..))
      cases hd : D.eval (incidenceInput X Y) with
      | false => rfl
      | true =>
        have ht := BoundaryLift.monoIn D hD hle.1 hle.2 hd
        rw [neg U V maximal] at ht
        contradiction

theorem finiteTable (D : Circuit) (hD : IsAO2 14 D) :
    ComputesIncidence fanoLines D ↔
      (∀ t ∈ BoundaryCounts.incidentRows, D.eval (incidenceInput {t.1} {t.2}) = true) ∧
      (∀ t ∈ BoundaryCounts.negativeRows, D.eval (incidenceInput t.1 t.2) = false) := by
  rw [boundaryIff D hD.1]
  constructor
  · rintro ⟨pos,neg⟩
    exact ⟨fun t h => pos _ _ (Finset.mem_filter.mp h).2,
      fun t h => neg _ _ ((BoundaryCounts.mem_negativeRows ..).mp h)⟩
  · rintro ⟨pos,neg⟩
    exact ⟨fun p l h => pos (p,l) (Finset.mem_filter.mpr ⟨Finset.mem_univ _,h⟩),
      fun X Y h => neg (X,Y) ((BoundaryCounts.mem_negativeRows ..).mpr h)⟩

end BoundarySuffices

#print axioms BoundarySuffices.finiteTable
