import Mathlib
import PEqualNP.Defs

-- Gate monotonicity follows the proof in PEqualNP.Outside.L_meta_1723.
namespace BoundaryLift

open PEqualNP.CircuitLowerBounds

def stp (w : List Bool) (g : Gate) : List Bool :=
  w ++ [g.op.eval (g.inputs.map fun i => w.getD i false)]

theorem eval_eq (C : Circuit) (x : List Bool) :
    C.eval x = (C.gates.foldl stp x).getD C.output false := rfl

theorem getD_snoc (W : List Bool) (v : Bool) (i : ℕ) :
    (W ++ [v]).getD i false = if i = W.length then v else W.getD i false := by
  rcases lt_trichotomy i W.length with h | h | h
  · rw [if_neg (by omega)]
    simp [List.getD_eq_getElem?_getD, List.getElem?_append_left h]
  · subst h
    simp [List.getD_eq_getElem?_getD]
  · rw [if_neg (by omega)]
    rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD,
      List.getElem?_eq_none (by simp; omega), List.getElem?_eq_none (by omega)]

theorem ev_and (g : Gate) (f : ℕ → Bool) (h : g.op = GateOp.and) :
    (g.op.eval (g.inputs.map f) = true ↔ ∀ i ∈ g.inputs, f i = true) := by
  rw [h]
  simp [GateOp.eval]

theorem ev_or (g : Gate) (f : ℕ → Bool) (h : g.op = GateOp.or) :
    (g.op.eval (g.inputs.map f) = true ↔ ∃ i ∈ g.inputs, f i = true) := by
  rw [h]
  simp [GateOp.eval]

theorem mono : ∀ (gs : List Gate) (W1 W2 : List Bool), W1.length = W2.length →
    (∀ g ∈ gs, g.op = GateOp.and ∨ g.op = GateOp.or) →
    (∀ i, W1.getD i false = true → W2.getD i false = true) →
    ∀ i, (gs.foldl stp W1).getD i false = true → (gs.foldl stp W2).getD i false = true := by
  intro gs
  induction gs with
  | nil => intro W1 W2 _ _ H; simpa using H
  | cons g gs ih =>
    intro W1 W2 hl hop H
    rw [List.foldl_cons, List.foldl_cons]
    apply ih (stp W1 g) (stp W2 g) (by simp [stp, hl])
      (fun g' hg' => hop g' (List.mem_cons_of_mem _ hg'))
    intro i
    simp only [stp, getD_snoc, hl]
    split_ifs
    · rcases hop g List.mem_cons_self with ha | ho
      · rw [ev_and g _ ha, ev_and g _ ha]
        intro h k hk
        exact H k (h k hk)
      · rw [ev_or g _ ho, ev_or g _ ho]
        rintro ⟨k, hk, h⟩
        exact ⟨k, hk, H k h⟩
    · exact H i

theorem ofFn_getD {n : ℕ} (x : Fin n → Bool) (i : ℕ) :
    (List.ofFn x).getD i false = if h : i < n then x ⟨i, h⟩ else false := by
  rw [List.getD_eq_getElem?_getD]
  split_ifs with h
  · rw [List.getElem?_eq_getElem (by simpa using h)]
    simp
  · rw [List.getElem?_eq_none (by simpa using h)]
    rfl

theorem eval_mono_fn {n : ℕ} (gates : List Gate)
    (hg : ∀ g ∈ gates, g.op = GateOp.and ∨ g.op = GateOp.or)
    (x y : Fin n → Bool) (hxy : ∀ v, x v = true → y v = true) (o : ℕ)
    (h : Circuit.eval ⟨gates, o⟩ (List.ofFn x) = true) :
    Circuit.eval ⟨gates, o⟩ (List.ofFn y) = true := by
  rw [eval_eq] at h ⊢
  refine mono gates _ _ (by simp) hg ?_ o h
  intro i
  rw [ofFn_getD, ofFn_getD]
  split_ifs with hi
  · exact hxy _
  · exact id

open PEqualNP.GenericRejection
abbrev Part := Finset (Fin 7)
def bits (X Y : Part) : Fin 14 → Bool :=
  Fin.append (fun a => decide (a ∈ X)) (fun b => decide (b ∈ Y))
theorem ofFn_bits (X Y : Part) : List.ofFn (bits X Y) = incidenceInput X Y :=
  List.ofFn_fin_append ..
theorem represents (x : Fin 14 → Bool) : ∃ X Y : Part, bits X Y = x := by
  refine ⟨Finset.univ.filter (fun a => x (Fin.castAdd 7 a) = true),
    Finset.univ.filter (fun b => x (Fin.natAdd 7 b) = true), ?_⟩
  funext i
  induction i using Fin.addCases (m := 7) (n := 7) with
  | left a => simp [bits]
  | right b => unfold bits; rw [Fin.append_right]; simp

theorem monoIn (D : Circuit) (hD : ∀ g ∈ D.gates, g.op = GateOp.and ∨ g.op = GateOp.or)
    {X Y X' Y' : Part} (hx : X ⊆ X') (hy : Y ⊆ Y')
    (v : D.eval (incidenceInput X Y) = true) : D.eval (incidenceInput X' Y') = true := by
  rw [← ofFn_bits] at v ⊢
  refine eval_mono_fn D.gates hD _ _ ?_ D.output v
  intro i
  induction i using Fin.addCases (m := 7) (n := 7) with
  | left a => unfold bits; rw [Fin.append_left, Fin.append_left]; simpa using hx (x := a)
  | right b => unfold bits; rw [Fin.append_right, Fin.append_right]; simpa using hy (x := b)

theorem negative_iff (X Y : Part) :
    incidenceFun fanoLines X Y = false ↔ IsFalseInput fanoLines X Y := by
  change decide (∃ p ∈ X, ∃ l ∈ Y, p ∈ fanoLines l) = false ↔ _
  simp only [decide_eq_false_iff_not, IsFalseInput, Finset.disjoint_left]
  grind

theorem lostPositive (C D : Circuit) (hC : ComputesIncidence fanoLines C)
    (hD : ∀ g ∈ D.gates, g.op = GateOp.and ∨ g.op = GateOp.or)
    (x : Fin 14 → Bool) (pos : C.eval (List.ofFn x) = true)
    (lost : D.eval (List.ofFn x) = false) :
    ∃ p l : Fin 7, p ∈ fanoLines l ∧
      C.eval (incidenceInput {p} {l}) = true ∧ D.eval (incidenceInput {p} {l}) = false := by
  obtain ⟨X,Y,rfl⟩ := represents x
  rw [ofFn_bits, hC] at pos
  rw [ofFn_bits] at lost
  obtain ⟨p,hp,l,hl,flag⟩ := of_decide_eq_true pos
  refine ⟨p,l,flag,?_,?_⟩
  · rw [hC]; simp [incidenceFun,flag]
  · cases hv : D.eval (incidenceInput {p} {l}) with
    | false => rfl
    | true =>
      have absurd := monoIn D hD (Finset.singleton_subset_iff.mpr hp)
        (Finset.singleton_subset_iff.mpr hl) hv
      simp [lost] at absurd

theorem gainedFalse (C D : Circuit) (hC : ComputesIncidence fanoLines C)
    (hD : ∀ g ∈ D.gates, g.op = GateOp.and ∨ g.op = GateOp.or)
    (x : Fin 14 → Bool) (neg : C.eval (List.ofFn x) = false)
    (gained : D.eval (List.ofFn x) = true) :
    ∃ X Y : Part, IsMaximalFalse fanoLines X Y ∧
      C.eval (incidenceInput X Y) = false ∧ D.eval (incidenceInput X Y) = true := by
  obtain ⟨X,Y,rfl⟩ := represents x
  rw [ofFn_bits, hC] at neg
  rw [ofFn_bits] at gained
  let P (v : Part × Part) := IsFalseInput fanoLines v.1 v.2
  have orig : P (X,Y) := (negative_iff X Y).mp neg
  obtain ⟨⟨U,V⟩, hle, hm⟩ := Finite.exists_le_maximal (p := P) orig
  refine ⟨U,V,⟨hm.1,?_,?_⟩, ?_, monoIn D hD hle.1 hle.2 gained⟩
  · intro p hpu add
    have down : (insert p U,V) ≤ (U,V) := hm.2 (show P (insert p U,V) from add) ⟨Finset.subset_insert _ _,le_rfl⟩
    exact hpu (down.1 (Finset.mem_insert_self ..))
  · intro l hlv add
    have down : (U,insert l V) ≤ (U,V) := hm.2 (show P (U,insert l V) from add) ⟨le_rfl,Finset.subset_insert _ _⟩
    exact hlv (down.2 (Finset.mem_insert_self ..))
  · rw [hC]
    exact (negative_iff U V).mpr hm.1

end BoundaryLift
