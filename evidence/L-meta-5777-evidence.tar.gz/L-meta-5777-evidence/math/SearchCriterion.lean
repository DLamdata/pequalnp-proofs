import CanonicalFlag
import BoundarySuffices

open PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection PEqualNP.TopForm

namespace FlagEquivalence

def SearchWitness (C : Circuit) : Prop :=
  C.size = 27 ∧ C.output = 40 ∧ IsAO2 14 C ∧ (∀ g ∈ C.gates, g.inputs.Nodup) ∧
  (∀ t ∈ BoundaryCounts.incidentRows, C.eval (incidenceInput {t.1} {t.2}) = true) ∧
  (∀ t ∈ BoundaryCounts.negativeRows, C.eval (incidenceInput t.1 t.2) = false) ∧
  2 ≤ C.lineDeg 14 {0} ∧ 2 ≤ C.lineDeg 14 {7}

theorem exactSearch : PostedStatement ↔ ¬∃ C : Circuit, SearchWitness C := by
  rw [canonicalIff]
  constructor
  · rintro noEligible ⟨C,small,_,ao,nd,pos,neg,pdeg,ldeg⟩
    exact noEligible ⟨C,toEligible C (by omega) ao nd ((BoundarySuffices.finiteTable C ao).2 ⟨pos,neg⟩),pdeg,ldeg⟩
  · rintro noSearch ⟨C,eligible,pdeg,ldeg⟩
    obtain ⟨ao,nd,computes⟩ := fromEligible C eligible
    have sz := liveObstruction C 0 0 eligible.1 ao nd computes (by decide) pdeg ldeg
    obtain ⟨pos,neg⟩ := (BoundarySuffices.finiteTable C ao).1 computes
    exact noSearch ⟨C,sz.1,sz.2.1,ao,nd,pos,neg,pdeg,ldeg⟩

end FlagEquivalence

#print axioms FlagEquivalence.exactSearch
