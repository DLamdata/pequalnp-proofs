#!/usr/bin/env bash
set -eu
record=$(cd "$(dirname "$0")" && pwd)
checkout=$(git -C "${1:-/workspace/pequalnp-proofs}" rev-parse --show-toplevel)
export PEQUALNP_HOME="${PEQUALNP_HOME:-/workspace/.pequalnp-build}"
export MATHLIB_CACHE_DIR="${MATHLIB_CACHE_DIR:-/workspace/.pequalnp-cache}"
export PATH="$checkout/tools/bin:$PATH"
cd "$checkout/lean"
lake build +PEqualNP.Defs
bash "$record/math/replay.sh" "$checkout"
bash "$record/math/replay-boundary.sh" "$checkout"
bash "$record/formulas/replay_bounds.sh" "$checkout"
bash "$record/cut/replay.sh" "$checkout"
cd "$record/search"
python3 audit.py
