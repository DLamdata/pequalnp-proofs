# Loogle and pinned-library checks for L-meta-5777

The checkout was at `7c4efd6d7efbd8a5b701c1c3405343b01acf5fac` when these notes were saved. In this task, the Mathlib dependency was `fc4f59e577feb1a4956671bc04ac18aaaf8cd842` and the pinned Lean version was 4.36.0.

| Query to Loogle | Returned declaration |
|---|---|
| `List.Nodup, List.flatMap` | `List.nodup_flatMap` |
| `List.ofFn_fin_append` | `List.ofFn_fin_append` |
| `Fin.append_left` | `Fin.append_left` |
| `Nat.max_le` | `Nat.max_le` |
| `List.getElem?_eq_some_iff` | `List.getElem?_eq_some_iff` |
| `Finset.card_le_one` | `Finset.card_le_one` |
| `PEqualNP.MetaComplexity.DMFormula` | Loogle reported an unknown identifier. The declaration is in the project. |

Each successful lookup returned one declaration. The following commands reproduce the lookups and the `#check` calls. The recorded results above summarize the tool output.

```bash
cd /workspace/pequalnp-proofs/lean
for q in 'List.Nodup, List.flatMap' 'List.ofFn_fin_append' 'Fin.append_left' 'Nat.max_le' 'List.getElem?_eq_some_iff' 'Finset.card_le_one' 'PEqualNP.MetaComplexity.DMFormula'
do
  curl -fsS -G https://loogle.lean-lang.org/json --data-urlencode "q=$q" | jq '{count,error,hits:[.hits[]?.name]}'
done
lake env lean --stdin <<'LEAN'
import Mathlib
#check Nat.max_le
#check List.ofFn_fin_append
#check Fin.append_left
#check List.nodup_flatMap
#check List.getElem?_eq_some_iff
#check Finset.card_le_one
LEAN
```

The local check exited successfully. In particular, `List.nodup_flatMap` characterizes distinctness of a concatenation by distinctness inside each list and pairwise disjointness between lists. Distinct operands within every gate permit the same gate output to be used by two different gates. The tree-unfolding lemma in `L_meta_2225` additionally counts output-wire usage and requires distinctness among all uses of gate wires.

The accepted file `L_meta_17415` rules out a dual-high-degree incident pair under an additional requirement on every AND gate's two-bit tests. It assumes that whenever such a gate accepts a two-bit input, the circuit accepts it. The accepted file `L_meta_9442` gives the exact relevant lower bound of 27 gates on the Fano incidence function. The statement of L-meta-5777 permits equality at that bound. `L_meta_5775` compiles formulas into tree circuits and `R_meta_2223_607` uses L-meta-5777's statement in the converse direction.
