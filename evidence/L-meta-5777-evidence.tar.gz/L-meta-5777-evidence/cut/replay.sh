#!/usr/bin/env bash
set -eu
bundle=$(cd "$(dirname "$0")" && pwd)
checkout=$(git -C "${1:-.}" rev-parse --show-toplevel)
cd "$checkout/lean"
lake build +PEqualNP.Defs checklemma
test -f .lake/build/lib/lean/PEqualNP/Defs.olean
stage=$(mktemp -d)
trap 'rm -rf -- "$stage"' EXIT
mod=R_meta_5777_413
mkdir -p "$stage/src/PEqualNP/Outside" "$stage/out/PEqualNP/Outside"
cp "$bundle/$mod.lean" "$stage/src/PEqualNP/Outside/"
lake env lean --root="$stage/src" -o "$stage/out/PEqualNP/Outside/$mod.olean" "$stage/src/PEqualNP/Outside/$mod.lean"
for f in "$PWD"/.lake/build/lib/lean/PEqualNP/*; do
  if [[ "${f##*/}" != Outside ]]; then ln -s "$f" "$stage/out/PEqualNP/"; fi
done
lake env sh -c 'export LEAN_PATH="$1:$LEAN_PATH"; exec .lake/build/bin/checklemma "$2" "$3" reduce' sh "$stage/out" "PEqualNP.Outside.$mod" "$bundle/statement.txt"
lake env lean --root="$bundle" -o "$stage/out/GenericUnfold.olean" "$bundle/GenericUnfold.lean"
lake env sh -c 'export LEAN_PATH="$1:$LEAN_PATH"; exec lean --root="$2" -o "$1/Remaining.olean" "$2/Remaining.lean"' sh "$stage/out" "$bundle"
lake env sh -c 'export LEAN_PATH="$1:$LEAN_PATH"; exec lean --stdin' sh "$stage/out" <<'LEAN'
import Remaining
#print axioms Fano5777Unfold.exactChild
#print axioms Fano5777Unfold.fromDescent
LEAN
