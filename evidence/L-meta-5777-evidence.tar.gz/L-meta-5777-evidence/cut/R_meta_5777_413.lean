import Mathlib
import PEqualNP.Defs

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.GenericRejection PEqualNP.TopForm

theorem PEqualNP.Outside.R_meta_5777_413
    (tree :
      let cost := fun (C : Circuit) => (C.gates.foldl (fun (v : List ℕ) g =>
        v ++ [(g.inputs.map (fun i => v.getD i 0)).sum]) (List.replicate 14 1)).getD C.output 29
      let branch := fun (a b : DMFormula 14) (x y : Prop) =>
        x ∧ y ∧ ¬ ∃ i, a = DMFormula.lit i true ∧ b = DMFormula.lit i true
      let good := fun (t : DMFormula 14) => DMFormula.rec (motive := fun _ : DMFormula 14 => Prop)
        (fun _ sign => sign = true) branch branch t
      let deg := fun (k : ℕ) (t : DMFormula 14) =>
        DMFormula.rec (motive := fun _ : DMFormula 14 => ℕ)
          (fun i _ => if i.val = k then 1 else 0)
          (fun _ _ a b => a+b) (fun _ _ a b => max a b) t
      ∀ D : Circuit, IsAO2 14 D → (∀ g ∈ D.gates, g.inputs.Nodup) → cost D ≤ 28 →
        ∃ t : DMFormula 14, good t ∧ t.leaves = cost D ∧
          (∀ x, t.eval x = D.eval (List.ofFn x)) ∧ ∀ k, deg k t = D.lineDeg 14 {k})
    (improve :
      let cost := fun (C : Circuit) => (C.gates.foldl (fun (v : List ℕ) g =>
        v ++ [(g.inputs.map (fun i => v.getD i 0)).sum]) (List.replicate 14 1)).getD C.output 29
      ∀ (C : Circuit) (p l : Fin 7), C.size ≤ 27 → IsAO2 14 C →
        (∀ g ∈ C.gates, g.inputs.Nodup) → ComputesIncidence fanoLines C →
        p ∈ fanoLines l → 2 ≤ C.lineDeg 14 {p.val} → 2 ≤ C.lineDeg 14 {7+l.val} →
        28 < cost C → ∃ D : Circuit, D.size ≤ 27 ∧ IsAO2 14 D ∧
          (∀ g ∈ D.gates, g.inputs.Nodup) ∧
          (∀ x : List Bool, x.length = 14 → D.eval x = C.eval x) ∧
          2 ≤ D.lineDeg 14 {p.val} ∧ 2 ≤ D.lineDeg 14 {7+l.val} ∧ cost D < cost C) :
    (have x1 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → Prop → Prop → Prop := fun (x1 x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x3 x4 : Prop) => x3 ∧ x4 ∧ ¬∃ (x5 : Fin (14 : ℕ)), x1 = PEqualNP.MetaComplexity.DMFormula.lit x5 Bool.true ∧ x2 = PEqualNP.MetaComplexity.DMFormula.lit x5 Bool.true; have x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → Prop := fun (x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) => PEqualNP.MetaComplexity.DMFormula.rec (fun (x3 : Fin (14 : ℕ)) (x4 : Bool) => x4 = Bool.true) x1 x1 x2; have x3 : ℕ → PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → ℕ := fun (x3 : ℕ) (x4 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) => PEqualNP.MetaComplexity.DMFormula.rec (fun (x5 : Fin (14 : ℕ)) (x6 : Bool) => if ↑x5 = x3 then (1 : ℕ) else (0 : ℕ)) (fun (x5 x6 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x7 x8 : ℕ) => x7 + x8) (fun (x5 x6 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x7 x8 : ℕ) => Max.max x7 x8) x4; ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit) (x5 x6 : Fin (7 : ℕ)), x4.size ≤ (27 : ℕ) → PEqualNP.TopForm.IsAO2 (14 : ℕ) x4 → (∀ x9 ∈ x4.gates, x9.inputs.Nodup) → PEqualNP.GenericRejection.ComputesIncidence PEqualNP.CircuitLowerBounds.fanoLines x4 → x5 ∈ PEqualNP.CircuitLowerBounds.fanoLines x6 → (2 : ℕ) ≤ x4.lineDeg (14 : ℕ) {↑x5} → (2 : ℕ) ≤ x4.lineDeg (14 : ℕ) {(7 : ℕ) + ↑x6} → ∃ (x14 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)), x2 x14 ∧ x14.leaves ≤ (28 : ℕ) ∧ (∀ (x15 : Fin (14 : ℕ) → Bool), x14.eval x15 = x4.eval (List.ofFn x15)) ∧ (2 : ℕ) ≤ x3 (↑x5) x14 ∧ (2 : ℕ) ≤ x3 ((7 : ℕ) + ↑x6) x14) := by
  let cost := fun (C : Circuit) => (C.gates.foldl (fun (v : List ℕ) g =>
        v ++ [(g.inputs.map (fun i => v.getD i 0)).sum]) (List.replicate 14 1)).getD C.output 29
  dsimp only
  intro C p l
  generalize hmeasure : cost C = m
  induction m using Nat.strong_induction_on generalizing C with
  | ind m ih =>
    intro hsize hao hnd hinc hflag hp hl
    by_cases hsmall : cost C ≤ 28
    · obtain ⟨t, hg, hleaves, heval, hdeg⟩ := tree C hao hnd hsmall
      exact ⟨t, hg, hleaves.trans_le hsmall, heval, hp.trans_eq (hdeg p.val).symm, hl.trans_eq (hdeg (7+l.val)).symm⟩
    · obtain ⟨D, hds, hdao, hdnd, hsame, hdp, hdl, hlt⟩ :=
        improve C p l hsize hao hnd hinc hflag hp hl (Nat.lt_of_not_ge hsmall)
      have hdinc : ComputesIncidence fanoLines D := by
        intro X Y
        have hlen : (incidenceInput X Y).length = 14 := by
          change (List.ofFn (fun p : Fin 7 => decide (p ∈ X)) ++ List.ofFn (fun l : Fin 7 => decide (l ∈ Y))).length = 14
          simp
        rw [hsame (incidenceInput X Y) hlen]
        exact hinc X Y
      obtain ⟨t, hg, hs, heval, ht1, ht2⟩ :=
        ih (cost D) (hmeasure ▸ hlt) D rfl hds hdao hdnd hdinc hflag hdp hdl
      exact ⟨t, hg, hs, fun x => (heval x).trans (hsame _ (by simp)), ht1, ht2⟩
