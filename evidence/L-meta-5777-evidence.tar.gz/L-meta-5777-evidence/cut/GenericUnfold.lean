import Mathlib
import PEqualNP.Defs

-- The wire-table induction is adapted from L_meta_2225.lean in open-goat/pequalnp-proofs.
-- It records exact unfolded cost, local literal distinctness, and degrees for all natural indices.
namespace Fano5777Unfold
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.TopForm

noncomputable def degree {n : ℕ} (i : ℕ) (F : DMFormula n) : ℕ :=
  DMFormula.rec (motive := fun _ => ℕ) (fun j _ => if j.val = i then 1 else 0)
    (fun _ _ a b => a + b) (fun _ _ a b => max a b) F

noncomputable def good {n : ℕ} (F : DMFormula n) : Prop :=
  let branch := fun (a b : DMFormula n) (x y : Prop) =>
    x ∧ y ∧ ¬ ∃ i, a = DMFormula.lit i true ∧ b = DMFormula.lit i true
  DMFormula.rec (motive := fun _ : DMFormula n => Prop) (fun _ sign => sign = true) branch branch F

def paths (n : ℕ) (gs : List Gate) : List ℕ :=
  gs.foldl (fun (v : List ℕ) g => v ++ [(g.inputs.map (fun i => v.getD i 0)).sum]) (List.replicate n 1)

private def shaped (n : ℕ) (gs : List Gate) : Prop :=
  ∀ j g, gs[j]? = some g →
    (g.op = GateOp.and ∨ g.op = GateOp.or) ∧
    ∃ a b, g.inputs = [a,b] ∧ a ≠ b ∧ a < n+j ∧ b < n+j

private theorem getMap {n : ℕ} {α : Type} {T : List (DMFormula n)} {i : ℕ} {F : DMFormula n}
    (h : T[i]? = some F) (f : DMFormula n → α) (base : α) :
    (T.map f).getD i base = f F := by
  simp [List.getD_eq_getElem?_getD, List.getElem?_map, h]

private theorem expandAll (n : ℕ) (gs : List Gate) (ok : shaped n gs) :
    ∃ T : List (DMFormula n), T.length = n + gs.length ∧
      (∀ (i : ℕ) (F : DMFormula n), T[i]? = some F → good F) ∧
      (∀ (j : ℕ) (i : Fin n), T[j]? = some (DMFormula.lit i true) → j = i.val) ∧
      (∀ x, T.map (fun F => F.eval x) = (Circuit.mk gs 0).wires (List.ofFn x)) ∧
      (∀ i : ℕ, T.map (degree i) = (Circuit.mk gs 0).lineDegrees n {i}) ∧
      T.map DMFormula.leaves = paths n gs := by
  induction gs using List.reverseRecOn with
  | nil =>
    let T := List.ofFn (fun i : Fin n => DMFormula.lit i true)
    refine ⟨T, by simp [T], ?_, ?_, ?_, ?_, ?_⟩
    · intro i F hi
      obtain ⟨bound, rfl⟩ := List.getElem?_eq_some_iff.mp hi
      have payload : T[i] = DMFormula.lit ⟨i, by simpa [T] using bound⟩ true := by simp [T]
      rw [payload]
      rfl
    · intro j i hj
      obtain ⟨bound, eqn⟩ := List.getElem?_eq_some_iff.mp hj
      simp [T] at eqn
      exact congrArg Fin.val eqn
    · intro x
      simp [T, Circuit.wires, Function.comp_def, DMFormula.eval]
    · intro i
      apply List.ext_getElem
      · simp [Circuit.lineDegrees, T]
      · intro j hj hj'
        simp only [Circuit.lineDegrees, List.foldl_nil]
        rw [List.getElem_map, List.getElem_map]
        have jT : j < T.length := by simpa using hj
        have eqn : T[j]'jT = DMFormula.lit ⟨j, by simpa [T] using jT⟩ true := by simp [T]
        rw [eqn]
        simp [degree, List.getElem_range]
    · simp [T, paths, Function.comp_def, DMFormula.leaves]
  | append_singleton gs g ih =>
    have early : shaped n gs := by
      intro j h atj
      have bound := (List.getElem?_eq_some_iff.mp atj).choose
      apply ok j h
      rwa [List.getElem?_append_left bound]
    obtain ⟨T, len, pos, index, evals, degs, costs⟩ := ih early
    have gateAt : (gs ++ [g])[gs.length]? = some g := by simp
    obtain ⟨operator, a, b, inputs, hab, ha, hb⟩ := ok gs.length g gateAt
    have ba : a < T.length := len.symm ▸ ha
    have bb : b < T.length := len.symm ▸ hb
    let A := T[a]
    let B := T[b]
    have aAt : T[a]? = some A := List.getElem?_eq_getElem ba
    have bAt : T[b]? = some B := List.getElem?_eq_getElem bb
    let F := match g.op with
      | GateOp.and => DMFormula.and A B
      | _ => DMFormula.or A B
    have noDup : ¬ ∃ i, A = DMFormula.lit i true ∧ B = DMFormula.lit i true := by
      rintro ⟨i, hai, hbi⟩
      exact hab ((index a i (aAt.trans (congrArg some hai))).trans (index b i (bAt.trans (congrArg some hbi))).symm)
    have posF : good F := by
      rcases operator with op | op <;>
        simpa [F, op, good] using And.intro (pos a A aAt) (And.intro (pos b B bAt) noDup)
    refine ⟨T ++ [F], by simp [len, Nat.add_assoc], ?_, ?_, ?_, ?_, ?_⟩
    · intro j H h
      by_cases before : j < T.length
      · rw [List.getElem?_append_left before] at h
        exact pos j H h
      · have inside := (List.getElem?_eq_some_iff.mp h).choose
        have equality : j = T.length := by simp at inside; omega
        subst j
        simp only [List.getElem?_append_right (Nat.le_refl _), Nat.sub_self,
          List.getElem?_cons_zero, Option.some.injEq] at h
        exact h ▸ posF
    · intro j i h
      by_cases before : j < T.length
      · rw [List.getElem?_append_left before] at h
        exact index j i h
      · have inside := (List.getElem?_eq_some_iff.mp h).choose
        have equality : j = T.length := by simp at inside; omega
        subst j
        rcases operator with op | op <;> simp [F, op] at h
    · intro x
      simp only [List.map_append, List.map_cons, List.map_nil]
      have unfoldStep :
          (Circuit.mk (gs ++ [g]) 0).wires (List.ofFn x) =
            (Circuit.mk gs 0).wires (List.ofFn x) ++
              [g.op.eval (g.inputs.map fun j => ((Circuit.mk gs 0).wires (List.ofFn x)).getD j false)] := by
        simp [Circuit.wires, List.foldl_append]
      rw [unfoldStep, ← evals x, inputs]
      simp only [List.map_cons, List.map_nil, getMap aAt, getMap bAt]
      rcases operator with op | op <;> simp [F, op, DMFormula.eval, GateOp.eval]
    · intro i
      simp only [List.map_append, List.map_cons, List.map_nil]
      have unfoldStep :
          (Circuit.mk (gs ++ [g]) 0).lineDegrees n {i} =
            (Circuit.mk gs 0).lineDegrees n {i} ++
              [g.lineDegree ((Circuit.mk gs 0).lineDegrees n {i})] := by
        simp [Circuit.lineDegrees, List.foldl_append]
      rw [unfoldStep, ← degs i]
      rcases operator with op | op <;>
        simp [F, op, degree, Gate.lineDegree, inputs, List.getD_eq_getElem?_getD, aAt, bAt]

    · simp only [List.map_append, List.map_cons, List.map_nil]
      have unfoldStep : paths n (gs ++ [g]) = paths n gs ++ [(g.inputs.map (fun i => (paths n gs).getD i 0)).sum] := by
        simp [paths, List.foldl_append]
      rw [unfoldStep, ← costs, inputs]
      rcases operator with op | op <;> simp [F, op, DMFormula.leaves, aAt, bAt]

lemma shapeFromAO (n : ℕ) (C : Circuit) (hao : IsAO2 n C)
    (distinct : ∀ g ∈ C.gates, g.inputs.Nodup)
    (j : ℕ) (g : Gate) (hit : C.gates[j]? = some g) :
    (g.op = GateOp.and ∨ g.op = GateOp.or) ∧
      ∃ a b, g.inputs = [a, b] ∧ a ≠ b ∧ a < n + j ∧ b < n + j := by
  have mem := List.mem_of_getElem? hit
  have earlier (i : ℕ) (hi : i ∈ g.inputs) : i < n + j := by
    obtain ⟨bound, eq⟩ := List.getElem?_eq_some_iff.mp hit
    have lookup : PEqualNP.MetaComplexity.NestedCover.gateAt C j = g := by
      unfold PEqualNP.MetaComplexity.NestedCover.gateAt
      rw [List.getD_eq_getElem?_getD, hit]
      rfl
    exact hao.2.1 j bound i (lookup.symm ▸ hi)
  have len := hao.2.2 g mem
  obtain ⟨a, b, slots⟩ : ∃ a b, g.inputs = [a, b] := by
    cases h : g.inputs with
    | nil => simp [h] at len
    | cons a mid =>
      cases mid with
      | nil => simp [h] at len
      | cons b tail =>
        have empty : tail = [] := by
          apply List.length_eq_zero_iff.mp
          simpa [h] using len
        subst tail
        exact ⟨a, b, rfl⟩
  have ne : a ≠ b := by simpa [slots] using distinct g mem
  exact ⟨hao.1 g mem, a, b, slots, ne, earlier a (by simp [slots]), earlier b (by simp [slots])⟩

theorem unfoldValid (n : ℕ) (C : Circuit) (hao : IsAO2 n C)
    (hn : ∀ g ∈ C.gates, g.inputs.Nodup) (hout : C.output < n + C.gates.length) :
    ∃ F : DMFormula n, good F ∧ F.leaves = (paths n C.gates).getD C.output 0 ∧
      (∀ x, F.eval x = C.eval (List.ofFn x)) ∧ ∀ k, degree k F = C.lineDeg n {k} := by
  obtain ⟨T, len, goodAll, _, evals, degs, costs⟩ := expandAll n C.gates (shapeFromAO n C hao hn)
  have bound : C.output < T.length := len.symm ▸ hout
  let F := T[C.output]
  have found : T[C.output]? = some F := List.getElem?_eq_getElem bound
  refine ⟨F, goodAll _ _ found, ?_, ?_, ?_⟩
  · rw [← costs, getMap found]
  · intro x
    change F.eval x = ((Circuit.mk C.gates 0).wires (List.ofFn x)).getD C.output false
    rw [← evals, getMap found]
  · intro i
    change degree i F = ((Circuit.mk C.gates 0).lineDegrees n {i}).getD C.output 0
    rw [← degs, getMap found]

theorem genericUnfold :
      let cost := fun (C : Circuit) => (C.gates.foldl (fun (v : List ℕ) g =>
        v ++ [(g.inputs.map (fun i => v.getD i 0)).sum]) (List.replicate 14 1)).getD C.output 29
      let branch := fun (a b : DMFormula 14) (x y : Prop) =>
        x ∧ y ∧ ¬ ∃ i, a = DMFormula.lit i true ∧ b = DMFormula.lit i true
      let good := fun (t : DMFormula 14) => DMFormula.rec (motive := fun _ : DMFormula 14 => Prop)
        (fun _ sign => sign = true) branch branch t
      let deg := fun (k : ℕ) (t : DMFormula 14) =>
        DMFormula.rec (motive := fun _ : DMFormula 14 => ℕ)
          (fun i _ => if i.val = k then 1 else 0)
          (fun _ _ a b => a+b) (fun _ _ a b => max a b) t
      ∀ D : Circuit, IsAO2 14 D → (∀ g ∈ D.gates, g.inputs.Nodup) → cost D ≤ 28 →
        ∃ t : DMFormula 14, good t ∧ t.leaves = cost D ∧
          (∀ x, t.eval x = D.eval (List.ofFn x)) ∧ ∀ k, deg k t = D.lineDeg 14 {k} := by
  dsimp only
  intro C hao hn hcost
  obtain ⟨T, len, goodAll, _, evals, degs, costs⟩ := expandAll 14 C.gates (shapeFromAO 14 C hao hn)
  change (paths 14 C.gates).getD C.output 29 ≤ 28 at hcost
  have bound : C.output < T.length := by
    by_contra! h
    rw [← costs, List.getD_eq_default _ _ (by simpa using h)] at hcost
    omega
  let F := T[C.output]
  have found : T[C.output]? = some F := List.getElem?_eq_getElem bound
  refine ⟨F, goodAll _ _ found, ?_, ?_, ?_⟩
  · change F.leaves = (paths 14 C.gates).getD C.output 29
    rw [← costs, getMap found]
  · intro x
    change F.eval x = ((Circuit.mk C.gates 0).wires (List.ofFn x)).getD C.output false
    rw [← evals, getMap found]
  · intro i
    change degree i F = ((Circuit.mk C.gates 0).lineDegrees 14 {i}).getD C.output 0
    rw [← degs, getMap found]

end Fano5777Unfold
