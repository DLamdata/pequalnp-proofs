"""Independent frontier reachability check for four complete Fano stars.

Search uses no gate ordering or equal-row gate pruning. A frontier is a multiset,
so two equal descriptors can still denote different operands. Dynamic programming
quotients only by permutation of that frontier. The full-Fano lower bound is used
externally to justify the minimal residual with exactly its essential variables.
"""
from functools import cache
from itertools import combinations
from pathlib import Path
import sys

def solve(centers):
    fano = {(p,l+7) for p in range(7) for l in range(7) if (p-l)%7 in (0,1,3)}
    edges = [edge for edge in sorted(fano) if all((centers>>v)&1==0 for v in edge)]
    names = sorted({v for e in edges for v in e})
    n = len(names)
    edges = [sum(1<<names.index(v) for v in e) for e in edges]
    target = lambda x:any(x&e==e for e in edges)
    neg = [x for x in range(1<<n) if not target(x) and all(target(x|1<<i) for i in range(n) if not (x>>i)&1)]
    # One bit per (positive row, negative row) for the values of a given wire.
    rows = [(p,m) for p in edges for m in neg]
    goal=(1<<len(rows))-1
    wires=tuple(sorted((sum((p>>i&1)<<k for k,(p,m) in enumerate(rows)),
                        sum((m>>i&1)<<k for k,(p,m) in enumerate(rows)),1<<i,0)
                        for i in range(n)))
    @cache
    def search(g,state):
        if len(state)==1:
            p,m,one,two=state[0]
            return g==0 and p==goal and m==0 and target(two)
        if len(state)>g+1:return False
        cov=0
        for p,m,_,_ in state:cov |=p&~m
        if cov!=goal:return False
        for i,j in combinations(range(len(state)),2):
            p,q,u,v=state[i]
            h,k,y,z=state[j]
            unaffected=state[:i]+state[i+1:j]+state[j+1:]
            for new in ((p|h,q|k,u|y,v|z),(p&h,q&k,u|y,v|z|(u&y))):
                for keep in ((),(state[i],),(state[j],),(state[i],state[j])):
                    if len(unaffected)+len(keep)+1>g:continue
                    s=tuple(sorted(unaffected+(new,)+keep))
                    if search(g-1,s):return True
        return False
    ret=search(11,wires)
    print(centers,'double=',ret,'unique states=',search.cache_info().currsize,flush=True)
    search.cache_clear()
    return ret
if __name__=="__main__":
    args=[int(a) for a in sys.argv[1:]]
    for c in args: assert not solve(c)
