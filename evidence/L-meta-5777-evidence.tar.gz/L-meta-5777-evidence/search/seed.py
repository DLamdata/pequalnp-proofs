import re
from pathlib import Path

source = Path(__file__).resolve().parents[1] / "Fano28.source"
line = next(s for s in source.read_text().splitlines() if s.startswith("def W : Circuit"))
gates = re.findall(r"⟨\.(and|or), \[(\d+),(\d+)\]⟩", line)
assert len(gates) == 28 and line.endswith(", 41⟩")
for op, x, y in gates:
    print(int(op == "and"), int(x), int(y))
