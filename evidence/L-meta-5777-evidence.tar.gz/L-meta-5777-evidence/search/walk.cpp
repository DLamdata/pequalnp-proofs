// Stochastic local rewiring of 27-gate solutions and near-solutions.
// The ordinary star circuit is exact on every row. We test singleton
// degrees for all 21 flags, with saturation at 2 for each marked input.
#include "model.hpp"
#include <random>
struct Score { int cost, misses,flags; };
Score score(const Circuit& c){
    auto v=inputs;
    unsigned once[41]{},twice[41]{};
    for(int j=0;j<14;++j) once[j]=1u<<j;
    for(int j=0;j<27;++j){
        auto [op,a,b]=c[j];
        v[j+14]=op?v[a]&v[b]:v[a]|v[b];
        once[j+14]=once[a]|once[b];
        twice[j+14]=twice[a]|twice[b]|(op?(once[a]&once[b]):0);
    }
    int f=0;
    for(auto [p,l]:edges) f+=((twice[40]>>p)&(twice[40]>>l)&1u);
    int misses=popcount(v[40]^target);
    return {2*misses+(f==0?3:0),misses,f};
}
Circuit star(){
    Circuit c{};
    int j=0;
    vector<int> stars;
    for(int p=0;p<7;++p){
        vector<int> lines;
        for(auto [x,l]:edges) if(x==p) lines.push_back(l);
        c[j++]={0,lines[0],lines[1]};
        c[j]={0,14+j-1,lines[2]}; ++j;
        c[j]={1,p,14+j-1}; stars.push_back(14+j++);
    }
    int tail=stars[0];
    for(int i=1;i<7;++i){ c[j]={0,tail,stars[i]}; tail=14+j++; }
    assert(j==27&&tail==40);
    return c;
}
int main(int argc,char** argv){
    assert(argc==3);
    int seedNum=stoi(argv[1]),cycles=stoi(argv[2]);
    mt19937 rng(seedNum);
    auto seed=read_seed();
    Circuit near{};
    // Reconstruct the first flagged one-row miss reported by repair.cpp.
    for(int j=1;j<28;++j){
        auto [op,a,b]=seed[j];
        auto wire=[](int k){return k==14?0:k-(k>14);};
        near[j-1]={op,wire(a),wire(b)};
    }
    near[0]={1,0,7};
    assert(score(near).misses==1 && score(near).flags>0);
    auto exact=star();
    assert(score(exact).misses==0 && score(exact).flags==0);
    long long attempts=0, exactVisits=0, flaggedNear=0;
    int best=60;
    for(int cycle=0;cycle<cycles;++cycle){
        auto cur=(cycle%2?near:exact);
        auto s=score(cur);
        Circuit record=cur;
        int low=s.cost;
        for(int it=0;it<50000;++it){
            if(it && it%5000==0) {cur=record;s=score(cur);}
            auto trial=cur;
            int mutations=1+(rng()%16==0)+(rng()%64==0);
            for(int t=0;t<mutations;++t){
                int j=rng()%27;
                auto &g=trial[j];
                int choice=rng()%10;
                if(choice<2) g.op^=1;
                else {
                    int &slot=(choice&1)?g.a:g.b;
                    int other=(choice&1)?g.b:g.a;
                    do slot=rng()%(14+j); while(slot==other);
                }
            }
            auto next=score(trial); ++attempts;
            exactVisits+=next.misses==0;
            flaggedNear+=next.misses==1 && next.flags;
            if(next.flags && next.misses<best){
                best=next.misses;
                cout<<"seed "<<seedNum<<" attempt "<<attempts<<" best flagged errors "<<best<<endl;
            }
            if(next.flags && !next.misses){
                cout<<"WITNESS"<<endl;
                for(int j=0;j<27;++j) cout<<trial[j].op<<" "<<trial[j].a<<" "<<trial[j].b<<endl;
                return 0;
            }
            if(next.cost<=low){record=trial;low=next.cost;}
            int delta=next.cost-s.cost;
            // Cyclic temperature schedule. Neutral edits are always accepted.
            if(delta<=0 || (delta<=4 && rng()%(1u<<(delta+(it%5000)/1500))==0)){
                cur=trial;s=next;
            }
        }
    }
    cout<<"seed "<<seedNum<<" attempts "<<attempts<<" exact visits "<<exactVisits
        <<" flagged one-row-error visits "<<flaggedNear<<" best flagged errors "<<best<<endl;
}
