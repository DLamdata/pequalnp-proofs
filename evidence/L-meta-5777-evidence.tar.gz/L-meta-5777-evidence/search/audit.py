from pathlib import Path

gates=[tuple(map(int,l.split())) for l in (Path(__file__).parent/'seed.txt').read_text().splitlines()]
edges=[(p,7+l) for p in range(7) for l in range(7) if (p-l)%7 in (0,1,3)]
def incidence(m):
    return any(m>>p&1 and m>>l&1 for p,l in edges)
def audit(name,gs):
    errors=[]
    for m in range(1<<14):
        v=[m>>i&1 for i in range(14)]
        for op,a,b in gs:
            assert 0<=a<len(v) and 0<=b<len(v) and a!=b
            v.append(v[a]&v[b] if op else v[a]|v[b])
        if v[-1]!=incidence(m):
            errors.append(m)
    ds=[]
    for idx in range(14):
        d=[int(i==idx) for i in range(14)]
        for op,a,b in gs: d.append(d[a]+d[b] if op else max(d[a],d[b]))
        ds.append(d[-1])
    flags=[(p,l-7) for p,l in edges if min(ds[p],ds[l])>=2]
    lost=[(p,l-7) for p,l in edges if ((1<<p)|(1<<l)) in errors]
    false_pos=sum(not incidence(m) for m in errors)
    print(name,len(gs), 'gates, errors across 16384 rows:',len(errors), 'including false positives:',false_pos,'lost edges:',lost,'double flags:',flags)
    return len(errors),len(flags)
def wire(k): return 0 if k==14 else k-int(k>14)
near=[(op,wire(a),wire(b)) for op,a,b in gates[1:]]
near[0]=(1,0,7)
assert audit('Published',gates)==(0,3)
n,f=audit('One-critical-row near miss',near)
assert n and f==2
