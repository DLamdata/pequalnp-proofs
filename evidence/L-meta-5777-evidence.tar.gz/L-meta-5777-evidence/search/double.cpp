#include "model.hpp"

Word gate_value(const Gate& g,const array<Word,42>& v){
    return g.op ? v[g.a]&v[g.b] : v[g.a]|v[g.b];
}
int main(){
    Circuit seed=read_seed();
    uint64_t exact=0, flagged=0, completePairs=0;
    int best_flags=-1;
    for(int del=14;del<42;++del){
        for(int redirect=0;redirect<del;++redirect){
            auto wire=[&](int v){return v==del?redirect:v-(v>del);};
            int out=wire(41),bad=0;
            Circuit c{};
            for(int j=14;j<42;++j) if(j!=del){
                auto [op,a,b]=seed[j-14];
                c[wire(j)-14]={op,wire(a),wire(b)};
                bad+=(wire(a)==wire(b));
            }
            auto base=inputs;
            for(int j=0;j<27;++j) base[14+j]=gate_value(c[j],base);
            for(int i=0;i<26;++i){
                Gate oldI=c[i];
                int badOther=bad-(oldI.a==oldI.b);
                if(badOther>1) continue;
                for(int a=0;a<14+i;++a) for(int b=a+1;b<14+i;++b) for(int op:{0,1}){
                    c[i]={op,a,b};
                    auto v=base;
                    v[i+14]=gate_value(c[i],v);
                    for(int j=i+1;j<27;++j){
                        auto oldJ=c[j];
                        v[14+j]=gate_value(oldJ,v);
                        if(badOther>(oldJ.a==oldJ.b)) continue;
                        auto low=v,high=v;
                        low[14+j]=0; high[14+j]=(Word(1)<<58)-1;
                        for(int k=j+1;k<27;++k){
                            low[k+14]=gate_value(c[k],low);
                            high[k+14]=gate_value(c[k],high);
                        }
                        if((low[out]&~target)||(target&~high[out])) continue;
                        // On rows sensitive to j the edit must equal the target.
                        Word sensitive=low[out]^high[out];
                        for(int x=0;x<14+j;++x) for(int y=x+1;y<14+j;++y) for(int op2:{0,1}){
                            Gate g{op2,x,y};
                            if((gate_value(g,v)^target)&sensitive) continue;
                            ++exact;
                            c[j]=g;
                            int f=flags(c,27,out);
                            if(f) ++flagged;
                            if(f>best_flags){
                                assert(eval(c,27,out)==target);
                                cout<<"Exact incidence; marked flags "<<f<<" del "<<del<<" bypass "<<redirect
                                    <<" first "<<14+i<<" "<<op<<" "<<a<<" "<<b<<" second "<<14+j
                                    <<" "<<op2<<" "<<x<<" "<<y<<" output "<<out<<endl;
                                best_flags=f;
                            }
                        }
                        c[j]=oldJ;
                    }
                }
                c[i]=oldI;
            }
            ++completePairs;
        }
        cout<<"through deleted wire "<<del<<" bypass pairs "<<completePairs<<" exact "<<exact<<" flagged "<<flagged<<endl;
    }
}
