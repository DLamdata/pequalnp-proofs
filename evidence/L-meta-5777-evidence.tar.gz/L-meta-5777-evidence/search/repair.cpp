#include "model.hpp"
int main(){
    Circuit seed=read_seed();
    long long tested=0,exact=0,near=0,withinOneFlagged=0,hits=0;
    int best=59;
    for(int del=14;del<42;++del) for(int redirect=0;redirect<del;++redirect){
        auto wire=[&](int v){return v==del?redirect:v-(v>del);};
        int out=wire(41),bad=0;
        Circuit c{};
        for(int j=14;j<42;++j) if(j!=del){
            auto [op,a,b]=seed[j-14];
            c[wire(j)-14]={op,wire(a),wire(b)};
            bad+=(wire(a)==wire(b));
        }
        for(int j=0;j<27;++j){
            Gate old=c[j];
            if(bad>(old.a==old.b)) continue;
            for(int a=0;a<14+j;++a) for(int b=a+1;b<14+j;++b) for(int op:{0,1}){
                c[j]={op,a,b};
                ++tested;
                int misses=popcount(eval(c,27,out)^target);
                if(misses==0) ++exact;
                if(misses<=1) {
                    if(misses==1) ++near;
                    int f=flags(c,27,out);
                    if(f && misses==1) ++withinOneFlagged;
                    if(f && misses<best){
                        best=misses;
                        cout<<"Best flagged critical-row errors "<<misses<<" deleted "<<del<<" bypass "<<redirect<<" replaced "<<j+14<<" op "<<op<<" args "<<a<<" "<<b<<" output "<<out<<" flags "<<f<<endl;
                    }
                    if(f && misses==0) ++hits;
                }
            }
            c[j]=old;
        }
    }
    cout<<"Valid edit scripts "<<tested<<" exact incidence "<<exact<<" one critical-row error "<<near<<" one error with flag "<<withinOneFlagged<<" exact with flag "<<hits<<endl;
}
