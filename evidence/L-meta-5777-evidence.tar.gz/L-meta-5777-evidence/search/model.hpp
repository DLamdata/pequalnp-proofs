#include <algorithm>
#include <array>
#include <cassert>
#include <bit>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
using Word = uint64_t;
struct Gate {int op,a,b;};
using Circuit = array<Gate,28>;
vector<pair<int,int>> edges;
vector<int> tests;
Word target;
array<Word,42> inputs{};
bool incidence(int m) {
    for(auto [p,l]:edges) if((m>>p&1)&&(m>>l&1)) return true;
    return false;
}
int flags(const Circuit& c,int n,int output){
    int degree[42][14]{};
    for(int j=0;j<14;++j) degree[j][j]=1;
    for(int j=0;j<n;++j){
        auto [op,a,b]=c[j];
        for(int k=0;k<14;++k)
            degree[j+14][k]=op?degree[a][k]+degree[b][k]:max(degree[a][k],degree[b][k]);
    }
    int count=0;
    for(auto [p,l]:edges) count+=(degree[output][p]>=2 && degree[output][l]>=2);
    return count;
}
Word eval(const Circuit& c,int n,int out){
    auto values=inputs;
    for(int j=0;j<n;++j){
        auto [op,a,b]=c[j];
        values[j+14]=op ? values[a]&values[b] : values[a]|values[b];
    }
    return values[out];
}
Circuit read_seed(){
    for(int l=0;l<7;++l) for(int d:{0,1,3}) edges.emplace_back((l+d)%7,l+7);
    for(auto [p,l]:edges) tests.push_back((1<<p)|(1<<l));
    target=(Word(1)<<tests.size())-1;
    for(int m=0;m<(1<<14);++m){
        if(incidence(m)) continue;
        bool maximal=true;
        for(int k=0;k<14;++k) if(!(m>>k&1) && !incidence(m|1<<k)) maximal=false;
        if(maximal) tests.push_back(m);
    }
    assert(tests.size()==58);
    for(size_t j=0;j<tests.size();++j) for(int k=0;k<14;++k)
        if(tests[j]>>k&1) inputs[k]|=Word(1)<<j;
    Circuit seed;
    for(int j=0;j<28;++j){
        auto& [op,a,b]=seed[j]; assert(cin>>op>>a>>b);
        assert((op==0 || op==1)&&0<=a&&a<14+j&&0<=b&&b<14+j&&a!=b);
    }
    assert(eval(seed,28,41)==target);
    cout<<"Seed flags "<<flags(seed,28,41)<<endl;
    return seed;
}
