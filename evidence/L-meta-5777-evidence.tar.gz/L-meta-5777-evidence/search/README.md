# Local repairs of the 28-gate Fano circuit

The seed is Solareyon’s published Fano28 circuit. The 28 rows of seed.txt give AND as 1 and OR as 0, followed by the two wire numbers. The 14 primary bits come first. Each test uses the cyclic Fano labeling from the proof repository. An incident flag qualifies when both singleton degrees of the output are at least two. At AND, degrees add. At OR, they take the maximum.

repair.cpp tries all edits of the following form. Delete one of the 28 gates, replace every use of its output (including the designated circuit output) by any one earlier wire, renumber, and replace one remaining gate with any allowed operation on two distinct earlier wires. All other gates retain their original operands, subject to the bypass. double.cpp does the same with two freely replaced gates in increasing topological order; either replacement may equal the original gate. It computes output signatures with the later gate forced low and high. On rows where those signatures agree, the target must already equal that common value. On the remaining rows the replacement must equal the target. This is exact since the circuit is monotone. Both programs reject repeated operands in the final circuit. Dead gates and non-final designated outputs are allowed. Counts refer to edit scripts, which need not be unique circuits.

The 21 minimal positive rows are the graph edges. The 37 maximal independent sets are the maximal false rows. Their truth values characterize the whole monotone function by upward and downward closure. There are 15,419,808 legal single-replacement scripts. None computes incidence. Of these, 1,298 missed just one boundary row and retained a qualifying flag. The two-replacement run exhausted all 770 deletion/bypass pairs and found zero exact incidence circuits. These results concern this particular seed and edit model.

The independent full truth-table check of one deterministic near miss found two qualifying flags. The circuit lost the incident edge at point 0 and line 4, missed 47 of the 16,384 assignments, and had no false positives. This circuit is not a counterexample. The source 28-gate circuit computed the correct function on all assignments and qualified at three flags.

walk.cpp starts alternating runs from the near miss and the correct 27-gate point-star circuit. It rewires operands or flips gate operations, retaining intermediate gate order and output wire 40. The score is twice the number of boundary errors plus three if no flag qualifies. It accepts neutral and downhill steps and occasionally uphill steps. Each seed stops after 200 cycles of 50,000 proposals or on a qualifying exact match. No run found a qualifying exact match. All seeds reached one wrong boundary row with a qualifying flag. Visits are proposals, including repeats.

From the search directory run

```sh
python3 seed.py > seed.txt
python3 audit.py
g++ -std=c++20 -O3 -march=native repair.cpp -o /tmp/fano-repair
g++ -std=c++20 -O3 -march=native double.cpp -o /tmp/fano-double
g++ -std=c++20 -O3 -march=native walk.cpp -o /tmp/fano-walk
/tmp/fano-repair < seed.txt
/tmp/fano-double < seed.txt
for seed in 5777 2223 21972 413; do /tmp/fano-walk "$seed" 200 < seed.txt; done
```

The C++ walk uses the standard mt19937 engine. The exhaustive enumerations and truth-table audit use no randomness. Codex ran the checks. [Seed and license](https://gist.github.com/Solareyon/13b6919a6c21468b1f65abbc04081fde/b6c3aaf18fe2148c9dd44799952806519d8b1ae8)
