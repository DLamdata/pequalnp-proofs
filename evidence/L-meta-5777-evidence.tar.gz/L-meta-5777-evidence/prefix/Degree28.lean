import PEqualNP.Defs.LineDegree

namespace FiveStarWitness

open PEqualNP.CircuitLowerBounds

-- Circuit from Solareyon's Fano28.lean, cited in the accompanying README.
def W : Circuit := ⟨[⟨.or, [7,11]⟩, ⟨.and, [0,14]⟩, ⟨.or, [13,15]⟩, ⟨.and, [0,16]⟩, ⟨.or, [8,16]⟩, ⟨.or, [2,17]⟩, ⟨.or, [9,18]⟩, ⟨.and, [19,20]⟩, ⟨.or, [7,8]⟩, ⟨.or, [22,12]⟩, ⟨.and, [1,23]⟩, ⟨.or, [7,9]⟩, ⟨.or, [25,10]⟩, ⟨.and, [3,26]⟩, ⟨.or, [8,10]⟩, ⟨.or, [28,11]⟩, ⟨.and, [4,29]⟩, ⟨.or, [9,11]⟩, ⟨.or, [31,12]⟩, ⟨.and, [5,32]⟩, ⟨.or, [10,12]⟩, ⟨.or, [34,13]⟩, ⟨.and, [6,35]⟩, ⟨.or, [21,24]⟩, ⟨.or, [37,27]⟩, ⟨.or, [38,30]⟩, ⟨.or, [39,33]⟩, ⟨.or, [40,36]⟩], 41⟩

theorem size_and_marked_degrees :
    W.size = 28 ∧ W.lineDeg 14 {0} = 3 ∧ W.lineDeg 14 {7} = 2 := by
  decide +kernel

theorem singleton_profile :
    (List.range 14).map (fun i => W.lineDeg 14 {i}) =
      [3,1,1,1,1,1,1,2,1,1,1,2,1,2] := by
  decide +kernel

end FiveStarWitness
