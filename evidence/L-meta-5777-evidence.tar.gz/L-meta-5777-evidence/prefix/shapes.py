"""Essential-input census after setting the five star centers low."""
from itertools import combinations
from collections import Counter

edges = frozenset((p, 7 + l) for p in range(7) for l in range(7) if (p - l) % 7 in (0, 1, 3))
census = Counter()
for centers in combinations(range(14), 5):
    rest = [e for e in edges if set(centers).isdisjoint(e)]
    V = set(v for edge in rest for v in edge)
    census[len(V)] += 1
    if len(V) == 7:
        pure_points = max(centers) < 7
        pure_lines = min(centers) >= 7
        assert pure_points or pure_lines
        counts = Counter(v for edge in rest for v in edge)
        assert sorted(counts.values()) == [1, 1, 1, 1, 2, 3, 3]
        hubs = [v for v in V if counts[v] == 3]
        assert all(len(set(edge).intersection(hubs)) == 1 for edge in rest)
assert census == {7: 42, 8: 546, 9: 1414}
print('remaining essential variables : sets of five distinct centers')
print(sorted(census.items()), 'tested every five-center subset')
