# Five complete stars in a Fano incidence circuit

At 27 gates, the following restricted circuit architecture cannot achieve singleton line degree at least two on both endpoints of any incident point–line pair. The 28-gate example does achieve it.

## Scope

Use the exact cyclic Fano graph from the repository. Points occupy wires 0 through 6 and lines occupy wires 7 through 13. Choose five distinct point or line vertices. For each center take one independent three-gate star, the center AND the OR of its three neighbors. Use five binary OR gates to combine the five stars with one output from an arbitrary sixth subcircuit. Thus the fixed part costs 20 gates. The sixth subcircuit may use any primary input and share its own internal results arbitrarily. All gates have two distinct earlier operands. Sharing gates between the five stars and the sixth subcircuit falls outside this architecture.

The source circuit from Solareyon has exactly this architecture and uses eight gates in its sixth subcircuit. On the same ordered gate list, Lean computes full-circuit size 28 and singleton line degrees 3 and 2 for point 0 and line 0. Complete28.lean reuses the published wire-evaluation proof, converts the incidence test to the exact project predicate, and verifies correctness on every input alongside IsAO2, distinct operands, flag membership, size and both singleton degrees in one theorem. The original directional recurrence on the marked input and the project's singleton max/add degree are different tests. In wire order 0–13, Degree28.singleton_profile computes [3,1,1,1,1,1,1,2,1,1,1,2,1,2]. Thus this assignment's additive degree criterion holds at all three flags from point 0 to lines 0, 4 and 6. The source's directional doubleReread test lists lines 0 and 4 only. [Discussion 21972](https://github.com/open-goat/pequalnp-proofs/discussions/21972) · [Versioned source and license](https://gist.github.com/Solareyon/13b6919a6c21468b1f65abbc04081fde/b6c3aaf18fe2148c9dd44799952806519d8b1ae8)

## Counting argument

1. At size 27 the sixth subcircuit has at most seven gates. The output OR gates take the maximum of singleton degrees. Every variable occurs at most once in each complete star, so the two high singleton degrees must both come from the sixth subcircuit.
2. Set all five center bits to zero. The stars vanish, and the sixth subcircuit must compute incidence of the induced graph on the remaining vertices. Every vertex on any surviving edge is essential: turn on only its neighbor and toggle the vertex itself.
3. Discard unreachable gates and count wires in the sixth subcircuit's output cone. With `g` gates and `r` distinct primary inputs, count outgoing uses towards the output. There are `2g` uses and `g+r−1` non-output vertices that each require at least one. The excess is `g−r+1`. If `r≥8` and `g≤7`, the excess must be zero. The output is a read-once tree and every singleton degree is at most one.
4. In a mixed selection of five centers, at least eight variables are essential in the restricted function. The exhaustive census found 1,414 selections with nine and 546 with eight. The other 42 selections are the 21 all-point and 21 all-line cases.
5. In a pure selection, the remaining two centers on that side each have three neighbors and share exactly one neighbor. Relabeling the seven incident vertices produces two 3-stars with one shared leaf. We use local bit positions for the seven original wires `[0,2,7,8,9,11,13]`. In the canonical labels the edges are (0,7), (0,11), (0,13), (2,8), (2,9), (2,13). These are all original incident pairs with both endpoints among the seven variables. Because the seven are already essential, any eighth vertex in the cone falls under point 3. The output cone can therefore use only those seven; its function on them is exactly the two-star residual.
6. With seven essential variables and two high degrees the excess must be one. Exactly one vertex has two outgoing uses, all other non-output vertices have one. Both high-degree inputs must be in the dependency cone of the repeated wire: outside it each occurs at most once in the unfolded tree. The repeated wire must consequently be internal. Its own cone is a binary tree and its variables have no outgoing path bypassing that wire. Let `S` be their set. Then the residual must factor through the one-bit signal `f(x restricted to S)` and the remaining input bits. The set `S` contains an incident pair. It is proper: if it contained all seven variables, its tree would already use six gates, leaving just one gate to take the repeated wire twice, contrary to distinct operands.
7. For each of the 86 eligible proper subsets, three assignments supported on `S` yield distinct rows of the truth table on the complementary variables, distinguished by just two complementary assignments. A Boolean signal can encode at most two rows. This proves the required factorization is impossible.

The cone counting, interface reduction and relabeling are mathematical arguments. Lean checks the universal one-bit nonfactorization theorem for the canonical residual, the mixed-center essential-count inequality, and the two-stars incidence counts. It also checks the 28-gate witness against each circuit-side condition in the assignment with the bound replaced by exact size 28. The axiom report for exact_28 contains only propext, Classical.choice and Quot.sound. The files do not formalize a lower bound over all project circuits or the assigned statement.

## Reproduce

The run used Python 3.12.14, Lean 4.36.0 (commit 611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9), and project revision 7c4efd6d7efbd8a5b701c1c3405343b01acf5fac. Use any working checkout of that revision with its pinned dependencies. From this folder run the commands below, substituting your checkout path.

```sh
python3 prefix.py
python3 shapes.py
proof_dir="$PWD"
cd /workspace/pequalnp-proofs/lean
for test in Prefix Centers Degree28 Complete28; do
    lake env lean --root="$proof_dir" -o "$proof_dir/$test.olean" "$proof_dir/$test.lean" || exit 1
done
```

The two scripts are deterministic and have no seeds. They stop after every eligible subset and every five-center choice, respectively. The first emits the Lean witness table. No SAT solver, timeout, or untested sampling assumption enters either count. Solareyon's circuit data and evaluation proof in Degree28.lean and Complete28.lean is reproduced from the linked source under the included Apache License 2.0. Codex ran the enumeration and Lean checks.
