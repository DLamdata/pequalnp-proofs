"""Exhaustive Boolean factorization obstruction for the fixed Fano28 suffix."""
from itertools import combinations
from pathlib import Path

# Local bit positions are sorted original circuit input-wire numbers.
variables = (0, 2, 7, 8, 9, 11, 13)
edges = tuple((p, 7 + l) for p in (0, 2) for l in range(7)
              if (p - l) % 7 in (0, 1, 3))
flags = [sum(1 << variables.index(v) for v in edge) for edge in edges]

def target(bits):
    return any(bits & flag == flag for flag in flags)

def split(mask):
    return mask != 127 and any(mask & flag == flag for flag in flags)

def certify(mask):
    a_rows = [x for x in range(128) if x & mask == x]
    b_cols = [y for y in range(128) if y & mask == 0]
    row_vectors = {tuple(target(x | y) for y in b_cols): x for x in a_rows}
    for (r, a), (s, b), (u, c) in combinations(row_vectors.items(), 3):
        for i, j in combinations(range(len(b_cols)), 2):
            if len({(r[i], r[j]), (s[i], s[j]), (u[i], u[j])}) == 3:
                return a, b, c, b_cols[i], b_cols[j]
    raise ValueError(f'no witness for {mask=}')

masks = [m for m in range(128) if split(m)]
witnesses = [certify(m) if split(m) else (0,)*5 for m in range(128)]
print('original wires:', variables, 'incident flags:', edges)
print(len(masks), 'eligible proper subsets all have three distinguishable rows')
print('deterministic exhaustive finite check; no seeds')
source = Path(__file__).with_name('Prefix.template').read_text()
source = source.replace('FLAGS', repr(flags))
source = source.replace('WITNESSES', ',\n'.join('⟨' + ', '.join(map(str, w)) + '⟩' for w in witnesses))
Path(__file__).with_name('Prefix.lean').write_text(source)
