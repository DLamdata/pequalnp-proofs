import Std

namespace FanoPrefix

def vertices := List.range 7
def flag (p l : Nat) := [0,1,3].contains ((p + 7 - l) % 7)
def selected (c i : Nat) := c.testBit i
def card (c : Nat) := vertices.countP (selected c)
def neededPoints (p l : Nat) := vertices.countP fun i =>
  !selected p i && vertices.any fun j => !selected l j && flag i j
def neededLines (p l : Nat) := vertices.countP fun j =>
  !selected l j && vertices.any fun i => !selected p i && flag i j

-- Partial application lets the kernel share the precomputed cardinality arrays.
def sizes : Array Nat := ((List.range 128).map card).toArray

def enough (p l : Fin 128) : Bool :=
  (sizes[p.val]! + sizes[l.val]! != 5 || sizes[p.val]! == 0 || sizes[l.val]! == 0) ||
    decide (8 ≤ neededPoints p.val l.val + neededLines p.val l.val)

set_option maxRecDepth 10000 in
set_option maxHeartbeats 8000000 in
theorem mixedFiveCheck : ∀ p l : Fin 128, enough p l = true := by decide

def twoStars (i j : Fin 7) : Bool :=
  i == j || (vertices.countP (flag i.val) == 3 &&
             vertices.countP (flag j.val) == 3 &&
             vertices.countP (fun l => flag i.val l && flag j.val l) == 1 &&
             vertices.countP (fun p => flag p i.val) == 3 &&
             vertices.countP (fun p => flag p j.val) == 3 &&
             vertices.countP (fun p => flag p i.val && flag p j.val) == 1)

theorem fanoTwoStars : ∀ i j : Fin 7, twoStars i j = true := by decide

end FanoPrefix
