"""Independent of the orbit partition: check all 1001 labeled center selections."""
from collections import Counter
from itertools import combinations
from pathlib import Path
from subprocess import check_output
result = Counter()
with Path('labeled-four.log').open('w') as log:
    for centers in combinations(range(14), 4):
        mask = sum(1 << x for x in centers)
        line = check_output(['./cone', str(mask), '3000000'], text=True)
        log.write(line)
        fields = dict(x.split('=') for x in line.split())
        assert fields['exhausted'] == '1' and fields['double'] == '0'
        result[int(fields['complete'])] += 1
assert result == {0: 931, 81: 70}
print(dict(result))
