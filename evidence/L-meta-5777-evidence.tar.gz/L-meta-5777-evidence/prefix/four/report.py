from csv import DictReader
from collections import Counter
from pathlib import Path
with Path('two.csv').open() as f:
    records=[{k:int(v) for k,v in r.items()} for r in DictReader(f)]
for centers in (3,132):
    rows=[r for r in records if r['centers']==centers]
    unique={r['first_key']:r for r in rows}
    latest=list(unique.values())
    print(f"mask {centers}: {len(latest)} of 132 buckets started, {sum(r['exhausted'] for r in latest)} exhausted, {sum(r['correct'] for r in latest)} correct completions observed, {sum(r['double'] for r in latest)} doubled, {sum(r['visited'] for r in latest)} latest visits across buckets")
