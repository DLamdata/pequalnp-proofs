#include <array>
#include <algorithm>
#include <bit>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
struct Wire {uint64_t pos,neg; unsigned support, twice;};
struct Gate {int a,b;bool is_and;};
array<Wire,64> wire;
array<Gate,32> path;
vector<unsigned> edges;
uint64_t limit,visited=0,complete=0,flagged=0;
int r=0,gmax=11;
uint64_t allneg=0;
bool aborted=false, control=false;
bool truth(unsigned bits){
  for(auto e:edges) if ((bits&e)==e)return true;
  return false;
}
bool cover(uint64_t live){
 for(unsigned i=0;i<edges.size();++i){
  uint64_t obs=0;
  for(auto j=live;j;j&=j-1){auto &w=wire[countr_zero(j)];
    if ((w.pos>>i)&1) obs|=~w.neg;
    if ((obs&allneg)==allneg)break;
  }
  if((obs&allneg)!=allneg)return false;
 }
 return true;
}
void search(int depth,uint64_t live,unsigned prev,int budget){
 if(aborted)return;
 if(++visited>=limit){aborted=true;return;}
 if(popcount(live)==1){
   if(depth!=gmax || budget) return;
   auto &out=wire[countr_zero(live)];
   ++complete;
   if(truth(out.twice)){
     ++flagged;
     cout<<"FLAGGED ";
     for(int i=0;i<depth;++i)cout<<path[i].a<<","<<path[i].b<<","<<path[i].is_and<<" ";
     cout<<endl;
     if(control) aborted=true;
   }
   return;
 }
 if(depth==gmax)return;
 int z=r+depth;
 for(uint64_t lb=live;lb;lb&=lb-1){
  int b=countr_zero(lb);
  for(uint64_t la=live&((1ULL<<b)-1);la;la&=la-1){
   int a=countr_zero(la);auto A=wire[a],B=wire[b];
   for(int op=0;op<2;++op){
    unsigned key=(b*64+a)*2+op;
    if(key<=prev)continue;
    Wire w{op?A.pos&B.pos:A.pos|B.pos,op?A.neg&B.neg:A.neg|B.neg,
       A.support|B.support,A.twice|B.twice|(op?(A.support&B.support):0u)};
    bool dominated=false;
    for(int i=0;i<z;++i)if((w.pos&~wire[i].pos)==0 && (wire[i].neg&~w.neg)==0){dominated=true;break;}
    if(dominated && !control)continue;
    wire[z]=w;path[depth]={a,b,bool(op)};
    uint64_t base=(live&~((1ULL<<a)|(1ULL<<b)))|(1ULL<<z);
    for(unsigned keep=0;keep<4;++keep){
     int cost=popcount(keep);if(cost>budget)continue;
     auto next=base|(uint64_t(keep&1u)<<a)|(uint64_t((keep>>1)&1u)<<b);
     if(cover(next))search(depth+1,next,key,budget-cost);
     if(aborted)return;
    }
   }
  }
 }
}
int main(int argc,char**argv){
 if(argc!=3 && argc!=4)return 1;
 if(argc==4){if(string(argv[3])!="positive-control-28")return 1;control=true;}
 unsigned centers=stoul(argv[1]);limit=stoull(argv[2]);gmax=(control?28:27)-4*popcount(centers);
 const int diff[3]={0,1,3};unsigned vertices=0;
 vector<unsigned> inds;
 for(int p=0;p<7;p++)for(int l=0;l<7;l++){
  int d=(p+7-l)%7;if(find(diff,diff+3,d)==diff+3)continue;
  unsigned pair=(1u<<p)|(1u<<(l+7));
  if(!(centers&pair)){inds.push_back(pair);vertices|=pair;}
 }
 vector<int> orig;
 for(int i=0;i<14;i++)if((vertices>>i)&1)orig.push_back(i);
 r=int(orig.size());int budget=gmax-r+1;
 for(auto e:inds){
   unsigned mapped=0;
   for(int i=0;i<r;i++)if(e&(1u<<orig[i]))mapped|=1u<<i;
   edges.push_back(mapped);
 }
 vector<unsigned> neg;
 for(unsigned x=0;x<(1u<<r);x++){
  if(truth(x))continue;
  bool maximal=true;
  for(int i=0;i<r;i++)if(!(x&(1u<<i))&&!truth(x|(1u<<i)))maximal=false;
  if(maximal)neg.push_back(x);
 }
 if(neg.size()>=64||r+gmax>=64||edges.size()>=64)return 2;
 allneg=(1ULL<<neg.size())-1;
 for(int i=0;i<r;i++){
  auto &w=wire[i];w.support=1u<<i;
  for(unsigned j=0;j<neg.size();++j)if(neg[j]&(1u<<i))w.neg|=1ULL<<j;
  for(unsigned j=0;j<edges.size();++j)if(edges[j]&(1u<<i))w.pos|=1ULL<<j;
 }
 search(0,(1ULL<<r)-1,0,budget);
 cout<<"centers="<<centers<<" vars="<<r<<" pos="<<edges.size()<<" neg="<<neg.size()
     <<" state_limit="<<limit<<" visited="<<visited<<" complete="<<complete
     <<" double="<<flagged<<" exhausted="<<!aborted<<endl;
}
