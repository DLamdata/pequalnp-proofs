from itertools import combinations,permutations
from collections import Counter
import sys
from pathlib import Path
neighbors = [frozenset((j+d)%7 for d in (0,1,3)) for j in range(7)]
group=[]
for perm in permutations(range(7)):
    lines=[frozenset(perm[i] for i in n) for n in neighbors]
    if set(lines)!=set(neighbors):continue
    image=tuple(perm)+tuple(7+neighbors.index(l) for l in lines)
    dual=lambda v: (7 if v < 7 else 0) + (-v)%7
    group.extend([image,tuple(dual(v) for v in image)])
assert len(set(group)) == 336
reps=Counter()
for subset in combinations(range(14),int(sys.argv[1]) if len(sys.argv)>1 else 4):
    rep=min(sum(1<<g[i] for i in subset) for g in group)
    reps[rep]+=1
for rep in sorted(reps):
    print(rep, reps[rep], [i for i in range(14) if rep&(1<<i)])
