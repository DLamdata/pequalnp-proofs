import csv
from pathlib import Path
for m in (3,132):
    snapshots=[]
    for f in ('two.csv','two-constant.csv'):
        with open(f) as stream:
            L={int(r['first_key']):{k:int(v) for k,v in r.items()} for r in csv.DictReader(stream) if int(r['centers'])==m}
        snapshots.append(L)
        print(f,m,len(L),sum(i['exhausted'] for i in L.values()),sum(i['correct'] for i in L.values()),sum(i['double'] for i in L.values()))
    closed=set(k for d in snapshots for k,v in d.items() if v['exhausted'])
    print('unique exhausted first-gate buckets',m,len(closed),'of 132')
