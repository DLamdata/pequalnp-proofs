"""Independent all-input check of the first 28-gate control solution."""
from pathlib import Path
from itertools import product
gates=[tuple(map(int,t.split(','))) for t in Path('control28.log').read_text().splitlines()[0].split()[1:]]
line=lambda p,l: (p-l)%7 in (0,1,3)
centers=[1,3,4,5,6]
variables=[0,2,7,8,9,11,13]
full_edges=[(p,7+l) for p,l in product(range(7),repeat=2) if line(p,l)]
for bits in range(1<<14):
    x=[bool(bits>>j&1) for j in range(14)]
    w=[x[j] for j in variables]
    for a,b,op in gates:
        assert 0<=a<b<len(w)
        w.append((w[a] and w[b]) if op else (w[a] or w[b]))
    stars=any(x[p] and x[j] for p,j in full_edges if p in centers)
    assert (w[-1] or stars)==any(x[p] and x[j] for p,j in full_edges)
def degree(v):
    d=[int(j==v) for j in variables]
    for a,b,op in gates:
        d.append((d[a]+d[b]) if op else max(d[a],d[b]))
    return max(d[-1], int(any(v in e for e in full_edges if e[0] in centers)))
double=[(p,j,degree(p),degree(j)) for p,j in full_edges if min(degree(p),degree(j))>=2]
assert double
print('Checked all 16384 inputs; full 28-gate control doubled flags',double)
