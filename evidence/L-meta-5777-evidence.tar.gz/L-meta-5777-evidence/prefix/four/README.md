# Exact cone search with complete stars

The size budget is 27 total gates, counted exactly as the project counts them. For k distinct centers, reserve 3k gates for independent full Fano stars and k more OR gates to join those stars and one residual wire. The residual is a fan-in-two monotone circuit with at most 27−4k gates. It may share internal gates arbitrarily. The rest of the circuit can read only its output. Point inputs are wires 0–6, line inputs wires 7–13. A flag is any edge of the original Fano graph.

## Lossless reductions

The accepted 27-gate lower bound for unrestricted Fano incidence is used here. [Repository theorem L-meta-9442](https://github.com/open-goat/pequalnp-proofs/blob/7c4efd6d7efbd8a5b701c1c3405343b01acf5fac/lean/PEqualNP/Outside/L_meta_9442.lean)

1. On inputs where every selected center is zero, the stars are all false. The remaining target is incidence of the induced residual graph. A variable incident to no surviving edge can also be set to zero. This restricted function extends to a correct full circuit by OR-ing the residual with the original stars.
2. There cannot be a dead or simplifiable gate in any candidate's residual cone: removing one and recombining with the stars would give at most 26 gates for full Fano incidence. If any center or other inessential input were used, set it to zero. At its earliest use, AND with zero simplifies to zero or OR with zero to the other input. Propagate constants to remove at least that gate; the residual is nonconstant. This gives the same contradiction. Thus the search uses exactly the remaining essential variables, and it computes their residual edge function on every input.
3. Retain the residual function's minimum true rows (edges) and maximum false rows (maximal independent sets). For monotone circuits, these rows determine correctness everywhere. With several wires still live, every positive-negative pair must have at least one live wire true at the positive row and false at the negative one. Otherwise any monotone continuation violates that pair. After each gate the search checks this necessary condition. At one live output the condition suffices.
4. Each step combines two distinct live wires in either order-insensitive gate. For each operand, branch on whether it is kept for another use or retired. With g gates and r inputs in a connected output cone, exactly g−r+1 uses are extra: the live-wire count starts at r, changes by −1 plus the number of kept operands per gate, and ends at one. All such choices are explored. Stop after exactly 27−4k gates, using the global lower bound. A new wire identical to an earlier one on the test rows can be replaced by the earlier wire and removed. Idempotent duplicate operands introduced by that replacement can also be simplified. This would yield a smaller correct circuit and is excluded by the same lower bound.
5. A topological ordering can always list gates in increasing order of the tuple (larger operand wire number, smaller operand number, operator). At each step take the smallest tuple among the gates ready to be listed. Any newly enabled gate uses the latest assigned wire number and has a larger tuple. Equal tuples duplicate a gate and cannot occur in a minimum-size circuit.
6. Each wire carries two bit masks. Support is the union of the operands' supports. The set of singleton marks of degree at least two is the union of the corresponding operand masks, enlarged at an AND by the intersection of the operand supports. This computes the exact ≥2 predicate for the project's additive AND / maximum OR recurrence. Each reserved star has every mark at degree ≤1 and the final OR takes the maximum. A candidate succeeds precisely when its output’s doubled mask contains an incident pair.
7. The 168 point collineations and their 168 point–line duals act on star-center choices. The generator checks point permutations against the displayed Fano lines, maps each line by its incidence set, and uses the duality exchanging a point or line i with line or point −i mod 7. Relabeling preserves gate count, incidence, and singleton degrees. The census reports every orbit representative.

The C++ enumeration and graph-counting translation are separate from the Lean-checked five-star certificates. This program uses deterministic DFS with an explicit state limit; only rows marked exhausted=1 are complete. The count 'complete' refers to ordered outputs after these exact reductions, not the number of all labeled gate lists.

## Four-star result and control

The twelve representatives account for all 1,001 labeled center sets. Every orbit exhausted its full search. Separately, all_four.py searched every labeled set directly (1,439,711 visited states in total). The 931 mixed choices yielded zero correct 11-gate residuals. Each of the 70 pure choices yielded 81 accepted completions; none doubled any incident flag. Hence joining four complete independent stars to one arbitrary independent residual does not attain a double-marked flag at size 27. The five-star witness fits the four-star template at size 28 by grouping its prefix with one star and one OR.

For four pure centers, the number 81 also counts the ordinary three remaining same-shore stars: each has three choices for its three-neighbor OR tree, with three choices of binary OR tree over the three star outputs. All 81 circuits are distinct up to gate ordering and operand swaps. They each realize one canonical order and its unique keep decisions. The total matches the entire census. Hence this class admits only ordinary star completions at size 27. The analogous count for three pure centers is 3^4 × 15 = 1,215, using the fifteen rooted non-plane binary trees on four labeled outputs.

A 28-gate positive control using five pure centers stops upon finding its first doubly marked circuit. An independent Python verifier evaluates all 16,384 truth assignments and the full singleton degree recurrence. It found point 2 and line inputs 8, 9 and 13 (line indices 1, 2, 6), with degrees 3 and 2 respectively. Degree28.lean tests the different, previously published Solareyon circuit.

## Replay

From this folder run the commands below. GCC 14.2.0 with C++20 and Python 3.12.14 were used. No random seeds.

```sh
g++ -O3 -std=c++20 cone.cpp -o cone
python3 orbits.py 4 > orbits.log
while read -r rep rest; do ./cone "$rep" 3000000; done < orbits.log
python3 all_four.py
./cone 122 10000000 positive-control-28 > control28.log
python3 verify_control.py
python3 orbits.py 3 > orbits3.log
while read -r rep rest; do ./cone "$rep" 50000000; done < orbits3.log
```

## Search revisions

The listed four-star and initial three-star logs used cone-basic.cpp, which prunes a new wire equal to an earlier wire on all minimum positive and maximum negative rows. For bytewise reproduction of those logs, compile cone-basic.cpp to the executable named cone. The revision cone.cpp also prunes a new wire whenever an earlier wire is at least as large on every critical positive row and at most as large on every critical negative row. Substituting that earlier wire can only increase a downstream monotone circuit on the positive rows and decrease it on the negative rows. Any successful completion would therefore give a smaller correct circuit, contradicting the global lower bound. This optimization is disabled for the 28-gate positive control.

The three-star representative with mask 11 reached the initial 50-million state limit. Its separate follow-up uses the stronger domination criterion and the following command.

```sh
g++ -O3 -std=c++20 cone.cpp -o cone-fast
./cone-fast 11 1000000000
```

Two opposite-shore selected centers sharing an edge already rule out optimality without search: the common edge is covered by both independent stars. Delete that neighbor from either star's three-way OR; the other star still covers the edge, and a gate is saved.

## Three-star outcome

Every three-center orbit exhausted the search at size 27. Masks 7 and 11 (pure centers) each yielded 1,215 completions, precisely the ordinary four-star residual count. Masks 131, 133 and 148 (mixed centers) yielded zero completions. The five orbit sizes are 56, 14, 42, 168 and 84, totaling all 364 choices. None produced a double-degree incident flag. Thus the 28-gate example is also sharp in the three-star template (absorb two of its five stars and the two corresponding OR gates into its residual). The raw initial cap for mask 11 was superseded by the completed run in extra11.log; use that latter run for the verdict.

## Bounded two-star follow-up

The fixed eight-gate two-star suffix leaves 19 gates. The orbits are pure (mask 3), incident mixed (mask 129, excluded by duplicate edge), and nonincident mixed (mask 132). An exhaustive partition by the first gate of the canonical topological order is used on the two remaining representatives. All 12 essential input wires are available initially, and all 132 operand pairs/operators per orbit are eligible for enumeration. The key is (64·b+a)·2+op for local wire indices a<b in sorted surviving-variable order, with 1 denoting AND. No further input-label symmetry is assumed on these first-gate buckets. The search tries larger b first, interleaves both representatives, then revisits capped buckets at increasing state limits. Only rows marked exhausted=1 close their buckets. This search has a wall limit and is not a claim about the unrestricted population.

```sh
g++ -O3 -std=c++20 cone-branch.cpp -o cone-branch
python3 two.py --seconds 240
```

To reproduce a specific logged row, run ./cone-branch CENTERS CAP first=FIRST_KEY. For reproducibility under different CPU availability, the recorded CSV identifies the precise seeds (none), branch key, cap, and explored count. Each branch search is deterministic. The positive-control run has its own replay command above.

A second bucket run adds constant propagation. A fresh wire false on every minimal positive row can be replaced by false, because this leaves all positive rows fixed and can only decrease the output at negative rows. Dually, a wire true on all maximal negative rows can be replaced by true. Propagating that constant eliminates at least one gate, and the target is nonconstant. Thus both cases contradict global 27-gate minimality. Use the following commands for this variant.

```sh
g++ -O3 -std=c++20 cone-constant.cpp -o cone-constant
python3 two_constant.py --seconds 120 --output two-constant.csv
python3 latest.py
```

The wall limits in the executed task were chosen to terminate both searches together at 01:14:50 UTC. Per-bucket logs are the exact replay specification. Completed coverage for each orbit is the union of exhausted buckets across the two runs. The same buckets may be visited more than once. Each representative has 132 possible first gates on its twelve inputs. The two-star conclusion is limited to the closed buckets and the sampled prefixes of others.
