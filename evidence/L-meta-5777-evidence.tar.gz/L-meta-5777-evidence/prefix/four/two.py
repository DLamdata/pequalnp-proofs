"""Run exact canonical first-gate buckets subject to per-bucket and wall limits."""
import argparse, csv, itertools, subprocess, time
from pathlib import Path
ap=argparse.ArgumentParser()
ap.add_argument('--seconds',type=float,default=240)
ap.add_argument('--output',default='two.csv')
args=ap.parse_args()
deadline=time.monotonic()+args.seconds
edges=[(p,7+l) for p in range(7) for l in range(7) if (p-l)%7 in (0,1,3)]
representatives = (3,132)  # pure, nonincident mixed (incident mixed excludes a redundant neighbor)
buckets=[]
for b in reversed(range(1,12)):
    for a in range(b):
        for op, centers in itertools.product((0,1),representatives):
            vertices=sorted({v for e in edges if not any(centers>>u&1 for u in e) for v in e})
            assert len(vertices)==12
            key=(b*64+a)*2+op
            buckets.append((centers,key,vertices[a],vertices[b],op))
with Path(args.output).open('w') as log:
    w=csv.writer(log)
    w.writerow(('centers','first_key','wire_a','wire_b','op_AND','cap','visited','correct','double','exhausted'))
    for cap in (40000,200000,1000000,5000000,50000000):
        pending=[]
        for centers,key,a,b,op in buckets:
            if time.monotonic()>=deadline:raise SystemExit
            try:
                s=subprocess.check_output(['./cone-branch',str(centers),str(cap),'first='+str(key)],text=True,timeout=max(0.1,deadline-time.monotonic()))
            except subprocess.TimeoutExpired:
                print('Wall limit stopped one bucket; only completed invocations appear in log.')
                raise SystemExit
            if s.startswith('FLAGGED'):print(s,flush=True)
            fields=dict(word.split('=') for word in s.splitlines()[-1].split())
            row=[fields[k] for k in ('visited','complete','double','exhausted')]
            w.writerow((centers,key,a,b,op,cap,*row))
            log.flush()
            if not int(fields['exhausted']):pending.append((centers,key,a,b,op))
        buckets=pending
        if not buckets:break
