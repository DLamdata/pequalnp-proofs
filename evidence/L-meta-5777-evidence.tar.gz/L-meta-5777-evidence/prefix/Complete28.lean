-- Gate list and evalIncidence from Solareyon, Apache-2.0. See README.
import Mathlib
import PEqualNP.Defs

namespace PEqualNP.Outside.L_meta_4126_research

open PEqualNP.CircuitLowerBounds PEqualNP.ReadK

def W : Circuit := ⟨[⟨.or, [7,11]⟩, ⟨.and, [0,14]⟩, ⟨.or, [13,15]⟩, ⟨.and, [0,16]⟩, ⟨.or, [8,16]⟩, ⟨.or, [2,17]⟩, ⟨.or, [9,18]⟩, ⟨.and, [19,20]⟩, ⟨.or, [7,8]⟩, ⟨.or, [22,12]⟩, ⟨.and, [1,23]⟩, ⟨.or, [7,9]⟩, ⟨.or, [25,10]⟩, ⟨.and, [3,26]⟩, ⟨.or, [8,10]⟩, ⟨.or, [28,11]⟩, ⟨.and, [4,29]⟩, ⟨.or, [9,11]⟩, ⟨.or, [31,12]⟩, ⟨.and, [5,32]⟩, ⟨.or, [10,12]⟩, ⟨.or, [34,13]⟩, ⟨.and, [6,35]⟩, ⟨.or, [21,24]⟩, ⟨.or, [37,27]⟩, ⟨.or, [38,30]⟩, ⟨.or, [39,33]⟩, ⟨.or, [40,36]⟩], 41⟩

lemma gateCount : W.size = 28 := rfl

lemma shape : ∀ (j : Fin W.gates.length), let g := W.gates.get j
    (g.op = GateOp.and ∨ g.op = GateOp.or) ∧
      ∃ a b, g.inputs = [a,b] ∧ a ≠ b ∧ a < 14 + j.val ∧ b < 14 + j.val := by
  intro j
  fin_cases j
  · exact ⟨Or.inr rfl, 7, 11, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inl rfl, 0, 14, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 13, 15, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inl rfl, 0, 16, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 8, 16, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 2, 17, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 9, 18, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inl rfl, 19, 20, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 7, 8, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 22, 12, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inl rfl, 1, 23, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 7, 9, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 25, 10, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inl rfl, 3, 26, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 8, 10, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 28, 11, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inl rfl, 4, 29, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 9, 11, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 31, 12, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inl rfl, 5, 32, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 10, 12, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 34, 13, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inl rfl, 6, 35, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 21, 24, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 37, 27, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 38, 30, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 39, 33, rfl, by decide, by decide, by decide⟩
  · exact ⟨Or.inr rfl, 40, 36, rfl, by decide, by decide, by decide⟩

def incidence (x : Fin 14 → Bool) : Bool :=
  ((x 0 && x 7) || ((x 1 && x 7) || ((x 3 && x 7) || ((x 1 && x 8) || ((x 2 && x 8) || ((x 4 && x 8) || ((x 2 && x 9) || ((x 3 && x 9) || ((x 5 && x 9) || ((x 3 && x 10) || ((x 4 && x 10) || ((x 6 && x 10) || ((x 4 && x 11) || ((x 5 && x 11) || ((x 0 && x 11) || ((x 5 && x 12) || ((x 6 && x 12) || ((x 1 && x 12) || ((x 6 && x 13) || ((x 0 && x 13) || (x 2 && x 13)))))))))))))))))))))

lemma incidenceCorrect (x : Fin 14 → Bool) :
    incidence x = decide (∃ p l : Fin 7,
      (p = l ∨ p = l + 1 ∨ p = l + 3) ∧ x (Fin.castAdd 7 p) = true ∧
      x (Fin.natAdd 7 l) = true) := by
  apply Bool.eq_iff_iff.mpr
  simp only [incidence, Bool.or_eq_true, Bool.and_eq_true, decide_eq_true_eq]
  constructor
  · intro h
    rcases h with h0 | h1 | h2 | h3 | h4 | h5 | h6 | h7 | h8 | h9 | h10 | h11 | h12 | h13 | h14 | h15 | h16 | h17 | h18 | h19 | h20
    · exact ⟨0, 0, by decide, h0.1, h0.2⟩
    · exact ⟨1, 0, by decide, h1.1, h1.2⟩
    · exact ⟨3, 0, by decide, h2.1, h2.2⟩
    · exact ⟨1, 1, by decide, h3.1, h3.2⟩
    · exact ⟨2, 1, by decide, h4.1, h4.2⟩
    · exact ⟨4, 1, by decide, h5.1, h5.2⟩
    · exact ⟨2, 2, by decide, h6.1, h6.2⟩
    · exact ⟨3, 2, by decide, h7.1, h7.2⟩
    · exact ⟨5, 2, by decide, h8.1, h8.2⟩
    · exact ⟨3, 3, by decide, h9.1, h9.2⟩
    · exact ⟨4, 3, by decide, h10.1, h10.2⟩
    · exact ⟨6, 3, by decide, h11.1, h11.2⟩
    · exact ⟨4, 4, by decide, h12.1, h12.2⟩
    · exact ⟨5, 4, by decide, h13.1, h13.2⟩
    · exact ⟨0, 4, by decide, h14.1, h14.2⟩
    · exact ⟨5, 5, by decide, h15.1, h15.2⟩
    · exact ⟨6, 5, by decide, h16.1, h16.2⟩
    · exact ⟨1, 5, by decide, h17.1, h17.2⟩
    · exact ⟨6, 6, by decide, h18.1, h18.2⟩
    · exact ⟨0, 6, by decide, h19.1, h19.2⟩
    · exact ⟨2, 6, by decide, h20.1, h20.2⟩
  · rintro ⟨p, l, edge, hp, hl⟩
    fin_cases p <;> fin_cases l <;> first | (exfalso; exact (by decide : ¬ _) edge) | (simp_all [Fin.castAdd, Fin.natAdd])


set_option maxHeartbeats 0 in
set_option maxRecDepth 15000 in
lemma booleanIdentity (b0 b1 b2 b3 b4 b5 b6 b7 b8 b9 b10 b11 b12 b13 : Bool) :
    (((((((b2 || (b0 && (b13 || (b0 && (b7 || b11))))) && (b9 || (b8 || (b13 || (b0 && (b7 || b11)))))) || (b1 && ((b7 || b8) || b12))) || (b3 && ((b7 || b9) || b10))) || (b4 && ((b8 || b10) || b11))) || (b5 && ((b9 || b11) || b12))) || (b6 && ((b10 || b12) || b13))) = ((b0 && b7) || ((b1 && b7) || ((b3 && b7) || ((b1 && b8) || ((b2 && b8) || ((b4 && b8) || ((b2 && b9) || ((b3 && b9) || ((b5 && b9) || ((b3 && b10) || ((b4 && b10) || ((b6 && b10) || ((b4 && b11) || ((b5 && b11) || ((b0 && b11) || ((b5 && b12) || ((b6 && b12) || ((b1 && b12) || ((b6 && b13) || ((b0 && b13) || (b2 && b13))))))))))))))))))))) := by
  revert b0 b1 b2 b3 b4 b5 b6 b7 b8 b9 b10 b11 b12 b13
  decide +kernel

set_option maxRecDepth 12000 in
set_option maxHeartbeats 12000000 in
lemma evalIncidence (x : Fin 14 → Bool) : W.eval (List.ofFn x) = incidence x := by
  let b0 := x 0
  let b1 := x 1
  let b2 := x 2
  let b3 := x 3
  let b4 := x 4
  let b5 := x 5
  let b6 := x 6
  let b7 := x 7
  let b8 := x 8
  let b9 := x 9
  let b10 := x 10
  let b11 := x 11
  let b12 := x 12
  let b13 := x 13
  let b14 := b7 || b11
  let b15 := b0 && b14
  let b16 := b13 || b15
  let b17 := b0 && b16
  let b18 := b8 || b16
  let b19 := b2 || b17
  let b20 := b9 || b18
  let b21 := b19 && b20
  let b22 := b7 || b8
  let b23 := b22 || b12
  let b24 := b1 && b23
  let b25 := b7 || b9
  let b26 := b25 || b10
  let b27 := b3 && b26
  let b28 := b8 || b10
  let b29 := b28 || b11
  let b30 := b4 && b29
  let b31 := b9 || b11
  let b32 := b31 || b12
  let b33 := b5 && b32
  let b34 := b10 || b12
  let b35 := b34 || b13
  let b36 := b6 && b35
  let b37 := b21 || b24
  let b38 := b37 || b27
  let b39 := b38 || b30
  let b40 := b39 || b33
  let b41 := b40 || b36
  have hin : List.ofFn x = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13] := by
    simp [List.ofFn_succ, b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13]
  let step (w : List Bool) (g : Gate) : List Bool :=
    w ++ [g.op.eval (g.inputs.map fun i => w.getD i false)]
  have h0 : (W.gates.take 0).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13] := hin
  have h1 : (W.gates.take 1).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14] := by
    have split : W.gates.take 1 = W.gates.take 0 ++ [⟨.or, [7,11]⟩] := rfl
    rw [split, List.foldl_append, h0]
    simp [step, GateOp.eval, b14, List.getD_eq_getElem?_getD]
  have h2 : (W.gates.take 2).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15] := by
    have split : W.gates.take 2 = W.gates.take 1 ++ [⟨.and, [0,14]⟩] := rfl
    rw [split, List.foldl_append, h1]
    simp [step, GateOp.eval, b15, List.getD_eq_getElem?_getD]
  have h3 : (W.gates.take 3).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16] := by
    have split : W.gates.take 3 = W.gates.take 2 ++ [⟨.or, [13,15]⟩] := rfl
    rw [split, List.foldl_append, h2]
    simp [step, GateOp.eval, b16, List.getD_eq_getElem?_getD]
  have h4 : (W.gates.take 4).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17] := by
    have split : W.gates.take 4 = W.gates.take 3 ++ [⟨.and, [0,16]⟩] := rfl
    rw [split, List.foldl_append, h3]
    simp [step, GateOp.eval, b17, List.getD_eq_getElem?_getD]
  have h5 : (W.gates.take 5).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18] := by
    have split : W.gates.take 5 = W.gates.take 4 ++ [⟨.or, [8,16]⟩] := rfl
    rw [split, List.foldl_append, h4]
    simp [step, GateOp.eval, b18, List.getD_eq_getElem?_getD]
  have h6 : (W.gates.take 6).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19] := by
    have split : W.gates.take 6 = W.gates.take 5 ++ [⟨.or, [2,17]⟩] := rfl
    rw [split, List.foldl_append, h5]
    simp [step, GateOp.eval, b19, List.getD_eq_getElem?_getD]
  have h7 : (W.gates.take 7).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20] := by
    have split : W.gates.take 7 = W.gates.take 6 ++ [⟨.or, [9,18]⟩] := rfl
    rw [split, List.foldl_append, h6]
    simp [step, GateOp.eval, b20, List.getD_eq_getElem?_getD]
  have h8 : (W.gates.take 8).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21] := by
    have split : W.gates.take 8 = W.gates.take 7 ++ [⟨.and, [19,20]⟩] := rfl
    rw [split, List.foldl_append, h7]
    simp [step, GateOp.eval, b21, List.getD_eq_getElem?_getD]
  have h9 : (W.gates.take 9).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22] := by
    have split : W.gates.take 9 = W.gates.take 8 ++ [⟨.or, [7,8]⟩] := rfl
    rw [split, List.foldl_append, h8]
    simp [step, GateOp.eval, b22, List.getD_eq_getElem?_getD]
  have h10 : (W.gates.take 10).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23] := by
    have split : W.gates.take 10 = W.gates.take 9 ++ [⟨.or, [22,12]⟩] := rfl
    rw [split, List.foldl_append, h9]
    simp [step, GateOp.eval, b23, List.getD_eq_getElem?_getD]
  have h11 : (W.gates.take 11).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24] := by
    have split : W.gates.take 11 = W.gates.take 10 ++ [⟨.and, [1,23]⟩] := rfl
    rw [split, List.foldl_append, h10]
    simp [step, GateOp.eval, b24, List.getD_eq_getElem?_getD]
  have h12 : (W.gates.take 12).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25] := by
    have split : W.gates.take 12 = W.gates.take 11 ++ [⟨.or, [7,9]⟩] := rfl
    rw [split, List.foldl_append, h11]
    simp [step, GateOp.eval, b25, List.getD_eq_getElem?_getD]
  have h13 : (W.gates.take 13).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26] := by
    have split : W.gates.take 13 = W.gates.take 12 ++ [⟨.or, [25,10]⟩] := rfl
    rw [split, List.foldl_append, h12]
    simp [step, GateOp.eval, b26, List.getD_eq_getElem?_getD]
  have h14 : (W.gates.take 14).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27] := by
    have split : W.gates.take 14 = W.gates.take 13 ++ [⟨.and, [3,26]⟩] := rfl
    rw [split, List.foldl_append, h13]
    simp [step, GateOp.eval, b27, List.getD_eq_getElem?_getD]
  have h15 : (W.gates.take 15).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28] := by
    have split : W.gates.take 15 = W.gates.take 14 ++ [⟨.or, [8,10]⟩] := rfl
    rw [split, List.foldl_append, h14]
    simp [step, GateOp.eval, b28, List.getD_eq_getElem?_getD]
  have h16 : (W.gates.take 16).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29] := by
    have split : W.gates.take 16 = W.gates.take 15 ++ [⟨.or, [28,11]⟩] := rfl
    rw [split, List.foldl_append, h15]
    simp [step, GateOp.eval, b29, List.getD_eq_getElem?_getD]
  have h17 : (W.gates.take 17).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30] := by
    have split : W.gates.take 17 = W.gates.take 16 ++ [⟨.and, [4,29]⟩] := rfl
    rw [split, List.foldl_append, h16]
    simp [step, GateOp.eval, b30, List.getD_eq_getElem?_getD]
  have h18 : (W.gates.take 18).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31] := by
    have split : W.gates.take 18 = W.gates.take 17 ++ [⟨.or, [9,11]⟩] := rfl
    rw [split, List.foldl_append, h17]
    simp [step, GateOp.eval, b31, List.getD_eq_getElem?_getD]
  have h19 : (W.gates.take 19).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32] := by
    have split : W.gates.take 19 = W.gates.take 18 ++ [⟨.or, [31,12]⟩] := rfl
    rw [split, List.foldl_append, h18]
    simp [step, GateOp.eval, b32, List.getD_eq_getElem?_getD]
  have h20 : (W.gates.take 20).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33] := by
    have split : W.gates.take 20 = W.gates.take 19 ++ [⟨.and, [5,32]⟩] := rfl
    rw [split, List.foldl_append, h19]
    simp [step, GateOp.eval, b33, List.getD_eq_getElem?_getD]
  have h21 : (W.gates.take 21).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33, b34] := by
    have split : W.gates.take 21 = W.gates.take 20 ++ [⟨.or, [10,12]⟩] := rfl
    rw [split, List.foldl_append, h20]
    simp [step, GateOp.eval, b34, List.getD_eq_getElem?_getD]
  have h22 : (W.gates.take 22).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33, b34, b35] := by
    have split : W.gates.take 22 = W.gates.take 21 ++ [⟨.or, [34,13]⟩] := rfl
    rw [split, List.foldl_append, h21]
    simp [step, GateOp.eval, b35, List.getD_eq_getElem?_getD]
  have h23 : (W.gates.take 23).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33, b34, b35, b36] := by
    have split : W.gates.take 23 = W.gates.take 22 ++ [⟨.and, [6,35]⟩] := rfl
    rw [split, List.foldl_append, h22]
    simp [step, GateOp.eval, b36, List.getD_eq_getElem?_getD]
  have h24 : (W.gates.take 24).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33, b34, b35, b36, b37] := by
    have split : W.gates.take 24 = W.gates.take 23 ++ [⟨.or, [21,24]⟩] := rfl
    rw [split, List.foldl_append, h23]
    simp [step, GateOp.eval, b37, List.getD_eq_getElem?_getD]
  have h25 : (W.gates.take 25).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33, b34, b35, b36, b37, b38] := by
    have split : W.gates.take 25 = W.gates.take 24 ++ [⟨.or, [37,27]⟩] := rfl
    rw [split, List.foldl_append, h24]
    simp [step, GateOp.eval, b38, List.getD_eq_getElem?_getD]
  have h26 : (W.gates.take 26).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33, b34, b35, b36, b37, b38, b39] := by
    have split : W.gates.take 26 = W.gates.take 25 ++ [⟨.or, [38,30]⟩] := rfl
    rw [split, List.foldl_append, h25]
    simp [step, GateOp.eval, b39, List.getD_eq_getElem?_getD]
  have h27 : (W.gates.take 27).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33, b34, b35, b36, b37, b38, b39, b40] := by
    have split : W.gates.take 27 = W.gates.take 26 ++ [⟨.or, [39,33]⟩] := rfl
    rw [split, List.foldl_append, h26]
    simp [step, GateOp.eval, b40, List.getD_eq_getElem?_getD]
  have h28 : (W.gates.take 28).foldl step (List.ofFn x) = [b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16, b17, b18, b19, b20, b21, b22, b23, b24, b25, b26, b27, b28, b29, b30, b31, b32, b33, b34, b35, b36, b37, b38, b39, b40, b41] := by
    have split : W.gates.take 28 = W.gates.take 27 ++ [⟨.or, [40,36]⟩] := rfl
    rw [split, List.foldl_append, h27]
    simp [step, GateOp.eval, b41, List.getD_eq_getElem?_getD]
  change ((W.gates.take 28).foldl step (List.ofFn x)).getD 41 false = incidence x
  rw [h28]
  change b41 = incidence x
  exact booleanIdentity (x 0) (x 1) (x 2) (x 3) (x 4) (x 5) (x 6) (x 7) (x 8) (x 9) (x 10) (x 11) (x 12) (x 13)

lemma exactEval (x : Fin 14 → Bool) :
    W.eval (List.ofFn x) = decide (∃ p l : Fin 7,
      (p = l ∨ p = l + 1 ∨ p = l + 3) ∧ x (Fin.castAdd 7 p) = true ∧
      x (Fin.natAdd 7 l) = true) := (evalIncidence x).trans (incidenceCorrect x)


open PEqualNP.GenericRejection PEqualNP.TopForm

theorem incidenceForDesk : ComputesIncidence fanoLines W := by
  intro X Y
  let x : Fin 14 → Bool := Fin.append (fun p => decide (p ∈ X)) (fun l => decide (l ∈ Y))
  have hi : List.ofFn x = incidenceInput X Y := List.ofFn_fin_append _ _
  rw [← hi, exactEval]
  unfold incidenceFun
  have edge : ∀ p l : Fin 7, (p = l ∨ p = l + 1 ∨ p = l + 3) ↔ p ∈ fanoLines l := by decide
  congr 1
  apply propext
  simp only [edge, x, Fin.append_left, Fin.append_right, decide_eq_true_eq]
  grind

theorem exact_28 : W.size = 28 ∧ IsAO2 14 W ∧
    (∀ g ∈ W.gates, g.inputs.Nodup) ∧ ComputesIncidence fanoLines W ∧
    (0 : Fin 7) ∈ fanoLines 0 ∧ W.lineDeg 14 {0} = 3 ∧ W.lineDeg 14 {7} = 2 := by
  exact ⟨rfl, by decide +kernel, by decide +kernel, incidenceForDesk,
    by decide, by decide +kernel, by decide +kernel⟩

end PEqualNP.Outside.L_meta_4126_research
#print axioms PEqualNP.Outside.L_meta_4126_research.exact_28
