"""Allowed 29-leaf multiplicity profiles from the project's formula-rank inequality."""
from itertools import combinations,product
from collections import Counter
from mixed_three import EDGES,stabilizer

def binary_choices(edges,W):
    constrained=[tuple(i for i in e if i in W) for e in edges]
    for winners in product(*constrained):
        if set(winners)!=W: continue
        counts=Counter(W)
        for (p,l),w in zip(edges,winners):
            counts[l if p==w else p]+=1
        yield tuple(counts[i] for i in range(14))

def main():
    allcovers={7:[],8:[]}
    for k in range(9):
        for c in combinations(range(14),k):
            W=set(c)
            if all(p in W or l in W for p,l in EDGES):
                assert k in (7,8)
                assert set(range(7))<=W or set(range(7,14))<=W
                allcovers[k].append(W)
    print('covers of size 7,8:',len(allcovers[7]),len(allcovers[8]))
    assert (len(allcovers[7]),len(allcovers[8]))==(2,14)
    profiles=set()
    for k,covers in allcovers.items():
        for W in covers:
            for slots in binary_choices(sorted(EDGES),W):
                assert sum(slots)==21+k
                for where in ([None] if k==8 else range(14)):
                    counts=tuple(v+(i==where) for i,v in enumerate(slots))
                    if counts[0]>=2 and counts[7]>=2: profiles.add(counts)
    pure=stabilizer(set())
    flip=lambda i:7+(-i)%7 if i<7 else (7-i)%7
    full=pure+[tuple(flip(v) for v in a) for a in pure]
    def canonical(a,M):
        return min(tuple(a[m.index(i)] for i in range(14)) for m in M)
    transports={tuple(sorted((a[0],a[7]))) for a in full}
    assert transports==EDGES
    for kind,group in [('side-preserving',pure),('allowing point-line duality',full)]:
        flag=[a for a in group if {a[0],a[7]}=={0,7}]
        orbits=Counter(canonical(a,flag) for a in profiles)
        print(kind,'flag stabilizer',len(flag),'allowed labeled profiles',len(profiles),'orbits',len(orbits))
        if kind.startswith('allowing'):
            for p,count in sorted(orbits.items()):
                print(','.join(map(str,p)), 'orbit',count)
if __name__=='__main__':main()
