"""Positive controls and independent finite checks for the mixed search bounds."""
import ast
from itertools import combinations
from mixed_three import EDGES, cases, stabilizer
from search_three import solve

def truth(tree, assignment):
    if isinstance(tree, ast.Constant):
        return bool(assignment >> tree.value & 1)
    a=truth(tree.left,assignment)
    b=truth(tree.right,assignment)
    return a and b if isinstance(tree.op, ast.BitAnd) else a or b

def pack(x,used):
    return sum(((x>>v)&1) << j for j,v in enumerate(used))

def edge_function(edges,x):
    return any(x>>p & x>>l & 1 for p,l in edges)

def main():
    group=stabilizer(set())
    orbit=lambda points:{tuple(sorted(m[p] for p in points)) for m in group}
    col,tri=orbit((0,1,3)),orbit((0,1,2))
    assert len(group)==168 and len(col)==7 and len(tri)==28
    assert col.isdisjoint(tri) and col|tri==set(combinations(range(7),3))
    dual=lambda v:7+(-v)%7 if v<7 else (7-v)%7
    assert {(dual(l),dual(p)) for p,l in EDGES}==EDGES
    print('Automorphism orbits exhaust all 35 triples; point/line duality verified.')

    for marked in (2,3):
        expr=solve([[2,3,4],[2,5,6]],tuple(range(7))+(0,marked,2),marked)
        assert expr
        t=ast.parse(expr,mode='eval').body
        rows=[(0,2),(0,3),(0,4),(1,2),(1,5),(1,6)]
        assert all(truth(t,x)==edge_function(rows,x) for x in range(128))
        print('Two-star positive control',marked,expr)

    mixed=solve([], (0,1,2,3,0,1), None, flag_occurrences=(1|16,2|32),
                mixed=([(2,3)],[(0,1)]))
    assert mixed
    t=ast.parse(mixed,mode='eval').body
    assert all((truth(t,x) or edge_function([(0,1)],x))==
               edge_function([(2,3),(0,1)],x) for x in range(16))
    print('Mixed lower/upper control',mixed)

    for points in [{0,1,3},{0,1,2}]:
        local,work=cases(points)
        fixed=EDGES-local
        supports={tuple(sorted(set(labels))) for _,_,labels in work}
        global_goal=[edge_function(EDGES,x) for x in range(1<<14)]
        global_need=[global_goal[x] and not edge_function(fixed,x) for x in range(1<<14)]
        for used in supports:
            size=1<<len(used)
            lo=[False]*size
            hi=[True]*size
            for x in range(1<<14):
                k=pack(x,used)
                lo[k] |= global_need[x]
                hi[k] &= global_goal[x]
            projection=[(used.index(p),used.index(l)) for p,l in fixed if p in used and l in used]
            rows=[(used.index(p),used.index(l)) for p,l in local]
            for k in range(size):
                loc=edge_function(rows,k);fix=edge_function(projection,k)
                assert lo[k] == (loc and not fix) and hi[k] == (loc or fix)
        print('Full 16384-row projection checks',sorted(points),len(supports),'supports')
if __name__=='__main__':
    main()
