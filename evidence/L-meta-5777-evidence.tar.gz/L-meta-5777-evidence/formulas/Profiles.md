# Four remaining multiplicity patterns for a 29-leaf formula

Fix the incident point 0 and line 0, whose wire labels are 0 and 7. For an unconstrained positive Fano formula meeting both singleton-degree requirements, the Lean interval theorem gives 29 as a global lower bound and 30 as an explicit upper bound. At 29 leaves, the rank argument leaves four possible literal-multiplicity vectors up to incidence automorphism and exchange of points with lines. Each vector lists the counts of points 0–6 followed by lines 0–6.

| Representative count vector | Size of orbit fixing the marked edge |
|---|---:|
| 2,1,1,1,1,1,1 / 3,3,3,3,3,3,3 | 2 |
| 2,1,1,1,1,1,2 / 3,3,3,3,3,3,2 | 8 |
| 2,1,1,1,2,2,1 / 3,3,3,3,1,3,3 | 4 |
| 2,1,1,2,1,1,1 / 2,3,3,3,3,3,3 | 4 |

For each incidence edge, the formula-rank lemma chooses one endpoint as winner and the other as loser. Each vertex must receive at least one leaf per loss, and another leaf when it wins at least once. There are 21 losses and the set of winners covers every edge. A cover has at least seven vertices, so there are either seven or eight winners. Direct enumeration finds precisely two seven-covers, the two sides, and fourteen eight-covers, each a complete side plus an exceptional opposite vertex. [General rank-slot inequality](https://github.com/open-goat/pequalnp-proofs/blob/7c4efd6d7efbd8a5b701c1c3405343b01acf5fac/lean/PEqualNP/Outside/L_meta_3793.lean)

After exchanging points with lines if necessary, take the full side to consist of points. With seven winners every point needs one leaf and each line needs three. Only one additional leaf is available; it must duplicate the marked point. With eight winners, all 29 leaves are already required by the rank slots. The exceptional line m wins a nonempty subset B of the three incident edges. A point in B needs two leaves and any other point needs one. The exceptional line has 4−|B| leaves, and the other six lines have three each. The marked point must belong to B and if m is the marked line, at most two edges can belong to B. This is necessary because degree at least two requires at least two occurrences of that variable, by induction using degree-addition at AND and maximum at OR.

The deterministic script enumerates all these winning choices, filters for the marked degrees' necessary occurrence counts, and computes the exact orbits. The Fano action is transitive on all 21 flags. For the fixed flag, its side-preserving stabilizer of order eight gives eight orbits among 18 labeled vectors. Allowing duality gives a stabilizer of order sixteen and the four representatives above. These are admissible multiplicities under the inequalities only. The existence of a 29-leaf formula requires a tree with one of these vectors satisfying the entire truth table and the marked-degree conditions. This argument concerns formulas. A 27-gate DAG can unfold to more than 29 leaves.

```sh
cd /workspace/L-meta-5777/formulas
python3 profiles.py
```

The output is in profiles.log. The interval itself is Lean checked. The 18-profile refinement uses mathematical reasoning and the Python calculation.
