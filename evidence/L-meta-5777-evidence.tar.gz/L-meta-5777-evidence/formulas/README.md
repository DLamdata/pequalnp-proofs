# Fano 30-leaf construction and restricted exact synthesis

Run with the pinned Lean 4.36.0 toolchain from the repository's lean directory. The source file and scripts can live anywhere. For the paths in the original task use the following commands.

```sh
cd /workspace/pequalnp-proofs/lean
lake env lean /workspace/L-meta-5777/formulas/Thirty.lean
cd /workspace/L-meta-5777/formulas
python3 search_twostars.py
for geometry in col-full-shared col-full-private tri-shared tri-private; do
    python3 search_three.py "$geometry" --seconds 0
done
```

Lean checked the relaxed desk statement using the project definitions. The printed linter warnings refer to unused bound names in the unaltered text of the assignment. The change in the relaxed statement is from 28 leaves to 30. The file also gives shape, which checks exactly 30 leaves and exactly degree two at both marked endpoints for every incident flag. The proof of computes holds for all 14-bit inputs and uses the definition of ComputesIncidence. The input decomposition in computes follows L_meta_8945.lean. The 30-leaf witness is the seven positive point-stars with an idempotent substitution of y AND (y AND x) in the row at the marked point x and marked line y. See the literature notes for related work and model differences.

The Python searches cover specific families. They allow the OR of a replacement subtree with the canonical stars on the remaining points. The replacement uses variables from its own rows, computes their exact incidence subfunction, and obeys the positive literal and unequal-literal-siblings condition. The marked point is in the replaced rows. A replacement for two rows has at most nine leaves if the total is at most 29. Their seven inputs are essential, so the only admissible occurrence multiset has each endpoint twice and every other input once. The marked line can be the rows' sole common line or a private neighbor of the marked point. The two-star search found no witness in either case.

A replacement for three rows has at most 13 leaves when the other four stars are retained. Three collinear points have one line in common and six private lines altogether. Three noncollinear points have three pairwise shared lines and one private line each. In both cases the marked line is either private to its point or shared. The modes col-full-shared, col-full-private, tri-shared, and tri-private use each essential local input as a separate leaf label. Two col modes without full group unmarked private twin lines under an OR for faster preliminary searches. The full modes remove this grouping restriction.

The deterministic synthesis enumerates the multiset of leaves (one occurrence per essential variable, one extra per marked endpoint, and then every admissible multiset of extra occurrences). In a positive formula, degree at least two in a singleton variable is equivalent to two occurrences whose lowest common ancestor is AND. Equal-labeled occurrences may be permuted so the designated pair enforces this condition without loss. For each binary tree the program splits the labeled leaf occurrences into two nonempty subsets in a canonical order, tries AND and OR, and rejects disallowed siblings. At each subtree the permissible truth tables have lower and upper bounds. Variables absent from the subtree are existentially quantified from the lower bound and universally quantified from the upper bound. If a candidate left operand has bits v, an AND requires the right operand to contain the lower bound and lie below upper OR NOT v. An OR requires it to contain lower AND NOT v and lie below upper. Every search uses complete local truth tables. Successful ten-leaf two-star positive controls are recorded in three-control.log. The two-star script also checks positive controls with its nine-leaf multiset.

The scripts have no random seeds. A case ends at the first witness, exhaustion, or its wall-clock alarm. A timeout is logged separately. Setting --seconds 0 disables the alarm for an exhaustive replay. All formula searches use trees, count each literal occurrence separately, and allow repeated subexpressions only at their full unfolded cost. The absence of a witness in these families leaves the unrestricted 29-leaf problem open.

## Completed run

The two-star search exhausted both marked-line cases. The three-star search exhausted 11 occurrence multisets in each full collinear mode and 55 in each noncollinear mode, 132 in total. The logs three-full.log and three.log record the first pass. Two triangle cases hit the initial two-second alarm and returned no witness on unrestricted rerun, as recorded in retries.log. Thus the minimum is 30 leaves in the stated family that retains four canonical point stars, permits a replacement subtree on the other three rows' input variables, and puts the marked point among those rows. The upper bound uses the explicit local construction in Thirty.lean. The lower side of this restricted optimum is an exhaustive Python search result. Monotone DAGs with sharing and unrestricted formula trees are outside this restricted search.

The run used CPython 3.12.14 and Lean 4.36.0 (release commit 611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9) on Linux x86-64. The checked project revision was 7c4efd6d7efbd8a5b701c1c3405343b01acf5fac.

## Unrestricted formula-size interval checked in Lean

Bounds.lean proves FanoThirty.interval. For each of the 21 incident flags, the least number of leaves in a positive formula computing Fano incidence on every input, with both marked degrees at least two and without identical positive-literal siblings, is either 29 or 30. To obtain the lower bound, the proof compiles any candidate formula to a circuit with leaf count minus one gates, preserved singleton degrees, and no shared internal wire, using L-meta-5775. L-meta-2225 excludes the resulting circuit with at most 27 gates. This verifies the previously reported 29-leaf floor in the present model. The upper bound is supplied by the explicit 30-leaf construction. The theorem gives no lower bound against arbitrary shared DAGs with 27 gates. The printout in bounds.log lists the standard three axioms. To replay with the checked local project results available, run the following.

```sh
bash /workspace/L-meta-5777/formulas/replay_bounds.sh /workspace/pequalnp-proofs
```

This file imports checked prior results beyond the original step's submission import list and is research evidence. The separate Thirty.lean covers the upper bound using project definitions alone.

FourStars.md gives the final search in the larger four-disjunct family, including arbitrary foreign-variable dependence and mixed point/line centers. Profiles.md gives a necessary four-orbit multiplicity classification for the remaining unrestricted 29-leaf question. The supporting new files are mixed_three.py, four_centers.py, profiles.py and controls.py. The cache optimization in search_three.py reuses projections of identical input supports without changing the search space.
