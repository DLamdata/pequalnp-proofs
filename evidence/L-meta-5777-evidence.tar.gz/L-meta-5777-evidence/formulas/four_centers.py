"""Classify four fixed Fano stars, including the genuinely mixed centers."""
from itertools import combinations
from mixed_three import EDGES, stabilizer

def main():
    collineations=stabilizer(set())
    dual=lambda v:7+(-v)%7 if v<7 else (7-v)%7
    group=collineations+[tuple(dual(v) for v in row) for row in collineations]
    assert len(set(group))==336
    for row in group:
        assert {tuple(sorted((row[a],row[b]))) for a,b in EDGES}==EDGES
    representatives={}
    for centers in combinations(range(14),4):
        rep=min(tuple(sorted(row[c] for c in centers)) for row in group)
        representatives[rep]=representatives.get(rep,0)+1
    assert len(representatives)==12 and sum(representatives.values())==1001
    for rep,count in sorted(representatives.items()):
        edges=[e for e in EDGES if set(e).isdisjoint(rep)]
        support=sorted(set().union(*[set(e) for e in edges]))
        for k in range(len(support)+1):
            winners=[w for w in combinations(support,k) if all(p in w or l in w for p,l in edges)]
            if winners: break
        floor=len(edges)+k
        print(rep,'orbit',count,'residual edges',len(edges),'cover',k,'floor',floor)
        if min(rep)<7 and max(rep)>=7:
            assert floor>=13
            if floor==13:
                assert rep==(0,1,2,10) and winners==[(3,4,5,6)]
                print('unique minimum cover',winners[0])
if __name__=='__main__':main()
