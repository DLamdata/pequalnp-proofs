# What happens when four complete stars remain as outer OR summands

Consider a positive tree built from four full Fano stars with four distinct centers and one arbitrary residual positive tree joined by OR. A star centered at a vertex is the AND of its literal with the OR of its three neighbors. Require no identical positive-literal siblings anywhere and singleton syntactic degrees at least two at the two endpoints of one incident flag. The natural 30-leaf construction is in this family. At a proposed total of 29 leaves, the four complete stars use 16 and the residual tree has at most 13. All four complete stars have singleton degree at most one everywhere. Thus both marked degrees have to reach two within the residual tree.

## Centers on both sides of the incidence graph

Set all four fixed center inputs to false. The target becomes the edge function of the graph obtained by deleting those centers and their incident edges. Variables outside the support of this residual graph can all be set to false as well. Simplifying Boolean constants in the residual positive tree gives a positive tree for the residual graph. This simplification cannot increase the number of leaves, and if any literal set to false was present, at least one leaf disappears. The residual graph is nonempty in every case below.

For a triangle-free four-cycle-free graph, the accepted general formula-rank lemma assigns each edge an adjacent winning and losing endpoint. For each vertex the number of leaf occurrences is at least the number of edges it loses, plus an indicator for being a winning endpoint. The winners cover every edge. Summing gives a lower bound of the number of edges plus the minimum vertex-cover size. The argument applies to the simplified tree even if removing constants produces identical literal siblings because the rank lemma needs positivity alone. [formula_rank, tight_slots, and winner_count_once](https://github.com/open-goat/pequalnp-proofs/blob/7c4efd6d7efbd8a5b701c1c3405343b01acf5fac/lean/PEqualNP/Outside/L_meta_3793.lean)

The script four_centers.py enumerates all 1,001 choices of four centers and every graph-preserving Fano point collineation, then also composes with point/line duality. It verifies each resulting permutation against all 21 edges. The 336 symmetries give 12 orbits. Two consist of pure point- or line-center sets. Nine of the other ten have a residual edge-count-plus-cover lower bound of at least 14, exceeding the available 13.

The one remaining mixed orbit has representative centers 0, 1, 2, and 10 in the desk's zero-based input numbering. Its residual graph has nine edges and exactly one minimum vertex cover, the four points 3, 4, 5, and 6. Every eligible residual tree must meet the 13-leaf floor exactly. Hence its original tree already used only residual variables, since a leaf removed by the constant restriction would put the simplified tree below the floor. Both marked variables must occur, so the marked edge lies in the residual graph. Equality in the rank-slot inequality implies that the winners are a minimum cover and each vertex has the minimum permitted number of leaves. The unique minimum cover consists entirely of points. Each incident edge therefore has its line as the losing endpoint. Each residual point wins and never loses, so its label occurs exactly once. Its singleton degree is at most one, contradicting the marked-point degree requirement.

This is a mathematical application of the linked checked rank lemma with finite data verified by Python. The complete four-star lower-bound argument has not been encoded as a Lean theorem.

## Four centers on the same side

For four point-centered stars the unconstrained residual graph comprises the rows of the remaining three points. The Python controls check the Fano symmetries directly against every edge. Collinear triples and noncollinear triples exhaust all 35 choices under collineations. Point/line duality transports the result to four line-centered stars.

The search enumerates all possible local leaf multisets with at most 13 occurrences, one occurrence for each essential residual input and two for each marked endpoint. Those lower limits follow by setting all foreign variables to false and observing that every endpoint of a remaining edge is essential, and by the degree condition. The two designated repeated occurrences have AND as their lowest common ancestor. If there are more than two occurrences, any satisfying pair can be named first since leaf labels are interchangeable.

Cases using only variables from the residual rows must compute their exact union when the other four points are false. The four exact-local searches exhaust these cases. mixed_three.py additionally permits inputs from the four fixed stars and overlaps between the residual output and the fixed stars. On a given support, write R for the uncovered edge terms, and S for the covered edge terms whose two endpoints are both visible to the residual tree. Its truth table must contain R AND NOT S and be contained in R OR S. Setting all unseen variables to false demonstrates necessity of both bounds. They suffice because each uncovered edge is entirely visible, and a covered edge with both endpoints already true remains true on all extensions. controls.py verifies both projected bounds independently over all 16,384 global inputs for every support in the additional searches. Exact-local and mixed cases together allow arbitrary labeling by all 14 original variables, allowing more terms than just a partition of the edges.

The solver handles bounds under AND and OR by enumerating the smaller child's truth tables and constraining the larger child. The search uses all legal binary splits for each multiset, with the label and degree restrictions described in the replay notes. The input is deterministic. No random seed is used.

```sh
cd /workspace/L-meta-5777/formulas
python3 four_centers.py
python3 controls.py
python3 mixed_three.py col --seconds 0
python3 mixed_three.py tri --seconds 0
```

See README.md for the exact-local replays and for the distinction between the globally checked formula interval, the specific four-star family, and the original DAG assignment.

## Completed finite checks

All 132 input multisets from the pure-support searches and all 145 additional multiset/flag orbit representatives using foreign inputs returned no witness. The additional set has four collinear and 141 noncollinear representatives. Every initially timed-out case completed on rerun with the alarm disabled. The evidence is in mixed.log and the mixed-*-retry*.log files. Thus this analysis gives minimum 30 in the four-full-stars-as-outer-disjuncts family. It does not decide the unrestricted 29-leaf case. The end-to-end lower bound for this family combines an exhaustive Python computation, the rank lemma, and the mixed-center argument above.
