"""Three-star finite subproblem synthesis under a 13-leaf local budget.
Run as python3 search_three.py. Per-multiset timeout is configurable.
"""
import argparse
import signal
from functools import cache, lru_cache
from itertools import combinations_with_replacement

def problem(name):
    if name.startswith("col-full-"):
        return [[3,4,5],[3,6,7],[3,8,9]], [1]*10, (3 if name=="col-full-shared" else 4)
    if name=="col-shared":
        # The two private line neighbors of each point are grouped under OR.
        return [[3,4],[3,5],[3,6]], [1,1,1,1,2,2,2], 3
    if name=="col-private":
        # Marked point's private lines remain separate. Other private pairs grouped.
        return [[3,4,5],[3,6],[3,7]], [1,1,1,1,1,1,2,2], 4
    return [[3,4,6],[3,5,7],[4,5,8]], [1]*9, (3 if name=="tri-shared" else 6)

def solve(rows,labels,marked, *, flag_occurrences=None, mixed=None):
    n=max(labels)+1
    full=(1<<(1<<n))-1
    vals=[sum(1<<x for x in range(1<<n) if x>>i&1) for i in range(n)]
    target=0
    for p,neighbors in enumerate(rows):
        disj=0
        for v in neighbors:
            disj |= vals[v]
        target |= vals[p] & disj
    upper=lower=target
    if mixed is not None:
        rows_edges,fixed_edges=mixed
        def union_edges(edges):
            out=0
            for a,b in edges:
                out |= vals[a]&vals[b]
            return out
        local=union_edges(rows_edges)
        fixed=union_edges(fixed_edges)
        lower=local & ~fixed
        upper=local | fixed
    pairs=(flag_occurrences if flag_occurrences is not None else
           [1<<0 | 1<<n, 1<<marked | 1<<(n+1)])
    # The first marked occurrences occupy their ordinary input positions. The
    # first two extra occurrences are the second copies; eventual other copies
    # can be permuted to choose this particular pair for the LCA requirement.
    # Occurrence subsets that use the same variables have identical projections.
    missing=[(1<<n)-1]*(1<<len(labels))
    for s in range(1,len(missing)):
        bit=s & -s
        missing[s]=missing[s^bit] & ~(1<<labels[bit.bit_length()-1])

    @lru_cache(maxsize=65536)
    def project(mask,v,universal):
        if v==0 or v==full: return v
        while mask:
            bit=mask & -mask
            i=bit.bit_length()-1
            k=1<<i
            swapped=((v&vals[i])>>k)|((v&~vals[i])<<k)
            v=(v&swapped) if universal else (v|swapped)
            mask^=bit
        return v

    def shrink(s,lo,hi):
        if lo & ~hi: return None
        mask=missing[s]
        if lo: lo=project(mask,lo,False)
        if hi!=full: hi=project(mask,hi,True)
        if lo & ~hi or lo&1 or not (hi>>(2**n-1)&1): return None
        return (lo,hi)
    @cache
    def splits(s):
        ret=[]
        a=(s-1)&s
        while a:
            b=s^a
            if (a.bit_count(),a)<(b.bit_count(),b):
                same=(a.bit_count()==b.bit_count()==1 and labels[a.bit_length()-1]==labels[b.bit_length()-1])
                if not same:
                    and_only=any((s&p)==p and a&p and b&p for p in pairs)
                    ret.append((a,b,[True] if and_only else [True,False]))
            a=(a-1)&s
        # Start with smaller first half; stable tie-break by bit masks.
        return sorted(ret,key=lambda x:(x[0].bit_count(),x[0]))

    def small(s,lo,hi):
        bounds=shrink(s,lo,hi)
        return {} if bounds is None else enumerate_small(s,*bounds)
    @cache
    def enumerate_small(s,lo,hi):
        if s.bit_count()==1:
            i=labels[s.bit_length()-1]
            t=vals[i]
            return {} if lo&~t or t&~hi else {t:str(i)}
        ret={}
        for a,b,ops in splits(s):
            for conj in ops:
                for v,expr in small(a,lo if conj else 0,full if conj else hi).items():
                    for w,rhs in small(b,lo if conj else lo&~v,hi|(full^v) if conj else hi).items():
                        val=v&w if conj else v|w
                        if val not in ret:
                            ret[val]=f'({expr} {"&" if conj else "|"} {rhs})'
        return ret

    def walk(s,lo,hi):
        bounds=shrink(s,lo,hi)
        return None if bounds is None else search(s,*bounds)
    @cache
    def search(s,lo,hi):
        if s.bit_count()<=3:
            return next(iter(small(s,lo,hi).values()),None)
        for a,b,ops in splits(s):
            for conj in ops:
                bounds=shrink(b,lo if conj else 0,full if conj else hi)
                if bounds is None: continue
                for v,expr in small(a,lo if conj else 0,full if conj else hi).items():
                    rhs=walk(b,lo if conj else lo&~v,hi|(full^v) if conj else hi)
                    if rhs is not None:
                        return f'({expr} {"&" if conj else "|"} {rhs})'
        return None
    return walk((1<<len(labels))-1,lower,upper)

class TimedOut(Exception):
    pass
def handler(*_):
    raise TimedOut()

def main():
    import gc
    ap=argparse.ArgumentParser()
    ap.add_argument('name',choices=['col-full-shared','col-full-private','col-shared','col-private','tri-shared','tri-private'])
    ap.add_argument('--seconds',type=int,default=2)
    ap.add_argument('--weight-limit',type=int,default=13)
    args=ap.parse_args()
    rows,weights,marked=problem(args.name)
    base=tuple(range(len(weights)))+(0,marked)
    remaining=args.weight_limit-sum(weights[i] for i in base)
    signal.signal(signal.SIGALRM,handler)
    for size in range(remaining+1):
        for extra in combinations_with_replacement(range(len(weights)),size):
            if sum(weights[i] for i in extra)>remaining:continue
            status='timeout'
            signal.alarm(args.seconds)
            try:
                expr=solve(rows,base+extra,marked)
                status=expr if expr else 'none'
            except TimedOut: pass
            finally:
                signal.alarm(0)
            print(args.name,extra,status,flush=True)
            gc.collect()
            if status not in ('none','timeout'):
                return
if __name__=='__main__':
    main()
