"""Complete restricted synthesis for two Fano stars with two marked degrees.
Python 3, deterministic. The remaining five stars stay in canonical form.
"""
from functools import cache
import ast
from functools import reduce
from operator import or_

ALL = (1 << 128) - 1
TRUTH = tuple(sum(1 << x for x in range(128) if x >> i & 1) for i in range(7))
# 0,1 are the two point variables. 2 is their shared neighbor; 3,4 and
# 5,6 are their respective private line-neighbors.
goal = (TRUTH[0] & (TRUTH[2]|TRUTH[3]|TRUTH[4])) | (TRUTH[1] & (TRUTH[2]|TRUTH[5]|TRUTH[6]))

def search(marked_line):
    labels = tuple(range(7)) + (0,marked_line)
    pairs = [(1<<0)|(1<<7),(1<<marked_line)|(1<<8)]

    @cache
    def splits(s):
        out = []
        a = (s-1) & s
        while a:
            b = s ^ a
            if (a.bit_count(), a) < (b.bit_count(), b):
                # Two copies of the same variable attain degree 2 iff their
                # lowest common ancestor is AND. Equal literal siblings forbidden.
                if a.bit_count() == b.bit_count() == 1 and labels[a.bit_length()-1] == labels[b.bit_length()-1]:
                    a=(a-1)&s
                    continue
                must_and = any((s & p)==p and (a & p) and (b & p) for p in pairs)
                for is_and in ([True] if must_and else [True,False]):
                    out.append((a,b,is_and))
            a=(a-1)&s
        return out

    @cache
    def small(s):
        if s.bit_count()==1:
            i=labels[s.bit_length()-1]
            return {TRUTH[i]:str(i)}
        ret={}
        for a,b,is_and in splits(s):
            for u,st in small(a).items():
                for v,tt in small(b).items():
                    ret.setdefault(u&v if is_and else u|v, f'({st} {"&" if is_and else "|"} {tt})')
        return ret

    @cache
    def synth(s,lo,hi):
        # Quantify variables absent in s to sharpen the constraints.
        for i in range(7):
            if not any((s & (1<<j)) for j,k in enumerate(labels) if k==i):
                k=1<<i
                v=TRUTH[i]
                lo |= ((lo & v)>>k)|((lo & ~v)<<k)
                hi &= ((hi & v)>>k)|((hi & ~v)<<k)
        if lo & ~hi:
            return None
        if s.bit_count()<=4:
            return next((st for v,st in small(s).items() if not (lo & ~v or v & ~hi)),None)
        for a,b,is_and in splits(s):
            for v,st in small(a).items():
                if is_and:
                    if lo & ~v: continue
                    tt=synth(b,lo,hi | (ALL^v))
                else:
                    if v & ~hi: continue
                    tt=synth(b,lo & ~v,hi)
                if tt is not None:
                    return f'({st} {"&" if is_and else "|"} {tt})'
        return None

    # Positive control with the same mandatory LCA constraints, multiset and budget.
    control = TRUTH[0] & TRUTH[marked_line] | reduce(or_, (v for i,v in enumerate(TRUTH) if i not in (0,marked_line)))
    known = synth(511,control,control)
    assert known is not None
    def check(node):
        if isinstance(node, ast.Constant):
            return TRUTH[node.value]
        left,right=check(node.left),check(node.right)
        return left & right if isinstance(node.op,ast.BitAnd) else left | right
    assert check(ast.parse(known, mode='eval').body) == control
    synth.cache_clear()
    print('positive control correct:',known)
    print('marked_line',marked_line,'result',synth(511,goal,goal),'subproblems',synth.cache_info(),flush=True)

for marked_line in (2,3):
    search(marked_line)
