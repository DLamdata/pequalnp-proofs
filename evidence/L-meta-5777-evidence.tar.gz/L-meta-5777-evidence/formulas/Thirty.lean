import Mathlib.Tactic.FinCases
import PEqualNP.Defs.DeMorganFormula
import PEqualNP.Defs.GenericRejection
import PEqualNP.Defs.TopForm

namespace FanoThirty
open PEqualNP.MetaComplexity PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection
abbrev F := DMFormula 14
def point (p : Fin 7) : F := .lit (Fin.castAdd 7 p) true
def line (l : Fin 7) : F := .lit (Fin.natAdd 7 l) true

def markedLine (p l q k : Fin 7) : F :=
  if (q = p ∧ k = l) then .and (line k) (.and (line k) (point q)) else line k
def row (p l q : Fin 7) : F :=
  .and (point q) (.or (markedLine p l q q) (.or (markedLine p l q (q-1)) (markedLine p l q (q-3))))
def orSeven (g : Fin 7 → F) : F :=
  .or (g 0) (.or (g 1) (.or (g 2) (.or (g 3) (.or (g 4) (.or (g 5) (g 6))))))

def witness (p l : Fin 7) : F := orSeven (row p l)
def distinctChildren : F → F → Bool
  | .lit i true, .lit j true => i != j
  | _, _ => true
def good : F → Bool
  | .lit _ b => b
  | .or a b | .and a b => good a && good b && distinctChildren a b
def degree (i : Nat) : F → Nat
  | .lit j _ => if j.val = i then 1 else 0
  | .and a b => degree i a + degree i b
  | .or a b => max (degree i a) (degree i b)

set_option maxRecDepth 8000 in
theorem shape : ∀ p l : Fin 7, p ∈ fanoLines l →
    (witness p l).leaves = 30 ∧ good (witness p l) = true ∧
    degree p.val (witness p l) = 2 ∧ degree (7+l.val) (witness p l) = 2 := by decide +kernel

lemma lineValue (p l q k : Fin 7) (x : Fin 14 → Bool) (hx : x (Fin.castAdd 7 q) = true) :
    (markedLine p l q k).eval x = x (Fin.natAdd 7 k) := by
  unfold markedLine
  split <;> simp [line,point,DMFormula.eval,hx]

lemma rowValue (p l q : Fin 7) (x : Fin 14 → Bool) :
    (row p l q).eval x = true ↔ x (Fin.castAdd 7 q) = true ∧
    ∃ k : Fin 7, q ∈ fanoLines k ∧ x (Fin.natAdd 7 k) = true := by
  have neighbors : ∀ q k : Fin 7, q ∈ fanoLines k ↔ k=q ∨ k=q-1 ∨ k=q-3 := by decide
  cases hx : x (Fin.castAdd 7 q) with
  | false => simp [row,point,DMFormula.eval,hx]
  | true =>
    simp only [row,DMFormula.eval,point,ite_true,hx,Bool.true_and,lineValue p l q _ x hx,Bool.or_eq_true,true_and]
    constructor
    · rintro (h|h|h)
      · exact ⟨q, (neighbors q q).2 (Or.inl rfl), h⟩
      · exact ⟨q-1, (neighbors q _).2 (Or.inr (Or.inl rfl)), h⟩
      · exact ⟨q-3, (neighbors q _).2 (Or.inr (Or.inr rfl)), h⟩
    · rintro ⟨k,h,hk⟩
      rcases (neighbors q k).1 h with rfl|rfl|rfl <;> tauto

lemma orSevenValue (g : Fin 7 → F) (x : Fin 14 → Bool) :
    (orSeven g).eval x = true ↔ ∃ i : Fin 7, (g i).eval x = true := by
  simp only [orSeven,DMFormula.eval,Bool.or_eq_true]
  constructor
  · rintro (h|h|h|h|h|h|h)
    exacts [⟨0,h⟩, ⟨1,h⟩, ⟨2,h⟩, ⟨3,h⟩, ⟨4,h⟩, ⟨5,h⟩, ⟨6,h⟩]
  · rintro ⟨i,hi⟩
    fin_cases i <;> tauto

theorem computes (p l : Fin 7) (C : Circuit) (hC : ComputesIncidence fanoLines C)
    (x : Fin 14 → Bool) : (witness p l).eval x = C.eval (List.ofFn x) := by
  let X := Finset.univ.filter fun q : Fin 7 => x (Fin.castAdd 7 q) = true
  let Y := Finset.univ.filter fun k : Fin 7 => x (Fin.natAdd 7 k) = true
  have repr : incidenceInput X Y = List.ofFn x := by
    unfold incidenceInput
    rw [← List.ofFn_fin_append]
    congr 1
    funext i
    refine Fin.addCases ?_ ?_ i
    · intro q
      simp [X]
    · intro k
      rw [Fin.append_right]
      simp [Y]
  rw [← repr,hC]
  apply Bool.eq_iff_iff.mpr
  simp only [witness,orSevenValue,rowValue,incidenceFun,decide_eq_true_eq,X,Y,Finset.mem_filter,
    Finset.mem_univ,true_and]
  tauto

def GoodProp (f : F) : Prop :=
  DMFormula.rec (fun _ b => b = true)
    (fun a b ha hb => ha ∧ hb ∧ ¬ ∃ i, a = .lit i true ∧ b = .lit i true)
    (fun a b ha hb => ha ∧ hb ∧ ¬ ∃ i, a = .lit i true ∧ b = .lit i true) f

lemma distinctSound {a b : F} (h : distinctChildren a b = true) :
    ¬ ∃ i, a = .lit i true ∧ b = .lit i true := by
  rintro ⟨i,rfl,rfl⟩
  simp [distinctChildren] at h

lemma goodSound (f : F) : good f = true → GoodProp f := by
  induction f with
  | lit i b => exact id
  | and a b ha hb | or a b ha hb =>
    intro h
    simp only [good, Bool.and_eq_true] at h
    exact ⟨ha h.1.1, hb h.1.2, distinctSound h.2⟩

noncomputable def degreeRec (i : Nat) (f : F) : Nat :=
  DMFormula.rec (fun j _ => if j.val = i then 1 else 0)
    (fun _ _ a b => a+b) (fun _ _ a b => max a b) f

lemma degreeCorrect (i : Nat) (f : F) : degreeRec i f = degree i f := by
  induction f with
  | lit _ _ => rfl
  | and a b ha hb => exact congrArg₂ (· + ·) ha hb
  | or a b ha hb => exact congrArg₂ max ha hb

theorem relaxedStatement : (have x1 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → Prop → Prop → Prop := fun (x1 x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x3 x4 : Prop) => x3 ∧ x4 ∧ ¬∃ (x5 : Fin (14 : ℕ)), x1 = PEqualNP.MetaComplexity.DMFormula.lit x5 Bool.true ∧ x2 = PEqualNP.MetaComplexity.DMFormula.lit x5 Bool.true; have x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → Prop := fun (x2 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) => PEqualNP.MetaComplexity.DMFormula.rec (fun (x3 : Fin (14 : ℕ)) (x4 : Bool) => x4 = Bool.true) x1 x1 x2; have x3 : ℕ → PEqualNP.MetaComplexity.DMFormula (14 : ℕ) → ℕ := fun (x3 : ℕ) (x4 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) => PEqualNP.MetaComplexity.DMFormula.rec (fun (x5 : Fin (14 : ℕ)) (x6 : Bool) => if ↑x5 = x3 then (1 : ℕ) else (0 : ℕ)) (fun (x5 x6 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x7 x8 : ℕ) => x7 + x8) (fun (x5 x6 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)) (x7 x8 : ℕ) => Max.max x7 x8) x4; ∀ (x4 : PEqualNP.CircuitLowerBounds.Circuit) (x5 x6 : Fin (7 : ℕ)), x4.size ≤ (27 : ℕ) → PEqualNP.TopForm.IsAO2 (14 : ℕ) x4 → (∀ x9 ∈ x4.gates, x9.inputs.Nodup) → PEqualNP.GenericRejection.ComputesIncidence PEqualNP.CircuitLowerBounds.fanoLines x4 → x5 ∈ PEqualNP.CircuitLowerBounds.fanoLines x6 → (2 : ℕ) ≤ x4.lineDeg (14 : ℕ) {↑x5} → (2 : ℕ) ≤ x4.lineDeg (14 : ℕ) {(7 : ℕ) + ↑x6} → ∃ (x14 : PEqualNP.MetaComplexity.DMFormula (14 : ℕ)), x2 x14 ∧ x14.leaves ≤ (30 : ℕ) ∧ (∀ (x15 : Fin (14 : ℕ) → Bool), x14.eval x15 = x4.eval (List.ofFn x15)) ∧ (2 : ℕ) ≤ x3 (↑x5) x14 ∧ (2 : ℕ) ≤ x3 ((7 : ℕ) + ↑x6) x14) := by
  dsimp only
  intro C p l _ _ _ hc hflag _ _
  obtain ⟨size, ok, dp, dl⟩ := shape p l hflag
  refine ⟨witness p l, goodSound _ ok, size.le, computes p l C hc, ?_, ?_⟩
  · change 2 ≤ degreeRec p.val (witness p l)
    rw [degreeCorrect, dp]
  · change 2 ≤ degreeRec (7 + l.val) (witness p l)
    rw [degreeCorrect, dl]

#print axioms relaxedStatement
end FanoThirty
