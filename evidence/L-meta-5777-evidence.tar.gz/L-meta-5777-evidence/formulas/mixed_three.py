"""Search additional 3-row replacement cases including external variables."""
import argparse
import gc
import signal
from collections import Counter
from itertools import combinations, combinations_with_replacement, permutations
from search_three import solve, TimedOut, handler

LINE=[frozenset((l,(l+1)%7,(l+3)%7)) for l in range(7)]
EDGES={(p,7+l) for l,ps in enumerate(LINE) for p in ps}

def stabilizer(points):
    maps=[]
    for m in permutations(range(7)):
        if {m[i] for i in points}!=points: continue
        ls=[frozenset(m[p] for p in row) for row in LINE]
        if all(l in LINE for l in ls):
            maps.append(m+tuple(7+LINE.index(l) for l in ls))
    return maps

def cases(points):
    rows={e for e in EDGES if e[0] in points}
    support={i for edge in rows for i in edge}
    aut=stabilizer(points)
    cases=set()
    for p,l in sorted(EDGES):
        mandatory=Counter(support)
        mandatory[p]=mandatory[l]=2
        base=tuple(sorted(mandatory.elements()))
        for n in range(14-len(base)):
            for extra in combinations_with_replacement(range(14),n):
                labels=tuple(sorted(base+extra))
                if set(labels)<=support:
                    continue  # already exhausted in the exact-local search
                k=min((m[p],m[l],tuple(sorted(m[j] for j in labels))) for m in aut)
                cases.add(k)
    return rows,sorted(cases,key=lambda c:(len(c[2]),c))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('kind',choices=('col','tri'))
    ap.add_argument('--seconds',type=int,default=3)
    ap.add_argument('--count',action='store_true')
    ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--end',type=int,default=None)
    args=ap.parse_args()
    points={0,1,3} if args.kind=='col' else {0,1,2}
    rows,work=cases(points)
    print('geometry',args.kind,'cases',len(work),flush=True)
    if args.count:return
    signal.signal(signal.SIGALRM,handler)
    for j,(p,l,labels) in enumerate(work):
        if j<args.start or args.end is not None and j>=args.end:continue
        used=sorted(set(labels))
        idx={i:k for k,i in enumerate(used)}
        dense=tuple(idx[i] for i in labels)
        two=[sum(1<<k for k in [v for v in range(len(labels)) if labels[v]==i][:2]) for i in (p,l)]
        local=[(idx[i],idx[k]) for i,k in rows]
        fixed=[(idx[i],idx[k]) for i,k in EDGES-rows if i in idx and k in idx]
        signal.alarm(args.seconds)
        status='timeout'
        try:
            status=solve([],dense,None,flag_occurrences=two,mixed=(local,fixed)) or 'none'
        except TimedOut:pass
        finally:signal.alarm(0)
        print(j,p,l,labels,status,flush=True)
        gc.collect()
        if status not in ('none','timeout'): return
if __name__=='__main__':main()
