#!/usr/bin/env bash
set -eu
evidence=$(cd "$(dirname "$0")" && pwd)
repo=${1:-/workspace/pequalnp-proofs}
cd "$repo/lean"
export PEQUALNP_HOME=${PEQUALNP_HOME:-/workspace/.pequalnp-build}
export MATHLIB_CACHE_DIR=${MATHLIB_CACHE_DIR:-/workspace/.pequalnp-cache}
../tools/build.sh +PEqualNP.Outside.L_meta_5775 +PEqualNP.Outside.L_meta_2225
out=$(mktemp -d)
trap 'rm -rf -- "$out"' EXIT
lake env lean --root="$evidence" -o "$out/Thirty.olean" "$evidence/Thirty.lean"
lake env bash -c 'LEAN_PATH="$1:$LEAN_PATH" lean "$2/Bounds.lean"' bash "$out" "$evidence"
