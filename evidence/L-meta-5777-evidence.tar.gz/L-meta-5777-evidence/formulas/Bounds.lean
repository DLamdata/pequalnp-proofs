import Thirty
import PEqualNP.Outside.L_meta_5775
import PEqualNP.Outside.L_meta_2225

namespace FanoThirty
open PEqualNP.CircuitLowerBounds PEqualNP.GenericRejection PEqualNP.TopForm
open PEqualNP.MetaComplexity PEqualNP.MetaComplexity.NestedCover

def Semantics (t : F) : Prop := ∀ x : Fin 14 → Bool, t.eval x = true ↔
  ∃ p l : Fin 7, p ∈ fanoLines l ∧ x (Fin.castAdd 7 p) = true ∧ x (Fin.natAdd 7 l) = true

def Attainable (p l : Fin 7) (k : Nat) : Prop := ∃ t : F, GoodProp t ∧ t.leaves ≤ k ∧
  Semantics t ∧ 2 ≤ degree p.val t ∧ 2 ≤ degree (7+l.val) t

theorem witnessSemantics (p l : Fin 7) : Semantics (witness p l) := by
  intro x
  simp only [witness, orSevenValue, rowValue]
  constructor
  · rintro ⟨q,hq,k,hk,hv⟩
    exact ⟨q,k,hk,hq,hv⟩
  · rintro ⟨q,k,hk,hq,hv⟩
    exact ⟨q,hq,k,hk,hv⟩

-- Compile the formula to a circuit with no reused internal wire, then apply
-- the closed Fano bound for this narrower circuit class. The gate-shape
-- transport is shared with the companion FlagEquivalence.lean.
set_option maxHeartbeats 2000000 in
theorem formulaFloor (p l : Fin 7) (hflag : p ∈ fanoLines l) (k : Nat)
    (h : Attainable p l k) : 29 ≤ k := by
  obtain ⟨t,good,leaf,sem,pd,ld⟩ := h
  by_contra! short
  obtain ⟨D,dao,dnd,ds,dtree,deval,ddeg⟩ := PEqualNP.Outside.L_meta_5775 t good
  have fp : ∀ a b : Fin 7, a ∈ fanoLines b ↔ a = b ∨ a = b + 1 ∨ a = b + 3 := by decide
  have gateShape (j : ℕ) (g : Gate) (hit : D.gates[j]? = some g) :
      (g.op = .and ∨ g.op = .or) ∧ ∃ a b : ℕ, g.inputs = [a,b] ∧ a ≠ b ∧
        a < 14 + j ∧ b < 14 + j := by
    have mem := List.mem_of_getElem? hit
    have earlier (i : ℕ) (hi : i ∈ g.inputs) : i < 14+j := by
      have valid : j < D.gates.length := (List.getElem?_eq_some_iff.mp hit).1
      have eq : gateAt D j = g := by
        unfold gateAt
        rw [List.getD_eq_getElem?_getD,hit]
        rfl
      exact dao.2.1 j valid i (eq.symm ▸ hi)
    have hlen := dao.2.2 g mem
    obtain ⟨a,b,slots⟩ : ∃ a b, g.inputs = [a,b] := by
      cases h : g.inputs with
      | nil => simp [h] at hlen
      | cons a mid => cases mid with
        | nil => simp [h] at hlen
        | cons b tail =>
          have empty : tail = [] := by
            apply List.length_eq_zero_iff.mp
            simpa [h] using hlen
          subst tail
          exact ⟨a,b,rfl⟩
    exact ⟨dao.1 g mem,a,b,slots,by simpa [slots] using dnd g mem,
      earlier a (by simp [slots]),earlier b (by simp [slots])⟩

  have cor (x : Fin 14 → Bool) : D.eval (List.ofFn x) = true ↔
      ∃ a b : Fin 7, (a = b ∨ a = b+1 ∨ a = b+3) ∧
        x (Fin.castAdd 7 a) = true ∧ x (Fin.natAdd 7 b) = true := by
    rw [deval]
    simpa only [fp] using sem x
  have disj := PEqualNP.Outside.L_meta_2225 D p l ⟨by omega,gateShape,cor⟩ dtree ((fp p l).mp hflag)
  change D.lineDeg 14 {p.val} ≤ 1 ∨ D.lineDeg 14 {7+l.val} ≤ 1 at disj
  rw [ddeg,ddeg] at disj
  change degreeRec p.val t ≤ 1 ∨ degreeRec (7+l.val) t ≤ 1 at disj
  rw [degreeCorrect,degreeCorrect] at disj
  omega

theorem interval (p l : Fin 7) (hflag : p ∈ fanoLines l) :
    (∀ k, Attainable p l k → 29 ≤ k) ∧ Attainable p l 30 := by
  refine ⟨formulaFloor p l hflag, ?_⟩
  obtain ⟨size,ok,pd,ld⟩ := shape p l hflag
  exact ⟨witness p l,goodSound _ ok,size.le,witnessSemantics p l,by omega,by omega⟩

#print axioms interval
end FanoThirty
